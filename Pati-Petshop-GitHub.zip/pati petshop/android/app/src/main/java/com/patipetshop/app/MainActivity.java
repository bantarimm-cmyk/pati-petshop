package com.patipetshop.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
