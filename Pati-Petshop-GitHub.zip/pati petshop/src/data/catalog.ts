/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CatalogItem } from '../types';

export const CATALOG_ITEMS: CatalogItem[] = [
  {
    id: 'dog_food_premium',
    name: 'Premium Köpek Maması (12kg)',
    category: 'dog',
    price: 380,
    icon: 'Beef',
    color: 'from-amber-100 to-amber-200 border-amber-300 text-amber-800 hover:bg-amber-50',
    soundType: 'bark',
  },
  {
    id: 'cat_food_premium',
    name: 'Gurme Kedi Maması (1.5kg)',
    category: 'cat',
    price: 195,
    icon: 'Fish',
    color: 'from-pink-100 to-pink-200 border-pink-300 text-pink-800 hover:bg-pink-50',
    soundType: 'meow',
  },
  {
    id: 'cat_litter_premium',
    name: 'Süper Emici Kedi Kumu (10L)',
    category: 'cat',
    price: 130,
    icon: 'Sparkles',
    color: 'from-purple-100 to-purple-200 border-purple-300 text-purple-800 hover:bg-purple-50',
    soundType: 'click',
  },
  {
    id: 'dog_toy_rope',
    name: 'Diş Kaşıyıcı Köpek İpi',
    category: 'dog',
    price: 75,
    icon: 'Bone',
    color: 'from-orange-100 to-orange-200 border-orange-300 text-orange-800 hover:bg-orange-50',
    soundType: 'bark',
  },
  {
    id: 'cat_toy_laser',
    name: 'Lazerli Kedi Oyuncağı',
    category: 'cat',
    price: 85,
    icon: 'Zap',
    color: 'from-rose-100 to-rose-200 border-rose-300 text-rose-800 hover:bg-rose-50',
    soundType: 'meow',
  },
  {
    id: 'bird_cage_luxury',
    name: 'Lüks Pirinç Kuş Kafesi',
    category: 'bird',
    price: 450,
    icon: 'Home',
    color: 'from-emerald-100 to-emerald-200 border-emerald-300 text-emerald-800 hover:bg-emerald-50',
    soundType: 'chirp',
  },
  {
    id: 'bird_feed_mix',
    name: 'Karışık Kuş Yemi (1kg)',
    category: 'bird',
    price: 60,
    icon: 'Feather',
    color: 'from-teal-100 to-teal-200 border-teal-300 text-teal-800 hover:bg-teal-50',
    soundType: 'chirp',
  },
  {
    id: 'fish_food_flakes',
    name: 'Pul Balık Yemi (250g)',
    category: 'fish',
    price: 45,
    icon: 'Waves',
    color: 'from-sky-100 to-sky-200 border-sky-300 text-sky-800 hover:bg-sky-50',
    soundType: 'bubble',
  },
  {
    id: 'pet_shampoo_aloe',
    name: 'Aloe Verasız Hassas Şampuan',
    category: 'other',
    price: 110,
    icon: 'Droplet',
    color: 'from-cyan-100 to-cyan-200 border-cyan-300 text-cyan-800 hover:bg-cyan-50',
    soundType: 'click',
  },
  {
    id: 'vet_grooming',
    name: 'Pet Kuaför & Tüy Kesimi',
    category: 'other',
    price: 350,
    icon: 'Scissors',
    color: 'from-indigo-100 to-indigo-200 border-indigo-300 text-indigo-800 hover:bg-indigo-50',
    soundType: 'success',
  },
];
