/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private isEnabled: boolean = true;

  constructor() {
    // Lazy initialisation on first user interaction
  }

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggle(enabled: boolean) {
    this.isEnabled = enabled;
    if (enabled) {
      this.init();
    }
  }

  public getEnabled(): boolean {
    return this.isEnabled;
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainStart = 0.15,
    delay = 0,
    filterFreq?: number
  ) {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, time);
    if (freqEnd !== freqStart) {
      osc.frequency.exponentialRampToValueAtTime(freqEnd, time + duration);
    }

    gainNode.gain.setValueAtTime(gainStart, time);
    gainNode.gain.exponentialRampToValueAtTime(0.001, time + duration);

    let lastNode: AudioNode = osc;

    if (filterFreq) {
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(filterFreq, time);
      filter.Q.setValueAtTime(3, time);
      lastNode.connect(filter);
      lastNode = filter;
    }

    lastNode.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + duration);
  }

  // Cute pop click sound for interface feedback
  public playClick() {
    this.playTone(600, 150, 0.06, 'sine', 0.1);
  }

  // Dog tail-wagging sound effect (rhythmic soft thumps on floor)
  public playTailWag() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    // 4 happy thumps spaced 120ms apart
    const deltas = [0, 0.12, 0.24, 0.36];
    deltas.forEach((delay) => {
      this.playTone(95, 45, 0.08, 'sine', 0.22, delay);
    });
  }

  // Treat bag rustle or food bag "tıkırtı" sound
  public playRustle() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    // Simulate a treat shake with 3 very fast high-pitched white noise bursts
    const bursts = [0, 0.08, 0.16];
    bursts.forEach((delay) => {
      const bufferSize = this.ctx!.sampleRate * 0.03; // very short
      const buffer = this.ctx!.createBuffer(1, bufferSize, this.ctx!.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx!.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx!.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(4500, time + delay);
      filter.Q.setValueAtTime(6, time + delay);

      const gain = this.ctx!.createGain();
      gain.gain.setValueAtTime(0.08, time + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, time + delay + 0.03);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx!.destination);

      noise.start(time + delay);
      noise.stop(time + delay + 0.03);
    });
  }

  // Updated success sound featuring "tıkırtı" (treat rustle) followed by a happy "kuyruk sallama" (tail wag thumps)
  public playSuccess() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    // 1. Play the "tıkırtı" treat-shaking immediately
    this.playRustle();

    // 2. Play a sweet high-register checkout chime in the middle
    this.playTone(880, 1046.50, 0.15, 'sine', 0.08, 0.05); // A5 -> C6 chime

    // 3. Play the happy "kuyruk sallama" (tail wag) thumps slightly delayed
    setTimeout(() => {
      this.playTailWag();
    }, 220);
  }

  // Synthesised cute meow sound for cats
  public playMeow() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'triangle';
    
    // Meow frequency profile: starts mid-low, rises, then falls slightly
    osc.frequency.setValueAtTime(320, time);
    osc.frequency.exponentialRampToValueAtTime(580, time + 0.15);
    osc.frequency.linearRampToValueAtTime(440, time + 0.35);

    // Formant filter to mimic "me-ow" vowel transition
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(800, time);
    filter.frequency.linearRampToValueAtTime(1600, time + 0.15);
    filter.frequency.exponentialRampToValueAtTime(1000, time + 0.35);
    filter.Q.setValueAtTime(2.5, time);

    // Volume envelope
    gainNode.gain.setValueAtTime(0.01, time);
    gainNode.gain.linearRampToValueAtTime(0.18, time + 0.06);
    gainNode.gain.exponentialRampToValueAtTime(0.08, time + 0.25);
    gainNode.gain.linearRampToValueAtTime(0.001, time + 0.35);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + 0.35);
  }

  // Cute short pet dog woof
  public playBark() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, time);
    osc.frequency.exponentialRampToValueAtTime(70, time + 0.12);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(280, time);
    filter.Q.setValueAtTime(4, time);

    gainNode.gain.setValueAtTime(0.01, time);
    gainNode.gain.linearRampToValueAtTime(0.25, time + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.01, time + 0.12);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + 0.12);
  }

  // High pitch bird chirp-chirp
  public playChirp() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    
    // Chirp 1
    this.playTone(2000, 3200, 0.05, 'sine', 0.08, 0);
    // Chirp 2
    this.playTone(2200, 3500, 0.06, 'sine', 0.08, 0.08);
  }

  // Water bubble popping sound for fishes
  public playBubble() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, time);
    osc.frequency.exponentialRampToValueAtTime(900, time + 0.12);

    gainNode.gain.setValueAtTime(0.01, time);
    gainNode.gain.linearRampToValueAtTime(0.12, time + 0.04);
    gainNode.gain.exponentialRampToValueAtTime(0.001, time + 0.12);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + 0.12);
  }

  // Soft swoosh down for item deletion/revert
  public playDelete() {
    if (!this.isEnabled) return;
    this.init();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(450, time);
    osc.frequency.linearRampToValueAtTime(80, time + 0.2);

    gainNode.gain.setValueAtTime(0.12, time);
    gainNode.gain.exponentialRampToValueAtTime(0.001, time + 0.2);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + 0.2);
  }
}

export const sounds = new SoundManager();
