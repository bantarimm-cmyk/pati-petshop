/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sale, CatalogItem, CartItem, Particle, PetCategory } from './types';
import { CATALOG_ITEMS } from './data/catalog';
import { sounds } from './utils/sound';
import StatsCard from './components/StatsCard';
import QuickSaleGrid from './components/QuickSaleGrid';
import SaleForm from './components/SaleForm';
import SalesCart from './components/SalesCart';
import SalesChart from './components/SalesChart';
import SalesHistory from './components/SalesHistory';
import ParticleSystem from './components/ParticleSystem';
import LucideIcon from './components/LucideIcon';
import CatalogManager from './components/CatalogManager';
import DailyReport from './components/DailyReport';
import BackupReminder from './components/BackupReminder';
import TargetTracker from './components/TargetTracker';
import VoiceSale from './components/VoiceSale';
import MascotStateMachine from './components/MascotStateMachine';
import WeatherWidget from './components/WeatherWidget';
import ReadySets from './components/ReadySets';

export default function App() {
  // --- Persistent Storage Loading ---
  const [sales, setSales] = useState<Sale[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('pati_petshop_sales');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  const [catalog, setCatalog] = useState<CatalogItem[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('pati_petshop_catalog');
      return saved ? JSON.parse(saved) : CATALOG_ITEMS;
    }
    return CATALOG_ITEMS;
  });

  const [activeTab, setActiveTab] = useState<'kasa' | 'katalog' | 'rapor'>('kasa');

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('pati_sound_enabled');
      return saved !== 'false'; // default is true
    }
    return true;
  });

  const [cart, setCart] = useState<CartItem[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [mascotMood, setMascotMood] = useState<'sleeping' | 'happy' | 'singing'>('sleeping');
  const [activeWeatherHighlight, setActiveWeatherHighlight] = useState<{
    itemIds: string[];
    type: string;
    cityName: string;
  } | null>(null);

  const handleHighlightProducts = (itemIds: string[], type: string, cityName: string) => {
    if (itemIds.length === 0) {
      setActiveWeatherHighlight(null);
    } else {
      setActiveWeatherHighlight({ itemIds, type, cityName });
    }
  };

  const [accentColor, setAccentColor] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('pati_accent_color') || '#FF4D00';
    }
    return '#FF4D00';
  });
  const [isColorPickerOpen, setIsColorPickerOpen] = useState(false);

  const [themeMode, setThemeMode] = useState<'night' | 'day'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('pati_theme_mode') as 'night' | 'day') || 'night';
    }
    return 'night';
  });

  // Sync themeMode
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('pati_theme_mode', themeMode);
    }
  }, [themeMode]);

  // Voice Sale addition helper
  const handleAddVoiceSale = (item: CatalogItem, quantity: number) => {
    if (item.soundType === 'bark') sounds.playBark();
    else if (item.soundType === 'meow') sounds.playMeow();
    else if (item.soundType === 'chirp') sounds.playChirp();
    else if (item.soundType === 'bubble') sounds.playBubble();
    else if (item.soundType === 'success') sounds.playSuccess();
    else sounds.playClick();

    setCart((prev) => {
      const existing = prev.find((i) => i.catalogItemId === item.id);
      if (existing) {
        return prev.map((i) =>
          i.catalogItemId === item.id ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [
        ...prev,
        {
          catalogItemId: item.id,
          name: item.name,
          category: item.category,
          price: item.price,
          quantity: quantity,
        },
      ];
    });

    setMascotMood('happy');
    setTimeout(() => setMascotMood('sleeping'), 2000);
  };

  // Sync sales with LocalStorage
  useEffect(() => {
    localStorage.setItem('pati_petshop_sales', JSON.stringify(sales));
  }, [sales]);

  // Sync and apply accent color
  useEffect(() => {
    if (typeof window !== 'undefined') {
      document.documentElement.style.setProperty('--accent-color', accentColor);
      localStorage.setItem('pati_accent_color', accentColor);
    }
  }, [accentColor]);

  // Sync catalog with LocalStorage
  useEffect(() => {
    localStorage.setItem('pati_petshop_catalog', JSON.stringify(catalog));
  }, [catalog]);

  // Sync sound setting
  useEffect(() => {
    localStorage.setItem('pati_sound_enabled', String(soundEnabled));
    sounds.toggle(soundEnabled);
  }, [soundEnabled]);

  // --- Sound Effects Manager ---
  const toggleSound = () => {
    const newValue = !soundEnabled;
    setSoundEnabled(newValue);
    if (newValue) {
      setTimeout(() => sounds.playClick(), 50);
    }
  };

  // --- Particle Explosion ---
  const triggerParticles = (clientX?: number, clientY?: number) => {
    const startX = clientX !== undefined ? clientX : window.innerWidth / 2;
    const startY = clientY !== undefined ? clientY : window.innerHeight / 3;

    const emojis = ['🐾', '✨', '🪙', '💖', '🐶', '🐱', '🐦', '🐟'];
    const count = 16;
    const newParticles: Particle[] = [];

    for (let i = 0; i < count; i++) {
      newParticles.push({
        id: Math.random().toString(36).substring(2, 9),
        x: startX,
        y: startY,
        emoji: emojis[Math.floor(Math.random() * emojis.length)],
        angle: Math.random() * 360,
        speed: 25 + Math.random() * 45,
      });
    }

    setParticles((prev) => [...prev, ...newParticles]);

    // Cleanup after animation completes
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => !newParticles.find((np) => np.id === p.id)));
    }, 1300);
  };

  // --- Mascot Interactions ---
  const handleMascotClick = (e: React.MouseEvent) => {
    const soundArray: (() => void)[] = [
      () => sounds.playMeow(),
      () => sounds.playBark(),
      () => sounds.playChirp(),
      () => sounds.playBubble(),
    ];
    // Play a random cute sound
    const randomSound = soundArray[Math.floor(Math.random() * soundArray.length)];
    randomSound();

    setMascotMood('singing');
    triggerParticles(e.clientX, e.clientY);
    setTimeout(() => setMascotMood('happy'), 600);
    setTimeout(() => setMascotMood('sleeping'), 2500);
  };

  // --- Cart Actions ---
  const handleAddToCart = (item: CatalogItem) => {
    // Play pet-specific entry sound
    if (item.soundType === 'bark') sounds.playBark();
    else if (item.soundType === 'meow') sounds.playMeow();
    else if (item.soundType === 'chirp') sounds.playChirp();
    else if (item.soundType === 'bubble') sounds.playBubble();
    else if (item.soundType === 'success') sounds.playSuccess();
    else sounds.playClick();

    setCart((prev) => {
      const existing = prev.find((i) => i.catalogItemId === item.id);
      if (existing) {
        return prev.map((i) =>
          i.catalogItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          catalogItemId: item.id,
          name: item.name,
          category: item.category,
          price: item.price,
          quantity: 1,
          image: item.image,
        },
      ];
    });

    setMascotMood('happy');
    setTimeout(() => setMascotMood('sleeping'), 2000);
  };

  const handleUpdateCartQuantity = (id: string, q: number) => {
    if (q <= 0) {
      handleRemoveFromCart(id);
      return;
    }
    setCart((prev) => prev.map((item) => (item.catalogItemId === id ? { ...item, quantity: q } : item)));
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.catalogItemId !== id));
  };

  const handleCheckoutCart = (notes: string, paymentMethod: 'cash' | 'card') => {
    if (cart.length === 0) return;

    // Generate individual sale rows for each cart item
    const newSales: Sale[] = cart.map((item) => ({
      id: 'sale_' + Math.random().toString(36).substring(2, 9),
      productName: item.name,
      category: item.category,
      price: item.price,
      quantity: item.quantity,
      totalPrice: item.price * item.quantity,
      notes: notes,
      createdAt: new Date().toISOString(),
      paymentMethod: paymentMethod,
    }));

    setSales((prev) => [...newSales, ...prev]);
    setCart([]);
    sounds.playSuccess();
    triggerParticles();

    setMascotMood('singing');
    setTimeout(() => setMascotMood('sleeping'), 3000);
  };

  // --- Instant Single Item Sale ---
  const handleInstantSell = (item: CatalogItem, event: React.MouseEvent) => {
    event.stopPropagation();

    // Sound effect
    if (item.soundType === 'bark') sounds.playBark();
    else if (item.soundType === 'meow') sounds.playMeow();
    else if (item.soundType === 'chirp') sounds.playChirp();
    else if (item.soundType === 'bubble') sounds.playBubble();
    else if (item.soundType === 'success') sounds.playSuccess();
    else sounds.playClick();

    setTimeout(() => sounds.playSuccess(), 120);

    const newSale: Sale = {
      id: 'sale_' + Math.random().toString(36).substring(2, 9),
      productName: item.name,
      category: item.category,
      price: item.price,
      quantity: 1,
      totalPrice: item.price,
      notes: 'Hızlı Tekli Satış',
      createdAt: new Date().toISOString(),
      paymentMethod: 'cash', // Default to cash for instant rapid touch
    };

    setSales((prev) => [newSale, ...prev]);
    triggerParticles(event.clientX, event.clientY);

    setMascotMood('singing');
    setTimeout(() => setMascotMood('sleeping'), 2500);
  };

  // --- Manual Custom Sale Form Actions ---
  const handleAddCustomSale = (data: {
    productName: string;
    category: PetCategory;
    price: number;
    quantity: number;
    notes: string;
    paymentMethod: 'cash' | 'card';
  }) => {
    const newSale: Sale = {
      id: 'sale_' + Math.random().toString(36).substring(2, 9),
      productName: data.productName,
      category: data.category,
      price: data.price,
      quantity: data.quantity,
      totalPrice: data.price * data.quantity,
      notes: data.notes,
      createdAt: new Date().toISOString(),
      paymentMethod: data.paymentMethod,
    };

    setSales((prev) => [newSale, ...prev]);
    sounds.playSuccess();
    triggerParticles();

    setMascotMood('happy');
    setTimeout(() => setMascotMood('sleeping'), 2000);
  };

  // --- Ledger Actions ---
  const handleDeleteSale = (id: string) => {
    setSales((prev) => prev.filter((s) => s.id !== id));
  };

  const handleClearAllSales = () => {
    setSales([]);
  };

  const handleRestoreBackup = (restoredSales: Sale[], restoredCatalog: CatalogItem[]) => {
    setSales(restoredSales);
    setCatalog(restoredCatalog);
  };

  // --- Product Catalog Handlers ---
  const handleAddCatalogItem = (newItem: Omit<CatalogItem, 'id' | 'color'>) => {
    const categoryColors: Record<PetCategory, string> = {
      cat: 'from-pink-950/20 to-purple-950/20 border-pink-900/40 text-pink-400 hover:bg-pink-950/10',
      dog: 'from-amber-950/20 to-orange-950/20 border-brand-orange/40 text-brand-orange hover:bg-brand-orange/10',
      bird: 'from-emerald-950/20 to-teal-950/20 border-emerald-900/40 text-emerald-400 hover:bg-emerald-950/10',
      fish: 'from-sky-950/20 to-blue-950/20 border-sky-900/40 text-sky-400 hover:bg-sky-950/10',
      other: 'from-indigo-950/20 to-violet-950/20 border-indigo-900/40 text-indigo-400 hover:bg-indigo-950/10',
    };
    const itemWithMeta: CatalogItem = {
      ...newItem,
      id: 'custom_item_' + Math.random().toString(36).substring(2, 9),
      color: categoryColors[newItem.category] || categoryColors.other,
    };
    setCatalog((prev) => [...prev, itemWithMeta]);
    sounds.playSuccess();
    triggerParticles();
  };

  const handleRemoveCatalogItem = (id: string) => {
    setCatalog((prev) => prev.filter((item) => item.id !== id));
  };

  // --- Metrics Aggregator ---
  const metrics = (() => {
    const totalRevenue = sales.reduce((sum, s) => sum + s.totalPrice, 0);
    const totalCount = sales.reduce((sum, s) => sum + s.quantity, 0);
    const averageBasket = sales.length > 0 ? Math.round(totalRevenue / sales.length) : 0;

    // Calculate Best Category
    const categoryTotals: Record<PetCategory, number> = { dog: 0, cat: 0, bird: 0, fish: 0, other: 0 };
    sales.forEach((s) => {
      categoryTotals[s.category] += s.totalPrice;
    });
    let bestCat: PetCategory = 'dog';
    let maxVal = 0;
    Object.entries(categoryTotals).forEach(([cat, val]) => {
      if (val > maxVal) {
        maxVal = val;
        bestCat = cat as PetCategory;
      }
    });

    const bestCatLabels: Record<PetCategory, string> = {
      dog: 'Köpek Ürünleri 🐶',
      cat: 'Kedi Ürünleri 🐱',
      bird: 'Kuş Ürünleri 🐦',
      fish: 'Balık Ürünleri 🐟',
      other: 'Hizmetler ✨',
    };

    const bestCatString = maxVal > 0 ? bestCatLabels[bestCat] : 'Veri Yok 🐾';

    return {
      totalRevenue: `₺${totalRevenue.toLocaleString('tr-TR')}`,
      totalCount: `${totalCount.toLocaleString('tr-TR')} Adet`,
      averageBasket: `₺${averageBasket.toLocaleString('tr-TR')}`,
      bestCategory: bestCatString,
    };
  })();

  return (
    <div className={`min-h-screen bg-[#0E0E0E] text-art-light dot-pattern font-sans selection:bg-brand-orange selection:text-black pb-12 antialiased ${themeMode === 'day' ? 'theme-day' : 'theme-night'}`}>
      {/* Dynamic Sound Particle Effects Component */}
      <ParticleSystem particles={particles} />

      {/* --- Elegant App Header Banner --- */}
      <header className="sticky top-0 z-40 border-b border-art-border bg-[#0E0E0E]/90 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Interactive Animated Mascot Paw Icon */}
            <motion.div
              whileHover={{ scale: 1.15, rotate: [0, -10, 10, -5, 5, 0] }}
              whileTap={{ scale: 0.9 }}
              onClick={handleMascotClick}
              className="flex h-12 w-12 items-center justify-center rounded-xs bg-[#222] text-brand-orange border border-art-border cursor-pointer relative shadow-md shadow-black/45"
              title="Mascotumuza tıklayın! 🐾"
            >
              <LucideIcon name="PawPrint" size={22} className="animate-pulse" />
              {mascotMood === 'happy' && (
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-rose-500 text-[8px] font-bold text-white">
                  ❤
                </span>
              )}
              {mascotMood === 'singing' && (
                <span className="absolute -top-2 -right-2 text-xs font-bold text-rose-500 animate-bounce">
                  ♫
                </span>
              )}
            </motion.div>

            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-serif italic text-2xl font-normal tracking-tight text-white">
                  Pati <span className="text-brand-orange">Petshop</span>
                </h1>
                <span className="hidden sm:inline-block rounded-xs bg-[#222] px-2 py-0.5 text-[9px] font-bold text-brand-orange uppercase tracking-widest border border-art-border">
                  Panel v1.0
                </span>
              </div>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-0.5">
                {mascotMood === 'sleeping' && '😴 Pati Mascotu dinleniyor... Ona tıkla!'}
                {mascotMood === 'happy' && '😃 Pati mutlu! Satışlar harika gidiyor!'}
                {mascotMood === 'singing' && '🎶 Pati şarkı söylüyor! Cha-Ching!'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Theme Color Picker Dropdown */}
            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => { sounds.playClick(); setIsColorPickerOpen(!isColorPickerOpen); }}
                className={`flex items-center gap-1.5 rounded-xs border px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  isColorPickerOpen
                    ? 'bg-[#222] border-brand-orange text-brand-orange shadow-md shadow-black/25'
                    : 'bg-[#181818] border-art-border text-gray-400 hover:text-gray-200'
                }`}
              >
                <LucideIcon name="Palette" size={12} />
                <span className="hidden md:inline">Tema Rengi</span>
                <span 
                  className="h-2.5 w-2.5 rounded-full border border-black/50" 
                  style={{ backgroundColor: accentColor }} 
                />
              </motion.button>

              <AnimatePresence>
                {isColorPickerOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsColorPickerOpen(false)} 
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-2 z-50 w-44 rounded-xs border border-art-border bg-[#141414] p-3 shadow-2xl shadow-black/90"
                    >
                      <h4 className="text-[8px] font-black uppercase tracking-widest text-brand-orange border-b border-art-border/40 pb-1.5 mb-2 flex items-center gap-1">
                        <LucideIcon name="Palette" size={10} />
                        <span>Aksan Rengi Seçin</span>
                      </h4>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { name: 'Turuncu', hex: '#FF4D00' },
                          { name: 'Yeşil', hex: '#10B981' },
                          { name: 'Mavi', hex: '#06B6D4' },
                          { name: 'Mor', hex: '#8B5CF6' },
                          { name: 'Pembe', hex: '#F43F5E' },
                          { name: 'Sarı', hex: '#F59E0B' },
                        ].map((color) => {
                          const isSelected = accentColor === color.hex;
                          return (
                            <button
                              key={color.hex}
                              type="button"
                              onClick={() => {
                                setAccentColor(color.hex);
                                sounds.playClick();
                              }}
                              className={`flex flex-col items-center gap-1 rounded-xs border p-1.5 transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-brand-orange bg-[#222]/60'
                                  : 'border-art-border bg-transparent hover:border-gray-700'
                              }`}
                            >
                              <span 
                                className="h-4.5 w-4.5 rounded-full border border-black/40 shadow-sm" 
                                style={{ backgroundColor: color.hex }}
                              />
                              <span className="text-[8px] font-extrabold uppercase tracking-wider text-gray-400">
                                {color.name}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Day / Night Theme Mode Switcher */}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                sounds.playClick();
                setThemeMode(prev => prev === 'night' ? 'day' : 'night');
              }}
              className="flex items-center gap-1.5 rounded-xs border border-art-border bg-[#181818] px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-gray-400 hover:text-gray-200 cursor-pointer transition-all"
              title={themeMode === 'night' ? 'Gündüz Moduna Geç' : 'Gece Moduna Geç'}
            >
              <LucideIcon name={themeMode === 'night' ? 'Sun' : 'Moon'} size={12} className={themeMode === 'night' ? 'text-amber-500 animate-spin-slow' : 'text-indigo-400'} />
              <span className="hidden md:inline">
                {themeMode === 'night' ? 'Gündüz' : 'Gece'}
              </span>
            </motion.button>

            {/* Sound Mute/Unmute Switch Button */}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={toggleSound}
              className={`flex items-center gap-1.5 rounded-xs border px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                soundEnabled
                  ? 'bg-[#222] border-brand-orange/40 hover:bg-[#2c2c2c] text-brand-orange shadow-md shadow-black/25'
                  : 'bg-[#181818] border-art-border text-gray-600 hover:text-gray-400'
              }`}
            >
              <LucideIcon name={soundEnabled ? 'Volume2' : 'VolumeX'} size={12} />
              <span className="hidden md:inline">
                {soundEnabled ? 'Sesler Açık' : 'Sesler Kapalı'}
              </span>
            </motion.button>
          </div>
        </div>
      </header>

      {/* --- Main Workspace Bento Grid --- */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 flex flex-col gap-8">
        
        {/* --- Top Row: Statistics Cards --- */}
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Toplam Ciro"
            value={metrics.totalRevenue}
            icon="Coins"
            gradient=""
            delay={0}
          />
          <StatsCard
            title="Satış Adedi"
            value={metrics.totalCount}
            icon="ShoppingBag"
            gradient=""
            delay={0.05}
          />
          <StatsCard
            title="Ortalama Sepet"
            value={metrics.averageBasket}
            icon="TrendingUp"
            gradient=""
            delay={0.1}
          />
          <StatsCard
            title="En Popüler Kategori"
            value={metrics.bestCategory}
            icon="Award"
            gradient=""
            delay={0.15}
          />
        </section>

        {/* --- Interactive Companions: Mascot & Weather State Machines --- */}
        <section className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <MascotStateMachine
            sales={sales}
            mascotMood={mascotMood}
            setMascotMood={setMascotMood}
            onTriggerParticles={triggerParticles}
          />
          <WeatherWidget
            catalog={catalog}
            onHighlightProducts={handleHighlightProducts}
            activeHighlight={activeWeatherHighlight}
          />
        </section>

        {/* Weekly sales target tracker */}
        <TargetTracker sales={sales} />

        {/* --- Custom Modern Segmented Tabs Navigation --- */}
        <div className="flex border-b border-art-border/60 pb-px">
          <button
            onClick={() => { sounds.playClick(); setActiveTab('kasa'); }}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'kasa'
                ? 'border-brand-orange text-brand-orange bg-[#111]'
                : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-[#111]/30'
            }`}
          >
            <LucideIcon name="Monitor" size={12} />
            <span>Kasa & Satış Ekranı</span>
          </button>
          
          <button
            onClick={() => { sounds.playClick(); setActiveTab('katalog'); }}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'katalog'
                ? 'border-brand-orange text-brand-orange bg-[#111]'
                : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-[#111]/30'
            }`}
          >
            <LucideIcon name="Package" size={12} />
            <span>Ürün Kataloğu</span>
            <span className="ml-1 rounded-xs bg-[#222] border border-art-border px-1.5 py-0.2 text-[9px] font-bold text-gray-400">
              {catalog.length}
            </span>
          </button>

          <button
            onClick={() => { sounds.playClick(); setActiveTab('rapor'); }}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'rapor'
                ? 'border-brand-orange text-brand-orange bg-[#111]'
                : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-[#111]/30'
            }`}
          >
            <LucideIcon name="TrendingUp" size={12} />
            <span>Gün Sonu Raporu</span>
            {sales.length > 0 && (
              <span className="ml-1 rounded-xs bg-brand-orange/15 border border-brand-orange/30 px-1.5 py-0.2 text-[9px] font-bold text-brand-orange">
                Yeni
              </span>
            )}
          </button>
        </div>

        {activeTab === 'kasa' && (
          <>
            {/* --- Middle Row: Sales Canvas Grid & Forms --- */}
            <section className="grid grid-cols-1 gap-8 lg:grid-cols-12 items-start">
              
              {/* Left Column (Catalog and Analytics Charts) - occupies 7 cols */}
              <div className="lg:col-span-8 flex flex-col gap-8">
                {/* Quick Catalog */}
                <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40">
                  <div className="mb-5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
                        <LucideIcon name="LayoutGrid" size={16} />
                      </div>
                      <div>
                        <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
                          Hızlı Katalog
                        </h3>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Ürünlere dokunarak sepet oluşturun</p>
                      </div>
                    </div>
                  </div>

                  <QuickSaleGrid
                    catalog={catalog}
                    onAddToCart={handleAddToCart}
                    onInstantSell={handleInstantSell}
                    activeHighlight={activeWeatherHighlight}
                  />
                </div>

                {/* Ready Bundles / Combo Packs */}
                <ReadySets
                  catalog={catalog}
                  onAddToCart={handleAddToCart}
                  onAddCatalogItem={handleAddCatalogItem}
                />

                {/* Live Analytics Dashboard Charts */}
                <SalesChart sales={sales} />
              </div>

              {/* Right Column (Cart, General manual entry form) - occupies 4 cols */}
              <div className="lg:col-span-4 flex flex-col gap-8">
                {/* Sales Shopping Basket */}
                <SalesCart
                  cart={cart}
                  onUpdateQuantity={handleUpdateCartQuantity}
                  onRemoveItem={handleRemoveFromCart}
                  onCheckout={handleCheckoutCart}
                />

                {/* Sesle Satış Girişi */}
                <VoiceSale
                  catalog={catalog}
                  onAddVoiceSale={handleAddVoiceSale}
                />

                {/* Custom Manual Sale Form */}
                <SaleForm catalog={catalog} onAddCustomSale={handleAddCustomSale} />
              </div>

            </section>

            {/* --- Bottom Row: Transaction History Ledger --- */}
            <section className="w-full">
              <SalesHistory
                sales={sales}
                onDeleteSale={handleDeleteSale}
                onClearAll={handleClearAllSales}
              />
            </section>
          </>
        )}

        {activeTab === 'katalog' && (
          <CatalogManager
            catalog={catalog}
            onAddCatalogItem={handleAddCatalogItem}
            onRemoveCatalogItem={handleRemoveCatalogItem}
          />
        )}

        {activeTab === 'rapor' && (
          <DailyReport
            sales={sales}
            onResetSales={handleClearAllSales}
            onDeleteSale={handleDeleteSale}
            triggerParticles={triggerParticles}
          />
        )}

        <BackupReminder
          sales={sales}
          catalog={catalog}
          onRestore={handleRestoreBackup}
        />

      </main>
    </div>
  );
}
