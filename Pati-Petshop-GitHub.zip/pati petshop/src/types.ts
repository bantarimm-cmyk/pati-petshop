/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PetCategory = 'dog' | 'cat' | 'bird' | 'fish' | 'other';

export interface Sale {
  id: string;
  productName: string;
  category: PetCategory;
  price: number;
  quantity: number;
  totalPrice: number;
  notes: string;
  createdAt: string; // ISO string
  paymentMethod?: 'cash' | 'card'; // Nakit veya Kredi Kartı
}

export interface CatalogItem {
  id: string;
  name: string;
  category: PetCategory;
  price: number;
  icon: string; // Lucide icon identifier
  color: string; // Tailwind bg/text classes
  soundType: 'bark' | 'meow' | 'chirp' | 'bubble' | 'click' | 'success';
  image?: string; // Base64 or URL
  images?: string[]; // Multiple images for carousel
  description?: string; // Product description
}

export interface CartItem {
  catalogItemId: string;
  name: string;
  category: PetCategory;
  price: number;
  quantity: number;
  image?: string; // Product thumbnail image url or base64
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  emoji: string;
  angle: number;
  speed: number;
}
