/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sale } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface TargetTrackerProps {
  sales: Sale[];
}

export default function TargetTracker({ sales }: TargetTrackerProps) {
  // Load target from localStorage, default is 10000 TL
  const [target, setTarget] = useState<number>(() => {
    const saved = localStorage.getItem('pati_weekly_target');
    return saved ? Number(saved) : 10000;
  });

  const [isEditing, setIsEditing] = useState(false);
  const [tempTarget, setTempTarget] = useState(String(target));

  // Calculate sales from the last 7 days
  const weeklySalesTotal = useMemo(() => {
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    return sales
      .filter((s) => new Date(s.createdAt).getTime() >= sevenDaysAgo)
      .reduce((sum, s) => sum + s.totalPrice, 0);
  }, [sales]);

  const progressPercentage = useMemo(() => {
    if (target <= 0) return 0;
    return Math.min(100, Math.round((weeklySalesTotal / target) * 100));
  }, [weeklySalesTotal, target]);

  const remainingAmount = useMemo(() => {
    return Math.max(0, target - weeklySalesTotal);
  }, [weeklySalesTotal, target]);

  // Dynamic encouragement message based on progress
  const feedbackMessage = useMemo(() => {
    if (weeklySalesTotal === 0) {
      return "Henüz bu hafta satış yapılmadı. İlk satışla hedefe doğru adım atın! 🐾";
    }
    if (progressPercentage >= 100) {
      return "Tebrikler! Haftalık satış hedefine ulaştınız! Can dostlarımız için harika bir hafta! 🐕🎉";
    }
    if (progressPercentage >= 75) {
      return "Harika gidiyorsunuz! Hedefe çok az kaldı, küçük bir gayret daha! 🐱✨";
    }
    if (progressPercentage >= 50) {
      // Halfway
      return "Yolun yarısını geçtiniz! Enerjinizi yüksek tutun, hedefe doğru devam! 🚀";
    }
    return `Haftalık hedefinize ulaşmak için ₺${remainingAmount.toLocaleString('tr-TR')} daha satış yapmalısınız. Bol şans! 💪`;
  }, [weeklySalesTotal, progressPercentage, remainingAmount]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = Number(tempTarget);
    if (!isNaN(parsed) && parsed > 0) {
      setTarget(parsed);
      localStorage.setItem('pati_weekly_target', String(parsed));
      setIsEditing(false);
      sounds.playSuccess();
    } else {
      sounds.playDelete();
    }
  };

  const handleStartEdit = () => {
    sounds.playClick();
    setTempTarget(String(target));
    setIsEditing(true);
  };

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-5 shadow-lg shadow-black/40">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
        {/* Header Title Info */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xs bg-brand-orange/15 border border-brand-orange/40 text-brand-orange">
            <LucideIcon name="Target" size={18} className="animate-pulse" />
          </div>
          <div>
            <h3 className="font-serif italic text-lg font-normal text-white">
              Haftalık Satış Hedefi <span className="text-brand-orange font-sans not-italic text-sm font-bold">%{progressPercentage}</span>
            </h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-0.5">
              Son 7 günlük satış performansınızı takip edin
            </p>
          </div>
        </div>

        {/* Action button or editing input */}
        <div className="flex items-center gap-3 self-start md:self-center">
          <AnimatePresence mode="wait">
            {isEditing ? (
              <motion.form
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleSave}
                className="flex items-center gap-2"
              >
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">₺</span>
                  <input
                    type="number"
                    value={tempTarget}
                    onChange={(e) => setTempTarget(e.target.value)}
                    placeholder="Hedef"
                    className="w-28 rounded-xs border border-brand-orange bg-[#111] py-1.5 pl-6 pr-2 text-xs font-extrabold font-mono text-white outline-none"
                    autoFocus
                    required
                    min="1"
                  />
                </div>
                <button
                  type="submit"
                  className="flex h-8 w-8 items-center justify-center rounded-xs bg-brand-orange text-black hover:bg-brand-orange/90 transition-all cursor-pointer"
                >
                  <LucideIcon name="Check" size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => { sounds.playClick(); setIsEditing(false); }}
                  className="flex h-8 w-8 items-center justify-center rounded-xs border border-art-border bg-[#222] hover:bg-[#333] text-gray-400 transition-all cursor-pointer"
                >
                  <LucideIcon name="X" size={14} />
                </button>
              </motion.form>
            ) : (
              <motion.button
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={handleStartEdit}
                className="flex items-center gap-1.5 rounded-xs border border-art-border bg-[#1a1a1a] hover:bg-[#222] px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-gray-400 hover:text-gray-200 transition-all cursor-pointer"
              >
                <LucideIcon name="Edit2" size={11} className="text-brand-orange" />
                <span>Hedefi Güncelle</span>
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Progress display and Bar */}
      <div className="space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          {/* Progress details */}
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black font-mono tracking-tight text-brand-orange">
              ₺{weeklySalesTotal.toLocaleString('tr-TR')}
            </span>
            <span className="text-xs font-extrabold font-mono text-gray-500 uppercase">
              / ₺{target.toLocaleString('tr-TR')} HEDEF
            </span>
          </div>

          {/* Remaining tracker */}
          {remainingAmount > 0 ? (
            <div className="text-xs font-bold text-gray-400 flex items-center gap-1.5">
              <LucideIcon name="Sparkles" size={12} className="text-brand-orange" />
              <span>Hedefe Kalan: <strong className="font-mono text-white">₺{remainingAmount.toLocaleString('tr-TR')}</strong></span>
            </div>
          ) : (
            <div className="text-xs font-extrabold text-[#22d3ee] flex items-center gap-1.5 uppercase tracking-wide">
              <LucideIcon name="PartyPopper" size={12} />
              <span>Hedef Tamamlandı! 🎉</span>
            </div>
          )}
        </div>

        {/* Styled Progress Bar Container */}
        <div className="relative w-full h-3 rounded-xs bg-[#111] border border-art-border/40 overflow-hidden flex">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progressPercentage}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="h-full bg-brand-orange relative overflow-hidden"
            style={{
              backgroundImage: 'linear-gradient(45deg, rgba(255,255,255,0.1) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0.1) 75%, transparent 75%, transparent)',
              backgroundSize: '20px 20px',
            }}
          />
        </div>

        {/* Dynamic motivation banner */}
        <div className="rounded-xs bg-[#181818] border border-art-border/50 p-3 text-xs font-medium text-gray-300 leading-relaxed flex items-start gap-2.5">
          <LucideIcon 
            name={progressPercentage >= 100 ? 'Award' : 'MessageSquare'} 
            size={14} 
            className="text-brand-orange shrink-0 mt-0.5" 
          />
          <span>{feedbackMessage}</span>
        </div>
      </div>
    </div>
  );
}
