/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import { Particle } from '../types';

interface ParticleSystemProps {
  particles: Particle[];
}

export default function ParticleSystem({ particles }: ParticleSystemProps) {
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      <AnimatePresence>
        {particles.map((p) => {
          // Calculate movement details using angle and speed
          const angleRad = (p.angle * Math.PI) / 180;
          const xDistance = Math.cos(angleRad) * p.speed * 4;
          const yDistance = Math.sin(angleRad) * p.speed * 4 - 300; // General drift upward

          return (
            <motion.div
              key={p.id}
              initial={{
                opacity: 1,
                scale: 0.5,
                x: p.x,
                y: p.y,
                rotate: 0,
              }}
              animate={{
                opacity: 0,
                scale: [1.2, 1.5, 0.8],
                x: p.x + xDistance,
                y: p.y + yDistance,
                rotate: p.angle * 2, // Spin while traveling
              }}
              exit={{ opacity: 0 }}
              transition={{
                duration: 1.2,
                ease: 'easeOut',
              }}
              className="absolute select-none text-2xl filter drop-shadow-md"
            >
              {p.emoji}
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
