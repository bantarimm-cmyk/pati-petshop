/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { CatalogItem, PetCategory } from '../types';
import { sounds } from '../utils/sound';
import LucideIcon from './LucideIcon';

interface ReadySetsProps {
  catalog: CatalogItem[];
  onAddToCart: (item: CatalogItem) => void;
  onAddCatalogItem: (item: Omit<CatalogItem, 'id' | 'color'>) => void;
}

export default function ReadySets({ catalog, onAddToCart, onAddCatalogItem }: ReadySetsProps) {
  const PREDEFINED_SETS = [
    {
      id: 'set_mama_kum',
      name: '📦 Süper Combo: Mama + Kum Seti',
      category: 'cat' as PetCategory,
      price: 520,
      originalPrice: 570,
      icon: 'Gift',
      soundType: 'success' as const,
      description: 'N&D Kedi Maması + Juno Kristal Kum',
      color: 'from-pink-950/20 to-purple-950/20 border-pink-500/30 text-pink-400 hover:bg-pink-950/10',
      badge: '%10 İndirim',
      items: ['N&D Kedi Maması (1.5kg)', 'Juno Kristal Kedi Kumu'],
    },
    {
      id: 'set_kedi_asi',
      name: '📦 Sağlık: Komple Kedi Aşı Seti',
      category: 'cat' as PetCategory,
      price: 450,
      originalPrice: 585,
      icon: 'Syringe',
      soundType: 'success' as const,
      description: 'İç Parazit Aşısı + Dış Parazit Aşısı + GimCat Macun',
      color: 'from-purple-950/20 to-indigo-950/20 border-purple-500/30 text-purple-400 hover:bg-purple-950/10',
      badge: '135₺ Tasarruf',
      items: ['İç Parazit Aşısı', 'Dış Parazit Aşısı', 'GimCat Tüy Macunu'],
    },
    {
      id: 'set_kopek_egitim',
      name: '📦 Eğitim: Köpek Gezdirme & Ödül Seti',
      category: 'dog' as PetCategory,
      price: 220,
      originalPrice: 255,
      icon: 'Award',
      soundType: 'success' as const,
      description: 'Rico Göğüs Tasması + Rico Somonlu Ödül Tableti',
      color: 'from-amber-950/20 to-orange-950/20 border-brand-orange/30 text-brand-orange hover:bg-brand-orange/10',
      badge: 'Fırsat Seti',
      items: ['Rico Göğüs Tasması (M)', 'Rico Somonlu Ödül Tableti'],
    },
    {
      id: 'set_kus_kafes',
      name: '📦 Kuş: Neşeli Gurme Kafes Seti',
      category: 'bird' as PetCategory,
      price: 240,
      originalPrice: 305,
      icon: 'Feather',
      soundType: 'success' as const,
      description: 'Ballı Yavru Kuş Yemi + Meyveli Yetişkin Kuş Yemi + Papağan Yemi',
      color: 'from-emerald-950/20 to-teal-950/20 border-emerald-500/30 text-emerald-400 hover:bg-emerald-950/10',
      badge: '%20 İndirim',
      items: ['Ballı Yavru Kuş Yemi', 'Meyveli Kuş Yemi', 'Sultan Papağanı Yemi'],
    },
    {
      id: 'set_kedi_hijyen',
      name: '📦 Hijyen: Kedi Tüy ve Koku Bakım Seti',
      category: 'cat' as PetCategory,
      price: 420,
      originalPrice: 535,
      icon: 'Sparkles',
      soundType: 'success' as const,
      description: 'Tüy Geliştirici Macun + Bioxic Koku Giderici + Kristal Kum',
      color: 'from-pink-950/20 to-rose-950/20 border-pink-500/30 text-pink-400 hover:bg-pink-950/10',
      badge: 'En Popüler',
      items: ['GimCat Macun', 'Bioxic Koku Giderici', 'Kristal Kum'],
    }
  ];

  const handleInstantAddToCart = (set: typeof PREDEFINED_SETS[0]) => {
    // Construct a temporary catalog item from the set definition
    const setItem: CatalogItem = {
      id: `set_item_${set.id}`,
      name: set.name,
      category: set.category,
      price: set.price,
      icon: set.icon,
      color: set.color,
      soundType: set.soundType,
    };
    onAddToCart(setItem);
  };

  const handleAddToPermanentCatalog = (set: typeof PREDEFINED_SETS[0]) => {
    // Check if it already exists in catalog
    const exists = catalog.some(item => item.name === set.name);
    if (exists) {
      sounds.playClick();
      alert(`'${set.name}' ürünü katalogda zaten mevcut.`);
      return;
    }

    onAddCatalogItem({
      name: set.name,
      category: set.category,
      price: set.price,
      icon: set.icon,
      soundType: set.soundType,
    });
  };

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40">
      <div className="mb-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-art-border/40 pb-4">
        <div className="flex items-center gap-3">
          <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
            <LucideIcon name="Gift" size={16} />
          </div>
          <div>
            <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
              Kampanyalı Hazır Setler
            </h3>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1 font-bold">
              En sık satılan ürün kombinasyonları ve indirimli paketler
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PREDEFINED_SETS.map((set) => {
          const isRegistered = catalog.some(item => item.name === set.name);
          return (
            <motion.div
              key={set.id}
              whileHover={{ scale: 1.01 }}
              className={`rounded-xs border p-4 bg-[#111]/40 flex flex-col justify-between transition-all ${
                set.category === 'cat'
                  ? 'border-pink-900/30 hover:border-pink-500/50 hover:bg-pink-950/5'
                  : set.category === 'dog'
                  ? 'border-brand-orange/30 hover:border-brand-orange/50 hover:bg-brand-orange/5'
                  : 'border-emerald-900/30 hover:border-emerald-500/50 hover:bg-emerald-950/5'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">
                      {set.category === 'cat' ? '🐱' : set.category === 'dog' ? '🐶' : '🐦'}
                    </span>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider line-clamp-1">
                      {set.name.replace('📦 ', '')}
                    </h4>
                  </div>
                  <span className={`px-1.5 py-0.5 rounded-xs text-[7px] font-black uppercase tracking-wider border shrink-0 ${
                    set.category === 'cat'
                      ? 'bg-pink-950/30 text-pink-400 border-pink-500/30'
                      : set.category === 'dog'
                      ? 'bg-brand-orange/10 text-brand-orange border-brand-orange/30'
                      : 'bg-emerald-950/30 text-emerald-400 border-emerald-500/30'
                  }`}>
                    {set.badge}
                  </span>
                </div>

                <p className="text-[10px] text-gray-400 font-medium leading-normal mb-3">
                  {set.description}
                </p>

                {/* Items tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {set.items.map((item, idx) => (
                    <span key={idx} className="bg-[#222]/60 border border-art-border/30 rounded-xs px-1.5 py-0.5 text-[8px] font-bold text-gray-500 uppercase tracking-widest">
                      ✓ {item}
                    </span>
                  ))}
                </div>
              </div>

              {/* Pricing and Action */}
              <div className="flex items-center justify-between border-t border-art-border/20 pt-3 mt-auto">
                <div className="flex flex-col">
                  <span className="text-[8px] font-bold text-gray-500 line-through tracking-wider">
                    {set.originalPrice}₺
                  </span>
                  <span className="text-base font-black text-brand-orange font-mono">
                    {set.price}₺
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Catalog Registration Status */}
                  <button
                    onClick={() => handleAddToPermanentCatalog(set)}
                    disabled={isRegistered}
                    className={`h-7 px-2.5 rounded-xs border text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                      isRegistered
                        ? 'bg-emerald-950/20 text-emerald-500/60 border-emerald-900/30 cursor-not-allowed'
                        : 'bg-transparent border-art-border text-gray-400 hover:text-white hover:border-white cursor-pointer'
                    }`}
                    title={isRegistered ? 'Katalogda Kayıtlı' : 'Kataloğa Tek Tıkla Ekle'}
                  >
                    <LucideIcon name={isRegistered ? 'Check' : 'PlusCircle'} size={11} />
                    <span>{isRegistered ? 'Kayıtlı' : 'Kataloğa Ekle'}</span>
                  </button>

                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleInstantAddToCart(set)}
                    className="h-7 px-3 rounded-xs bg-brand-orange hover:bg-brand-orange/90 text-black text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-sm shadow-brand-orange/10"
                  >
                    <LucideIcon name="ShoppingCart" size={11} />
                    <span>Sepete Ekle</span>
                  </motion.button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
