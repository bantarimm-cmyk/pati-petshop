/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CatalogItem, PetCategory } from '../types';
import { sounds } from '../utils/sound';
import LucideIcon from './LucideIcon';

import * as XLSX from 'xlsx';

interface CatalogManagerProps {
  catalog: CatalogItem[];
  onAddCatalogItem: (item: Omit<CatalogItem, 'id' | 'color'>) => void;
  onRemoveCatalogItem: (id: string) => void;
}

const PRESET_ICONS = [
  'Beef', 'Fish', 'Bone', 'Zap', 'Home', 'Feather', 'Waves', 
  'Droplet', 'Scissors', 'Award', 'Sparkles', 'Heart', 'Package', 
  'Gift', 'ShoppingBag', 'Smile', 'ToyBrick', 'Syringe'
];

const PRESET_SOUNDS = [
  { key: 'click', label: 'Tık Sesi 🔊' },
  { key: 'success', label: 'Başarı Sesi 🎉' },
  { key: 'meow', label: 'Kedi Miyavlaması 🐱' },
  { key: 'bark', label: 'Köpek Havlaması 🐶' },
  { key: 'chirp', label: 'Kuş Ötüşü 🐦' },
  { key: 'bubble', label: 'Balık Baloncuğu 🐟' },
];

// Sub-component for individual Catalog Items rendering
function CatalogItemRow({
  item,
  onRemove,
  getCategoryBadge,
}: {
  item: CatalogItem;
  onRemove: (id: string) => void;
  getCategoryBadge: (cat: PetCategory) => { text: string; emoji: string; style: string };
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeImgIdx, setActiveImgIdx] = useState(0);

  const baseImages = item.images && item.images.length > 0
    ? item.images
    : (item.image ? [item.image] : []);

  const categoryFallbackCarousels: Record<PetCategory, string[]> = {
    cat: [
      'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=500&auto=format&fit=crop&q=80'
    ],
    dog: [
      'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=500&auto=format&fit=crop&q=80'
    ],
    bird: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=500&auto=format&fit=crop&q=80'
    ],
    fish: [
      'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1544568100-847a948585b9?w=500&auto=format&fit=crop&q=80'
    ],
    other: [
      'https://images.unsplash.com/photo-1444212477490-ca407925329e?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1544568100-847a948585b9?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=500&auto=format&fit=crop&q=80'
    ]
  };

  const slides = baseImages.length > 0 
    ? (baseImages.length === 1 
        ? [baseImages[0], ...categoryFallbackCarousels[item.category].slice(0, 2)]
        : baseImages)
    : categoryFallbackCarousels[item.category];

  const badge = getCategoryBadge(item.category);

  const playSound = () => {
    if (item.soundType === 'bark') sounds.playBark();
    else if (item.soundType === 'meow') sounds.playMeow();
    else if (item.soundType === 'chirp') sounds.playChirp();
    else if (item.soundType === 'bubble') sounds.playBubble();
    else if (item.soundType === 'success') sounds.playSuccess();
    else sounds.playClick();
  };

  const defaultDescription = `${item.name}, dostunuzun yaşam kalitesini maksimuma çıkarmak için geliştirilmiş sağlıklı, hijyenik ve yüksek kaliteli bir üründür. `;

  return (
    <div className="border-b border-art-border/20 py-3.5 px-2 hover:bg-[#131313]/40 transition-colors rounded-xs">
      {/* COMPACT MAIN ROW */}
      <div 
        onClick={() => { sounds.playClick(); setIsExpanded(!isExpanded); }}
        className="flex items-center justify-between cursor-pointer group"
      >
        <div className="flex items-center gap-3 truncate pr-2">
          {/* Main Thumbnail */}
          <div className="relative w-10 h-10 rounded-xs border border-art-border bg-[#1c1c1c] flex items-center justify-center overflow-hidden flex-shrink-0">
            {slides[0] ? (
              <img
                src={slides[0]}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="text-brand-orange">
                <LucideIcon name={item.icon || 'Package'} size={15} />
              </div>
            )}
          </div>
          
          <div className="truncate">
            <h4 className="text-xs font-bold text-art-light truncate group-hover:text-brand-orange transition-colors" title={item.name}>
              {item.name}
            </h4>
            <div className="flex items-center gap-2 mt-1">
              <span className={`inline-flex items-center gap-0.5 rounded-xs border px-1.5 py-0.2 text-[8px] font-extrabold uppercase tracking-wider ${badge.style}`}>
                {badge.emoji} {badge.text}
              </span>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-wider">
                🔊 {item.soundType}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3.5 flex-shrink-0">
          <span className="font-mono text-xs font-black text-brand-orange">
            ₺{item.price}
          </span>

          {/* Expand chevron */}
          <div className="text-gray-500 group-hover:text-brand-orange transition-colors">
            <LucideIcon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={14} />
          </div>

          {/* Delete button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              sounds.playDelete();
              onRemove(item.id);
            }}
            className="flex h-7 w-7 items-center justify-center rounded-xs bg-rose-950/40 text-rose-400 border border-rose-900/50 hover:bg-rose-900/30 transition-colors cursor-pointer"
            title="Katalogdan Sil"
          >
            <LucideIcon name="Trash2" size={11} />
          </button>
        </div>
      </div>

      {/* EXPANDED DETAILS CARD */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0, marginTop: 0 }}
            animate={{ height: 'auto', opacity: 1, marginTop: 12 }}
            exit={{ height: 0, opacity: 0, marginTop: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden bg-[#0a0a0a] border border-art-border/30 rounded-xs p-4 flex flex-col md:flex-row gap-4"
          >
            {/* CAROUSEL (DÖNER GALERİ) */}
            <div className="w-full md:w-2/5 flex flex-col gap-2">
              <div className="relative aspect-video rounded-xs border border-art-border bg-[#151515] overflow-hidden group/carousel flex items-center justify-center">
                {slides[activeImgIdx] ? (
                  <img
                    src={slides[activeImgIdx]}
                    alt={`Product slide ${activeImgIdx}`}
                    className="w-full h-full object-cover animate-fade-in"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <LucideIcon name="Image" size={24} className="text-gray-600" />
                )}

                {/* Left/Right buttons */}
                {slides.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        sounds.playClick();
                        setActiveImgIdx(prev => (prev === 0 ? slides.length - 1 : prev - 1));
                      }}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-black/75 border border-white/10 hover:border-brand-orange text-white flex items-center justify-center cursor-pointer transition-all"
                    >
                      <LucideIcon name="ChevronLeft" size={12} />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        sounds.playClick();
                        setActiveImgIdx(prev => (prev === slides.length - 1 ? 0 : prev + 1));
                      }}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-black/75 border border-white/10 hover:border-brand-orange text-white flex items-center justify-center cursor-pointer transition-all"
                    >
                      <LucideIcon name="ChevronRight" size={12} />
                    </button>
                  </>
                )}

                {/* Image counter tag */}
                <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/75 text-[7px] font-mono text-gray-400 uppercase tracking-widest border border-white/5">
                  {activeImgIdx + 1} / {slides.length}
                </span>
              </div>

              {/* Indicator dots */}
              {slides.length > 1 && (
                <div className="flex justify-center gap-1.5 mt-1">
                  {slides.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={(e) => { e.stopPropagation(); sounds.playClick(); setActiveImgIdx(idx); }}
                      className={`h-1.5 rounded-full transition-all cursor-pointer ${
                        idx === activeImgIdx ? 'w-4 bg-brand-orange' : 'w-1.5 bg-gray-600 hover:bg-gray-400'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* DETAILS TEXT PANEL */}
            <div className="flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-art-border/15 pb-1.5 mb-2">
                  <span className="text-[9px] font-black uppercase text-brand-orange tracking-widest">
                    {item.category.toUpperCase()} ÜRÜN DETAYI
                  </span>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); playSound(); }}
                    className="text-[9.5px] font-black uppercase tracking-wider text-brand-orange hover:underline cursor-pointer flex items-center gap-1.5"
                  >
                    🔊 Sesi Sına
                  </button>
                </div>
                <p className="text-[10px] text-gray-300 font-medium leading-relaxed">
                  {item.description || defaultDescription}
                </p>
              </div>

              <div className="mt-4 pt-2 border-t border-art-border/15 flex items-center justify-between text-[9px] font-bold uppercase tracking-wider text-gray-500">
                <span>Dükkan Kodu: <strong className="text-gray-300 font-mono text-[9.5px]">{item.id}</strong></span>
                <span className="text-brand-orange font-black">Fiyat: ₺{item.price}</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const SMART_BRANDS = ['N&D', 'Pro Plan', 'Royal Canin', 'Rico', 'Juno', 'Peritas'];
const SMART_FORMULAS = ['Yavru', 'Yetişkin', 'Kısırlaştırılmış'];
const SMART_FLAVORS = ['Tavuklu', 'Somonlu', 'Kuzulu', 'Ördekli'];

const ESSENTIAL_PRODUCTS = [
  { id: 'gimcat_hairball', name: 'GimCat Anti-Hairball Kedi Malt Macunu (50g)', price: 185, category: 'cat' as PetCategory, icon: 'Droplet', soundType: 'meow' as const, description: 'Tüy yumağı kusmasını önleyici formül' },
  { id: 'gimcat_growth', name: 'GimCat Duo-Paste Tüy Geliştirici Macun (50g)', price: 195, category: 'cat' as PetCategory, icon: 'Sparkles', soundType: 'meow' as const, description: 'Sağlıklı deri ve parlak tüy gelişimi' },
  { id: 'bioxic_odor', name: 'Bioxic Kedi Kumu Koku Giderici Toz', price: 120, category: 'cat' as PetCategory, icon: 'Waves', soundType: 'bubble' as const, description: 'Kötü kokuları hapseden hijyenik toz' },
  { id: 'bioxic_oral', name: 'Bioxic Evcil Hayvan Ağız Bakım Suyu (250ml)', price: 145, category: 'dog' as PetCategory, icon: 'Droplet', soundType: 'bark' as const, description: 'Diş taşı ve ağız kokusu giderici solüsyon' },
  { id: 'gardenmix_budgie_honey', name: 'Garden Mix Ballı Yavru Muhabbet Kuşu Yemi', price: 65, category: 'bird' as PetCategory, icon: 'Feather', soundType: 'chirp' as const, description: 'Gelişim destekleyici ballı tohum karışımı' },
  { id: 'gardenmix_budgie_fruit', name: 'Garden Mix Meyveli Yetişkin Kuş Yemi', price: 55, category: 'bird' as PetCategory, icon: 'Feather', soundType: 'chirp' as const, description: 'Karışık kurutulmuş meyveli premium yem' },
  { id: 'gardenmix_sultan', name: 'Garden Mix Sultan Papağanı Özel Yemi', price: 135, category: 'bird' as PetCategory, icon: 'Feather', soundType: 'chirp' as const, description: 'Büyük tohumlu gurme papağan yemi' },
  { id: 'gardenmix_lovebird', name: 'Garden Mix Paraket Kuş Yemi (Sade)', price: 110, category: 'bird' as PetCategory, icon: 'Feather', soundType: 'chirp' as const, description: 'Doğal tahıllı günlük yem karışımı' },
  { id: 'juno_crystal_litter', name: 'Juno Kristal Silika Kedi Kumu (3.8L)', price: 220, category: 'cat' as PetCategory, icon: 'Package', soundType: 'click' as const, description: 'Yüksek emiş güçlü kokusuz kristal kum' },
  { id: 'peritas_dog_treat', name: 'Peritas Kuzulu Köpek Ödül Çubuğu (3lü)', price: 85, category: 'dog' as PetCategory, icon: 'Beef', soundType: 'bark' as const, description: 'Eğitimler için yüksek proteinli ödül maması' },
  { id: 'peritas_cat_treat', name: 'Peritas Somonlu Sıvı Kedi Ödül Maması', price: 45, category: 'cat' as PetCategory, icon: 'Fish', soundType: 'meow' as const, description: 'Kediler için lezzetli sıvı ödül tüpü' },
  { id: 'rico_dog_treat', name: 'Rico Somonlu Ödül Tableti (100g)', price: 75, category: 'dog' as PetCategory, icon: 'Bone', soundType: 'bark' as const, description: 'Özel eğitim ve motivasyon tableti' },
];

export default function CatalogManager({ catalog, onAddCatalogItem, onRemoveCatalogItem }: CatalogManagerProps) {
  // Tabs: 'single' | 'bulk' | 'preset' | 'smart' | 'import'
  const [activeTab, setActiveTab] = useState<'single' | 'bulk' | 'preset' | 'smart' | 'import'>('single');
  const [isDragging, setIsDragging] = useState(false);

  // Single Add State
  const [name, setName] = useState('');
  const [category, setCategory] = useState<PetCategory>('dog');
  const [price, setPrice] = useState<number | ''>('');
  const [icon, setIcon] = useState('Package');
  const [soundType, setSoundType] = useState<'bark' | 'meow' | 'chirp' | 'bubble' | 'click' | 'success'>('click');
  const [singleError, setSingleError] = useState('');

  // --- Image, AI Generator & Gallery States ---
  const [selectedImage, setSelectedImage] = useState<string>(''); // Holds Base64 or URL
  const [aiStyle, setAiStyle] = useState<'realistic' | 'watercolor' | 'cartoon' | 'neon'>('realistic');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState('');
  const [showGallery, setShowGallery] = useState(false);

  // Extra properties for Catalog Items
  const [description, setDescription] = useState('');
  const [imagesList, setImagesList] = useState<string[]>([]);
  const [isCompletingAI, setIsCompletingAI] = useState(false);

  // OCR Scanner states
  const [showOCRScanner, setShowOCRScanner] = useState(false);
  const [isScanningOCR, setIsScanningOCR] = useState(false);
  const [ocrScannerStream, setOcrScannerStream] = useState<MediaStream | null>(null);
  const [ocrError, setOcrError] = useState('');

  // Expandable item state
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);

  // Preloaded media gallery (cute and high-quality pets and items)
  const [mediaGallery, setMediaGallery] = useState<string[]>([
    'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400&auto=format&fit=crop&q=60', // Kedi maması kabı
    'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=400&auto=format&fit=crop&q=60', // Köpek tasmayla koşan
    'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400&auto=format&fit=crop&q=60', // Köpek maması/oyuncaklı
    'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=400&auto=format&fit=crop&q=60', // Sevimli Yavru Köpek
    'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&auto=format&fit=crop&q=60', // Kedi portre
    'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=400&auto=format&fit=crop&q=60', // Tavşan / Pet
    'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=400&auto=format&fit=crop&q=60', // Goldfish akvaryum
    'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&auto=format&fit=crop&q=60', // Kuş kafeste yeşil
  ]);

  // Bulk Add State
  const [bulkText, setBulkText] = useState(
    'Lüks Kedi Tırmalama Ağacı - 550\n' +
    'Ergonomik Köpek Tasması - 220\n' +
    'Kalamar Kemiği - 45\n' +
    'Akvaryum Hava Motoru - 180'
  );
  const [bulkCategory, setBulkCategory] = useState<PetCategory>('dog');
  const [bulkError, setBulkError] = useState('');
  const [bulkSuccessMsg, setBulkSuccessMsg] = useState('');

  // Smart Generator States
  const [smartSubTab, setSmartSubTab] = useState<'matrix' | 'size' | 'essentials'>('matrix');

  // Matrix states
  const [selectedBrands, setSelectedBrands] = useState<string[]>(['N&D', 'Pro Plan', 'Royal Canin']);
  const [selectedFormulas, setSelectedFormulas] = useState<string[]>(['Kısırlaştırılmış', 'Yetişkin']);
  const [selectedFlavors, setSelectedFlavors] = useState<string[]>(['Tavuklu', 'Somonlu']);
  const [matrixBasePrice, setMatrixBasePrice] = useState<number>(250);
  const [matrixCategory, setMatrixCategory] = useState<PetCategory>('cat');

  // Size states
  const [sizeBaseName, setSizeBaseName] = useState('Rico Göğüs Tasması');
  const [sizeCategory, setSizeCategory] = useState<PetCategory>('dog');
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['S', 'M', 'L']);
  const [sizeBasePrice, setSizeBasePrice] = useState<number>(180);

  // Essentials Checklist states
  const [selectedEssentials, setSelectedEssentials] = useState<string[]>([
    'gimcat_hairball', 'gimcat_growth', 'bioxic_odor', 'bioxic_oral', 'gardenmix_sultan', 'juno_crystal_litter'
  ]);

  // Search state
  const [searchTerm, setSearchTerm] = useState('');

  // Preset Packages definition
  const PRESETS_BUNDLES = [
    {
      id: 'bundle_cat',
      title: '🐱 Kedi Konfor & Eğlence',
      description: 'Kediler için tırmalama, tüy bakımı, nane ve interaktif fare oyuncağı seti.',
      color: 'border-pink-500/30 bg-pink-950/5 hover:bg-pink-950/15',
      badgeColor: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
      items: [
        { name: 'Kedi Tırmalama Ağacı', category: 'cat' as PetCategory, price: 550, icon: 'Home', soundType: 'meow' as const },
        { name: 'Malt Macun Tüy Önleyici', category: 'cat' as PetCategory, price: 140, icon: 'Droplet', soundType: 'meow' as const },
        { name: 'Kedi Nanesi (Catnip) Spreyi', category: 'cat' as PetCategory, price: 95, icon: 'Sparkles', soundType: 'click' as const },
        { name: 'İnteraktif Peluş Fare', category: 'cat' as PetCategory, price: 75, icon: 'Smile', soundType: 'meow' as const },
      ]
    },
    {
      id: 'bundle_dog',
      title: '🐶 Köpek Eğitim & Ödül',
      description: 'Köpekler için göğüs tasması, eğitim sosisi, diş ipi ve pratik köpek matı.',
      color: 'border-brand-orange/30 bg-brand-orange/5 hover:bg-brand-orange/15',
      badgeColor: 'bg-brand-orange/20 text-brand-orange border-brand-orange/30',
      items: [
        { name: 'Ergonomik Göğüs Tasması', category: 'dog' as PetCategory, price: 240, icon: 'Award', soundType: 'bark' as const },
        { name: 'Ödül Kemirmeliği Sosis', category: 'dog' as PetCategory, price: 80, icon: 'Beef', soundType: 'bark' as const },
        { name: 'Diş Temizleyici Diş İpi', category: 'dog' as PetCategory, price: 65, icon: 'Bone', soundType: 'bark' as const },
        { name: 'Pratik Katlanabilir Mat', category: 'dog' as PetCategory, price: 180, icon: 'Package', soundType: 'click' as const },
      ]
    },
    {
      id: 'bundle_exotic',
      title: '🐦🐠 Kuş & Akvaryum Dünyası',
      description: 'Kuşlar ve balıklar için doğal ahşap tünek, kalamar kemiği, akvaryum silecek mıknatısı.',
      color: 'border-emerald-500/30 bg-emerald-950/5 hover:bg-emerald-950/15',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      items: [
        { name: 'Gaga Taşlı Doğal Ahşap Tünek', category: 'bird' as PetCategory, price: 75, icon: 'ToyBrick', soundType: 'chirp' as const },
        { name: 'Kalamar Kemiği Gelişim Seti', category: 'bird' as PetCategory, price: 40, icon: 'Feather', soundType: 'chirp' as const },
        { name: 'Akvaryum Silecek Mıknatısı', category: 'fish' as PetCategory, price: 130, icon: 'Waves', soundType: 'bubble' as const },
        { name: 'Dekoratif Akvaryum Şatosu', category: 'fish' as PetCategory, price: 290, icon: 'Home', soundType: 'bubble' as const },
      ]
    }
  ];

  // Helper parser for bulk lines
  const parseBulkLine = (line: string) => {
    // Clean up currency symbols (TL, ₺) and whitespace
    const cleanLine = line.replace(/[tT][lL]|₺/g, '').trim();
    if (!cleanLine) return null;

    // Split by common separators: - or : or ,
    const separators = ['-', ':', ','];
    for (const sep of separators) {
      if (cleanLine.includes(sep)) {
        const parts = cleanLine.split(sep);
        const priceStr = parts.pop()?.trim() || '';
        const nameStr = parts.join(sep).trim();
        const priceVal = parseFloat(priceStr);
        if (nameStr && !isNaN(priceVal) && priceVal > 0) {
          return { name: nameStr, price: Math.round(priceVal) };
        }
      }
    }

    // Fallback split by last space followed by a number
    const lastSpaceIdx = cleanLine.lastIndexOf(' ');
    if (lastSpaceIdx !== -1) {
      const nameStr = cleanLine.substring(0, lastSpaceIdx).trim();
      const priceStr = cleanLine.substring(lastSpaceIdx + 1).trim();
      const priceVal = parseFloat(priceStr);
      if (nameStr && !isNaN(priceVal) && priceVal > 0) {
        return { name: nameStr, price: Math.round(priceVal) };
      }
    }

    return null;
  };

  // Get active parsed items from bulk text
  const getParsedBulkItems = () => {
    const lines = bulkText.split('\n');
    const results: { name: string; price: number; category: PetCategory; icon: string; soundType: any }[] = [];
    
    lines.forEach((line) => {
      const parsed = parseBulkLine(line);
      if (parsed) {
        // Intelligently guess category from name
        const lowerName = parsed.name.toLowerCase();
        let guessedCat: PetCategory = bulkCategory;
        let guessedIcon = 'Package';
        let guessedSound: any = 'click';

        if (lowerName.includes('kedi') || lowerName.includes('mama') && lowerName.includes('kedi') || lowerName.includes('kum') || lowerName.includes('miyav')) {
          guessedCat = 'cat';
          guessedIcon = 'Fish';
          guessedSound = 'meow';
        } else if (lowerName.includes('köpek') || lowerName.includes('hav') || lowerName.includes('tasma') || lowerName.includes('kemik')) {
          guessedCat = 'dog';
          guessedIcon = 'Bone';
          guessedSound = 'bark';
        } else if (lowerName.includes('kuş') || lowerName.includes('kafes') || lowerName.includes('yem') && lowerName.includes('kuş') || lowerName.includes('ötüş')) {
          guessedCat = 'bird';
          guessedIcon = 'Feather';
          guessedSound = 'chirp';
        } else if (lowerName.includes('balık') || lowerName.includes('akvaryum') || lowerName.includes('yem') && lowerName.includes('balık') || lowerName.includes('su')) {
          guessedCat = 'fish';
          guessedIcon = 'Waves';
          guessedSound = 'bubble';
        } else {
          // Set icon based on general keywords
          if (lowerName.includes('oyuncak')) guessedIcon = 'Smile';
          else if (lowerName.includes('şampuan') || lowerName.includes('ilaç') || lowerName.includes('damla')) guessedIcon = 'Droplet';
          else if (lowerName.includes('kuaför') || lowerName.includes('traş') || lowerName.includes('makas')) guessedIcon = 'Scissors';
        }

        results.push({
          name: parsed.name,
          price: parsed.price,
          category: guessedCat,
          icon: guessedIcon,
          soundType: guessedSound,
        });
      }
    });

    return results;
  };

  const handleAIGenerateImage = () => {
    if (!name.trim()) {
      alert("Yapay zeka ile görsel üretmek için lütfen önce 'Ürün Adı' kısmını doldurun.");
      return;
    }
    sounds.playClick();
    setIsGeneratingImage(true);
    
    // Simulate high-tech AI image generation
    setTimeout(() => {
      const nameLower = name.toLowerCase();
      let selectedUrl = '';

      // Curated collection of amazing royalty-free pet product photos:
      const catFood = [
        'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1608454367599-c133fcabfb65?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=500&auto=format&fit=crop&q=80'
      ];
      const catToys = [
        'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=500&auto=format&fit=crop&q=80'
      ];
      const dogFood = [
        'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1535268647977-a403b69df7fd?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=500&auto=format&fit=crop&q=80'
      ];
      const dogToys = [
        'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&auto=format&fit=crop&q=80'
      ];
      const birdImages = [
        'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=500&auto=format&fit=crop&q=80'
      ];
      const fishImages = [
        'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=500&auto=format&fit=crop&q=80'
      ];
      const fallbackImages = [
        'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=500&auto=format&fit=crop&q=80'
      ];

      if (category === 'cat') {
        if (nameLower.includes('mam') || nameLower.includes('konserve') || nameLower.includes('malt')) {
          selectedUrl = catFood[Math.floor(Math.random() * catFood.length)];
        } else {
          selectedUrl = catToys[Math.floor(Math.random() * catToys.length)];
        }
      } else if (category === 'dog') {
        if (nameLower.includes('mam') || nameLower.includes('ödül') || nameLower.includes('sosis')) {
          selectedUrl = dogFood[Math.floor(Math.random() * dogFood.length)];
        } else {
          selectedUrl = dogToys[Math.floor(Math.random() * dogToys.length)];
        }
      } else if (category === 'bird') {
        selectedUrl = birdImages[Math.floor(Math.random() * birdImages.length)];
      } else if (category === 'fish') {
        selectedUrl = fishImages[Math.floor(Math.random() * fishImages.length)];
      } else {
        selectedUrl = fallbackImages[Math.floor(Math.random() * fallbackImages.length)];
      }

      // Add a signature unique to avoid cache
      const finalUrl = `${selectedUrl}&sig=${Math.floor(Math.random() * 100000)}`;

      setSelectedImage(finalUrl);
      setMediaGallery(prev => {
        if (prev.includes(finalUrl)) return prev;
        return [finalUrl, ...prev];
      });
      setIsGeneratingImage(false);
      sounds.playSuccess();
    }, 1500);
  };

  const startCamera = async () => {
    sounds.playClick();
    setCameraError('');
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 400, height: 400, facingMode: 'user' }
      });
      setCameraStream(stream);
      // Wait a tiny bit and hook it to the video element
      setTimeout(() => {
        const videoElement = document.getElementById('webcam-preview') as HTMLVideoElement;
        if (videoElement) {
          videoElement.srcObject = stream;
        }
      }, 300);
    } catch (err) {
      console.error(err);
      setCameraError('Kameraya erişilemedi. İzin verildiğinden emin olun.');
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setShowCamera(false);
  };

  const capturePhoto = () => {
    const videoElement = document.getElementById('webcam-preview') as HTMLVideoElement;
    const canvasElement = document.createElement('canvas');
    if (videoElement) {
      canvasElement.width = videoElement.videoWidth || 400;
      canvasElement.height = videoElement.videoHeight || 400;
      const ctx = canvasElement.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
        const dataUrl = canvasElement.toDataURL('image/jpeg');
        setSelectedImage(dataUrl);
        setMediaGallery(prev => [dataUrl, ...prev]);
        sounds.playSuccess();
        stopCamera();
      }
    }
  };

  const handleSimulatedCameraCapture = () => {
    sounds.playClick();
    // Beautiful random pet portrait simulation
    const simulatedPetPics = [
      'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&auto=format&fit=crop&q=60', // Golden dog
      'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=400&auto=format&fit=crop&q=60', // Cat with glasses
      'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=400&auto=format&fit=crop&q=60', // Kitten
      'https://images.unsplash.com/photo-1444212477490-ca407925329e?w=400&auto=format&fit=crop&q=60', // Two dogs
      'https://images.unsplash.com/photo-1544568100-847a948585b9?w=400&auto=format&fit=crop&q=60'  // Happy dog
    ];
    const picked = simulatedPetPics[Math.floor(Math.random() * simulatedPetPics.length)] + `&sig=${Math.floor(Math.random() * 100000)}`;
    setSelectedImage(picked);
    setMediaGallery(prev => [picked, ...prev]);
    sounds.playSuccess();
    setShowCamera(false);
  };

  const handleLocalImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setSelectedImage(result);
        setMediaGallery(prev => [result, ...prev]);
        sounds.playSuccess();
      }
    };
    reader.readAsDataURL(file);
  };

  // --- AI Auto-Complete & Predictions ---
  const handleAIAutoComplete = () => {
    if (!name.trim()) {
      alert("AI ile otomatik tamamlamak için lütfen önce 'Ürün Adı' kısmına bir isim girin.");
      return;
    }
    sounds.playClick();
    setIsCompletingAI(true);

    setTimeout(() => {
      const nameLower = name.toLowerCase();
      let guessedCategory: PetCategory = 'dog';
      let guessedPrice = 150;
      let guessedIcon = 'Package';
      let guessedSound: 'bark' | 'meow' | 'chirp' | 'bubble' | 'click' | 'success' = 'click';
      let guessedDesc = '';
      let guessedImages: string[] = [];

      // Heuristics for category, sound, icon, description, and images
      if (nameLower.includes('kedi') || nameLower.includes('kum') || nameLower.includes('malt') || nameLower.includes('miyav') || nameLower.includes('tırmalama') || nameLower.includes('kitten') || nameLower.includes('cat')) {
        guessedCategory = 'cat';
        guessedSound = 'meow';
        guessedIcon = nameLower.includes('kum') || nameLower.includes('mama') ? 'Package' : 'ToyBrick';
        if (nameLower.includes('mama') || nameLower.includes('konserve')) {
          guessedPrice = nameLower.includes('konserve') ? 65 : 450;
          guessedDesc = `${name.trim()}, kedilerin sağlıklı büyümesini, enerjik ve parlak tüylere sahip olmasını destekleyen vitamin ve taurin zenginleştirilmiş özel kedi mamasıdır.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1608454367599-c133fcabfb65?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=500&auto=format&fit=crop&q=80'
          ];
        } else if (nameLower.includes('kum')) {
          guessedPrice = 185;
          guessedDesc = `Mükemmel topaklaşma gücüne ve koku hapsetme teknolojisine sahip %100 doğal bentonit kedi kumu. Toz barındırmaz ve patilere yapışmaz.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&auto=format&fit=crop&q=80'
          ];
        } else {
          guessedPrice = 280;
          guessedDesc = `Kedinizin tırnak sağlığını korumak, stresi azaltmak ve evdeki mobilyaları tırmalamasını önlemek için tasarlanmış yüksek kaliteli tırmalama aksesuarı.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=500&auto=format&fit=crop&q=80'
          ];
        }
      } else if (nameLower.includes('köpek') || nameLower.includes('kemik') || nameLower.includes('tasma') || nameLower.includes('hav') || nameLower.includes('dog') || nameLower.includes('puppy')) {
        guessedCategory = 'dog';
        guessedSound = 'bark';
        guessedIcon = nameLower.includes('tasma') ? 'Award' : nameLower.includes('kemik') ? 'Bone' : 'Package';
        if (nameLower.includes('mama') || nameLower.includes('ödül')) {
          guessedPrice = nameLower.includes('ödül') ? 95 : 550;
          guessedDesc = `${name.trim()}, köpeklerin eklem gelişimini, bağışıklık sistemini ve parlak tüylerini destekleyen protein dolu dengeli köpek besinidir.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1535268647977-a403b69df7fd?w=500&auto=format&fit=crop&q=80'
          ];
        } else if (nameLower.includes('tasma')) {
          guessedPrice = 240;
          guessedDesc = `Dayanıklı paslanmaz metal aksamlı, yıkanabilir nefes alan kumaştan, göğüs yapısına tam oturan ergonomik köpek gezdirme tasması.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&auto=format&fit=crop&q=80'
          ];
        } else {
          guessedPrice = 180;
          guessedDesc = `Köpeklerin kemirme ve yakalama reflekslerini eğlenceli şekilde destekleyen, toksik içermeyen birinci sınıf kauçuktan üretilmiş köpek oyuncağı.`;
          guessedImages = [
            'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&auto=format&fit=crop&q=80',
            'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500&auto=format&fit=crop&q=80'
          ];
        }
      } else if (nameLower.includes('kuş') || nameLower.includes('yem') || nameLower.includes('kafes') || nameLower.includes('muhabbet') || nameLower.includes('kanarya') || nameLower.includes('gaga') || nameLower.includes('tünek')) {
        guessedCategory = 'bird';
        guessedSound = 'chirp';
        guessedIcon = 'Feather';
        guessedPrice = nameLower.includes('kafes') ? 350 : 85;
        guessedDesc = `Kuşların kemik, gaga ve tüy gelişimini destekleyen, severek tükettikleri ballı ve vitaminli tahıl-tohum karışımlı gurme kuş besini.`;
        guessedImages = [
          'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&auto=format&fit=crop&q=80',
          'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=500&auto=format&fit=crop&q=80'
        ];
      } else if (nameLower.includes('balık') || nameLower.includes('akvaryum') || nameLower.includes('fanus') || nameLower.includes('yem') || nameLower.includes('filtre') || nameLower.includes('su') || nameLower.includes('pul')) {
        guessedCategory = 'fish';
        guessedSound = 'bubble';
        guessedIcon = 'Waves';
        guessedPrice = nameLower.includes('akvaryum') ? 600 : 90;
        guessedDesc = `Süs balıklarının canlı renklerini güçlendiren, sindirimini kolaylaştıran ve akvaryum suyunu bulandırmayan üstün formüllü pul yem.`;
        guessedImages = [
          'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=500&auto=format&fit=crop&q=80',
          'https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=500&auto=format&fit=crop&q=80'
        ];
      } else {
        guessedCategory = 'other';
        guessedSound = 'click';
        guessedIcon = 'Package';
        guessedPrice = 145;
        guessedDesc = `Evcil dostlarımızın yaşam konforunu ve dükkanınızın ürün kalitesini artıran, özenle tedarik edilmiş pet shop ürünü.`;
        guessedImages = [
          'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500&auto=format&fit=crop&q=80',
          'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=500&auto=format&fit=crop&q=80'
        ];
      }

      setCategory(guessedCategory);
      setPrice(guessedPrice);
      setSoundType(guessedSound);
      setIcon(guessedIcon);
      setDescription(guessedDesc);
      setSelectedImage(guessedImages[0] || '');
      setImagesList(guessedImages);
      setMediaGallery(prev => {
        const unique = new Set([...guessedImages, ...prev]);
        return Array.from(unique);
      });

      setIsCompletingAI(false);
      sounds.playSuccess();
    }, 1000);
  };

  // --- OCR Scanner Methods & Database ---
  const OCR_MOCK_BARCODES = [
    { barcode: '8690123456789', name: 'N&D Tahılsız Somonlu Kedi Maması 1.5kg', price: 485, category: 'cat' as PetCategory, description: 'Seçkin somon balığı içeriğiyle yüksek proteinli tahılsız kedi maması. Parlak tüyler ve tüy yumağı kontrolü sağlar.', images: ['https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500&auto=format&fit=crop&q=80', 'https://images.unsplash.com/photo-1608454367599-c133fcabfb65?w=500&auto=format&fit=crop&q=80'] },
    { barcode: '8689876543210', name: 'Royal Canin Mini Adult Köpek Maması 800g', price: 320, category: 'dog' as PetCategory, description: 'Küçük ırk yetişkin köpeklerin tüm enerji gereksinimlerini karşılayan, lezzetli ve sindirimi kolay formül.', images: ['https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=500&auto=format&fit=crop&q=80', 'https://images.unsplash.com/photo-1535268647977-a403b69df7fd?w=500&auto=format&fit=crop&q=80'] },
    { barcode: '8697412589632', name: 'Garden Mix Sultan Papağanı Yemi 750g', price: 135, category: 'bird' as PetCategory, description: 'Egzotik kurutulmuş meyveler, kabuklu kuruyemişler ve vitaminli özel sultan papağanı tohum karışımı.', images: ['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&auto=format&fit=crop&q=80', 'https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=500&auto=format&fit=crop&q=80'] },
    { barcode: '8680147258369', name: 'Lepistes Pul Akvaryum Yemi 100g', price: 95, category: 'fish' as PetCategory, description: 'Süs balıklarının renk parlaklığını destekleyen, bağışıklığı güçlendiren ve suyu kirletmeyen pul yem.', images: ['https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?w=500&auto=format&fit=crop&q=80', 'https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=500&auto=format&fit=crop&q=80'] },
    { barcode: '8690258147369', name: 'Lüks Kadife Kedi ve Köpek Yatağı', price: 420, category: 'other' as PetCategory, description: 'Maksimum uyku ve dinlenme konforu sunan, yıkanabilir kılıflı, anti-alerjik ortopedik pet yatağı.', images: ['https://images.unsplash.com/photo-1541599540903-216a46ca1df0?w=500&auto=format&fit=crop&q=80', 'https://images.unsplash.com/photo-1568640347023-a616a30bc3bd?w=500&auto=format&fit=crop&q=80'] }
  ];

  const startOCRScanner = async () => {
    sounds.playClick();
    setOcrError('');
    setShowOCRScanner(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 500, height: 375, facingMode: 'environment' }
      });
      setOcrScannerStream(stream);
      setTimeout(() => {
        const videoElement = document.getElementById('ocr-webcam-preview') as HTMLVideoElement;
        if (videoElement) {
          videoElement.srcObject = stream;
        }
      }, 300);
    } catch (err) {
      console.error(err);
      setOcrError('Kameraya doğrudan erişilemedi. Kamera simülasyon modu veya hazır test barkodlarıyla testi başlatabilirsiniz.');
    }
  };

  const stopOCRScanner = () => {
    if (ocrScannerStream) {
      ocrScannerStream.getTracks().forEach(track => track.stop());
      setOcrScannerStream(null);
    }
    setShowOCRScanner(false);
  };

  const handleSimulatedOCRScan = (barcodeItem?: typeof OCR_MOCK_BARCODES[0]) => {
    sounds.playClick();
    setIsScanningOCR(true);
    
    setTimeout(() => {
      const picked = barcodeItem || OCR_MOCK_BARCODES[Math.floor(Math.random() * OCR_MOCK_BARCODES.length)];
      
      // Auto add to the catalog
      onAddCatalogItem({
        name: picked.name,
        category: picked.category,
        price: picked.price,
        icon: picked.category === 'cat' ? 'Fish' : picked.category === 'dog' ? 'Bone' : 'Package',
        soundType: picked.category === 'cat' ? 'meow' : picked.category === 'dog' ? 'bark' : 'click',
        image: picked.images[0],
        images: picked.images,
        description: picked.description,
      });

      // Populate form fields too
      setName(picked.name);
      setCategory(picked.category);
      setPrice(picked.price);
      setDescription(picked.description);
      setSelectedImage(picked.images[0]);
      setImagesList(picked.images);
      setMediaGallery(prev => {
        const unique = new Set([...picked.images, ...prev]);
        return Array.from(unique);
      });

      setIsScanningOCR(false);
      stopOCRScanner();
      sounds.playSuccess();
      setBulkSuccessMsg(`Kamera OCR: "${picked.name}" başarıyla algılandı ve kataloğa eklendi! 📷🎉`);
      setTimeout(() => setBulkSuccessMsg(''), 4000);
    }, 1500);
  };

  const handleSingleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();

    if (!name.trim()) {
      setSingleError('Lütfen ürün adını giriniz.');
      return;
    }

    if (price === '' || price <= 0) {
      setSingleError('Lütfen geçerli bir fiyat giriniz.');
      return;
    }

    onAddCatalogItem({
      name: name.trim(),
      category,
      price: Number(price),
      icon,
      soundType,
      image: selectedImage || undefined,
      images: imagesList.length > 0 ? imagesList : (selectedImage ? [selectedImage] : []),
      description: description.trim() || undefined,
    });

    // Reset Form
    setName('');
    setPrice('');
    setIcon('Package');
    setSoundType('click');
    setSelectedImage('');
    setImagesList([]);
    setDescription('');
    setSingleError('');
  };

  const handleBulkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();

    const itemsToAdd = getParsedBulkItems();
    if (itemsToAdd.length === 0) {
      setBulkError('Geçerli bir biçimde ürün adı ve fiyatı içeren satır bulunamadı.');
      return;
    }

    itemsToAdd.forEach((item) => {
      onAddCatalogItem(item);
    });

    setBulkSuccessMsg(`${itemsToAdd.length} adet ürün başarıyla dükkan kataloğuna eklendi! 🎉`);
    setBulkText('');
    setBulkError('');
    sounds.playSuccess();

    setTimeout(() => {
      setBulkSuccessMsg('');
    }, 4000);
  };

  const handleAddPresetBundle = (bundle: typeof PRESETS_BUNDLES[0]) => {
    sounds.playClick();
    
    bundle.items.forEach((item) => {
      onAddCatalogItem({
        name: item.name,
        category: item.category,
        price: item.price,
        icon: item.icon,
        soundType: item.soundType,
      });
    });

    sounds.playSuccess();
    setBulkSuccessMsg(`"${bundle.title}" içerisindeki ${bundle.items.length} ürün başarıyla eklendi! 🎉`);
    
    setTimeout(() => {
      setBulkSuccessMsg('');
    }, 4000);
  };

  const handleGenerateMatrix = () => {
    sounds.playClick();
    if (selectedBrands.length === 0 || selectedFormulas.length === 0 || selectedFlavors.length === 0) {
      setBulkError('Lütfen en az bir Marka, Formül ve Lezzet seçiniz.');
      return;
    }

    let addedCount = 0;
    selectedBrands.forEach((brand) => {
      let brandMult = 1.0;
      if (brand === 'N&D') brandMult = 1.55;
      else if (brand === 'Pro Plan') brandMult = 1.35;
      else if (brand === 'Royal Canin') brandMult = 1.3;
      else if (brand === 'Peritas') brandMult = 0.95;
      else if (brand === 'Juno') brandMult = 0.8;
      else if (brand === 'Rico') brandMult = 0.75;

      selectedFormulas.forEach((formula) => {
        let formulaAdd = 0;
        if (formula === 'Yavru') formulaAdd = 15;
        else if (formula === 'Kısırlaştırılmış') formulaAdd = 30;

        selectedFlavors.forEach((flavor) => {
          let flavorAdd = 0;
          if (flavor === 'Somonlu') flavorAdd = 20;
          else if (flavor === 'Kuzulu') flavorAdd = 15;
          else if (flavor === 'Ördekli') flavorAdd = 25;

          const calculatedPrice = Math.round(matrixBasePrice * brandMult + formulaAdd + flavorAdd);
          const catSuffix = matrixCategory === 'cat' ? 'Kedi Maması' : 'Köpek Maması';
          const itemName = `${brand} ${formula} ${flavor} ${catSuffix}`;
          const itemIcon = matrixCategory === 'cat' ? 'Fish' : 'Bone';
          const itemSound = matrixCategory === 'cat' ? 'meow' : 'bark';

          onAddCatalogItem({
            name: itemName,
            category: matrixCategory,
            price: calculatedPrice,
            icon: itemIcon,
            soundType: itemSound as any,
          });
          addedCount++;
        });
      });
    });

    sounds.playSuccess();
    setBulkSuccessMsg(`Akıllı Varyasyon: ${addedCount} adet ürün başarıyla dükkan kataloğuna eklendi! 🚀`);
    setBulkError('');
    setTimeout(() => setBulkSuccessMsg(''), 5000);
  };

  const handleGenerateSizes = () => {
    sounds.playClick();
    if (!sizeBaseName.trim()) {
      setBulkError('Lütfen bir temel ürün adı giriniz.');
      return;
    }
    if (selectedSizes.length === 0) {
      setBulkError('Lütfen en az bir Beden seçiniz.');
      return;
    }

    let addedCount = 0;
    selectedSizes.forEach((size) => {
      let sizeMult = 1.0;
      if (size === 'S') sizeMult = 0.85;
      else if (size === 'M') sizeMult = 1.0;
      else if (size === 'L') sizeMult = 1.15;
      else if (size === 'XL') sizeMult = 1.3;

      const calculatedPrice = Math.round(sizeBasePrice * sizeMult);
      const itemName = `${sizeBaseName.trim()} - ${size}`;
      const itemIcon = sizeCategory === 'dog' ? 'Award' : 'Heart';
      const itemSound = sizeCategory === 'dog' ? 'bark' : 'click';

      onAddCatalogItem({
        name: itemName,
        category: sizeCategory,
        price: calculatedPrice,
        icon: itemIcon,
        soundType: itemSound as any,
      });
      addedCount++;
    });

    sounds.playSuccess();
    setBulkSuccessMsg(`Boyut Varyasyonu: ${addedCount} farklı bedende ürün başarıyla dükkan kataloğuna eklendi! 📏`);
    setBulkError('');
    setTimeout(() => setBulkSuccessMsg(''), 5000);
  };

  const handleGenerateSelectedEssentials = () => {
    sounds.playClick();
    if (selectedEssentials.length === 0) {
      setBulkError('Lütfen listeden en az bir ürün seçiniz.');
      return;
    }

    let addedCount = 0;
    ESSENTIAL_PRODUCTS.forEach((prod) => {
      if (selectedEssentials.includes(prod.id)) {
        onAddCatalogItem({
          name: prod.name,
          category: prod.category,
          price: prod.price,
          icon: prod.icon,
          soundType: prod.soundType,
        });
        addedCount++;
      }
    });

    sounds.playSuccess();
    setBulkSuccessMsg(`Hazır Markalar: ${addedCount} adet dükkan demirbaşı ürün başarıyla eklendi! 🛍️`);
    setBulkError('');
    setTimeout(() => setBulkSuccessMsg(''), 5000);
  };

  // --- File Drop & Parse Handlers (CSV & Excel) ---
  const handleFileDrop = (file: File) => {
    const reader = new FileReader();
    const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');

    if (isExcel) {
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const json = XLSX.utils.sheet_to_json(worksheet) as any[];
          processImportedRows(json);
        } catch (err: any) {
          setBulkError('Excel dosyası çözümlenirken hata oluştu: ' + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    } else if (file.name.endsWith('.csv') || file.type === 'text/csv' || file.type === 'application/vnd.ms-excel') {
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const rows = parseCSVText(text);
          processImportedRows(rows);
        } catch (err: any) {
          setBulkError('CSV dosyası çözümlenirken hata oluştu: ' + err.message);
        }
      };
      reader.readAsText(file);
    } else {
      setBulkError('Desteklenmeyen dosya formatı. Lütfen sadece .csv, .xls veya .xlsx uzantılı dosyaları yükleyin.');
    }
  };

  const parseCSVText = (text: string): any[] => {
    const lines = text.split(/\r?\n/);
    if (lines.length === 0) return [];

    const headers = splitCSVLine(lines[0]);
    const results: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const values = splitCSVLine(line);
      const row: any = {};
      headers.forEach((header, index) => {
        const cleanHeader = header.trim().replace(/^["']|["']$/g, '');
        const rawValue = values[index] !== undefined ? values[index] : '';
        row[cleanHeader] = rawValue.trim().replace(/^["']|["']$/g, '');
      });
      results.push(row);
    }
    return results;
  };

  const splitCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    const delimiter = line.includes(';') ? ';' : ',';

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"' || char === "'") {
        inQuotes = !inQuotes;
      } else if (char === delimiter && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current);
    return result;
  };

  const processImportedRows = (rows: any[]) => {
    if (!rows || rows.length === 0) {
      setBulkError('Dosyada geçerli ürün satırı bulunamadı.');
      return;
    }

    let addedCount = 0;
    const errors: string[] = [];

    const findValue = (row: any, searchKeys: string[]) => {
      const rowKeys = Object.keys(row);
      for (const k of rowKeys) {
        const cleanK = k.toLowerCase().trim();
        if (searchKeys.includes(cleanK)) {
          return row[k];
        }
      }
      return null;
    };

    rows.forEach((row, index) => {
      const rawName = findValue(row, ['adı', 'ad', 'ürün', 'ürün adı', 'urun', 'name', 'title', 'product']);
      const rawPrice = findValue(row, ['fiyat', 'fiyatı', 'tutar', 'price', 'amount']);
      const rawCategory = findValue(row, ['kategori', 'category', 'type', 'sınıf', 'tür']);
      const rawIcon = findValue(row, ['ikon', 'icon']);
      const rawSound = findValue(row, ['ses', 'sound', 'soundtype']);

      if (!rawName) {
        errors.push(`Satır ${index + 2}: Ürün adı bulunamadı.`);
        return;
      }

      const price = parseFloat(String(rawPrice).replace(',', '.').replace(/[^0-9.]/g, ''));
      if (isNaN(price) || price <= 0) {
        errors.push(`Satır ${index + 2} (${rawName}): Geçersiz fiyat (${rawPrice}).`);
        return;
      }

      let category: PetCategory = 'other';
      if (rawCategory) {
        const catLower = String(rawCategory).toLowerCase();
        if (catLower.includes('ked') || catLower === 'cat') category = 'cat';
        else if (catLower.includes('köp') || catLower.includes('kop') || catLower === 'dog') category = 'dog';
        else if (catLower.includes('kuş') || catLower.includes('kus') || catLower === 'bird') category = 'bird';
        else if (catLower.includes('bal') || catLower === 'fish') category = 'fish';
      } else {
        const nameLower = String(rawName).toLowerCase();
        if (nameLower.includes('kedi') || nameLower.includes('kitten')) category = 'cat';
        else if (nameLower.includes('köpek') || nameLower.includes('dog') || nameLower.includes('puppy')) category = 'dog';
        else if (nameLower.includes('kuş') || nameLower.includes('yem') || nameLower.includes('papağan')) category = 'bird';
        else if (nameLower.includes('balık') || nameLower.includes('yem') || nameLower.includes('akvaryum')) category = 'fish';
      }

      let icon = String(rawIcon || '').trim();
      if (!icon) {
        if (category === 'cat') icon = 'Fish';
        else if (category === 'dog') icon = 'Bone';
        else if (category === 'bird') icon = 'Feather';
        else if (category === 'fish') icon = 'Waves';
        else icon = 'Package';
      }

      let soundType: any = 'click';
      if (rawSound) {
        const sndLower = String(rawSound).toLowerCase();
        if (sndLower === 'meow' || sndLower === 'miyav') soundType = 'meow';
        else if (sndLower === 'bark' || sndLower === 'hav') soundType = 'bark';
        else if (sndLower === 'chirp' || sndLower === 'cik') soundType = 'chirp';
        else if (sndLower === 'bubble' || sndLower === 'baloncuk') soundType = 'bubble';
        else if (sndLower === 'success' || sndLower === 'başarı') soundType = 'success';
      } else {
        if (category === 'cat') soundType = 'meow';
        else if (category === 'dog') soundType = 'bark';
        else if (category === 'bird') soundType = 'chirp';
        else if (category === 'fish') soundType = 'bubble';
      }

      onAddCatalogItem({
        name: String(rawName).trim(),
        category,
        price,
        icon,
        soundType,
      });
      addedCount++;
    });

    if (addedCount > 0) {
      sounds.playSuccess();
      setBulkSuccessMsg(`Dosyadan ${addedCount} adet ürün başarıyla kataloğa eklendi! 📥`);
      setBulkError(errors.length > 0 ? `Bazı satırlarda hata oluştu (${errors.length} adet): \n` + errors.slice(0, 5).join('\n') : '');
    } else {
      setBulkError('Hiçbir ürün eklenemedi. Hatalar:\n' + errors.join('\n'));
    }
  };

  const downloadSampleTemplate = () => {
    sounds.playClick();
    const csvContent = 
      "Ürün Adı,Fiyatı,Kategori,İkon,Ses\n" +
      "N&D Yavru Somonlu Kedi Maması (1.5kg),320,Kedi,Fish,meow\n" +
      "Pro Plan Yetişkin Kısırlaştırılmış Ördekli Kedi Maması,340,Kedi,Fish,meow\n" +
      "Rico Göğüs Tasması Kırmızı S Beden,160,Köpek,Award,bark\n" +
      "GimCat Anti-Hairball Kedi Macunu,185,Kedi,Droplet,meow\n" +
      "Garden Mix Sultan Papağanı Yemi,135,Kuş,Feather,chirp\n" +
      "Bioxic Kedi Kumu Koku Giderici Toz,120,Kedi,Waves,bubble\n" +
      "Akvaryum Süs Mercanı,95,Balık,Waves,bubble";

    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "pati_petshop_katalog_sablon.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredCatalog = catalog.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCategoryBadge = (cat: PetCategory) => {
    switch (cat) {
      case 'cat': return { emoji: '🐱', text: 'Kedi', style: 'border-pink-500/40 text-pink-400 bg-pink-950/10' };
      case 'dog': return { emoji: '🐶', text: 'Köpek', style: 'border-brand-orange/40 text-brand-orange bg-brand-orange/10' };
      case 'bird': return { emoji: '🐦', text: 'Kuş', style: 'border-emerald-500/40 text-emerald-400 bg-emerald-950/10' };
      case 'fish': return { emoji: '🐟', text: 'Balık', style: 'border-sky-500/40 text-sky-400 bg-sky-950/10' };
      default: return { emoji: '🐾', text: 'Diğer', style: 'border-indigo-500/40 text-indigo-400 bg-indigo-950/10' };
    }
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 items-start">
      {/* Add Product Form Column - occupies 5 cols */}
      <div className="lg:col-span-5 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40">
        
        {/* Quick Tab Header */}
        <div className="mb-5 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
              <LucideIcon name="Sparkles" size={16} />
            </div>
            <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
              Ürün Ekleme Sihirbazı
            </h3>
          </div>

          {/* Action Tabs */}
          <div className="grid grid-cols-5 gap-0.5 bg-[#121212] p-1 rounded-xs border border-art-border/40">
            <button
              type="button"
              onClick={() => { sounds.playClick(); setActiveTab('single'); }}
              className={`py-1.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeTab === 'single'
                  ? 'bg-brand-orange text-black font-black'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Tekli
            </button>
            <button
              type="button"
              onClick={() => { sounds.playClick(); setActiveTab('bulk'); }}
              className={`py-1.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeTab === 'bulk'
                  ? 'bg-brand-orange text-black font-black'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Toplu
            </button>
            <button
              type="button"
              onClick={() => { sounds.playClick(); setActiveTab('preset'); }}
              className={`py-1.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeTab === 'preset'
                  ? 'bg-brand-orange text-black font-black'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Paketler
            </button>
            <button
              type="button"
              onClick={() => { sounds.playClick(); setActiveTab('smart'); }}
              className={`py-1.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeTab === 'smart'
                  ? 'bg-brand-orange text-black font-black'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Sihirbaz
            </button>
            <button
              type="button"
              onClick={() => { sounds.playClick(); setActiveTab('import'); }}
              className={`py-1.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeTab === 'import'
                  ? 'bg-brand-orange text-black font-black'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Dosya Yükle
            </button>
          </div>
        </div>

        {/* Dynamic Success notifications across all tabs */}
        {bulkSuccessMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 rounded-xs bg-emerald-950/30 border border-emerald-900/50 p-3 text-xs font-bold text-emerald-400 flex items-center gap-1.5"
          >
            <LucideIcon name="CheckCircle" size={14} />
            <span>{bulkSuccessMsg}</span>
          </motion.div>
        )}

        {/* TAB 1: Single Product Form */}
        {activeTab === 'single' && (
          <form onSubmit={handleSingleSubmit} className="flex flex-col gap-5">
            {/* Kamera ile Tara (OCR) banner */}
            <div className="bg-[#1c1c1c]/50 border border-brand-orange/20 rounded-xs p-3 flex items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-2">
                <div className="bg-brand-orange/10 p-2 rounded-full border border-brand-orange/30 text-brand-orange animate-pulse">
                  <LucideIcon name="Camera" size={14} />
                </div>
                <div>
                  <h4 className="text-[10px] font-black uppercase tracking-wider text-white">Ambalaj / Barkod Okutucu (OCR)</h4>
                  <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mt-0.5">Kamera ile taratıp otomatik kaydedin</p>
                </div>
              </div>
              <button
                type="button"
                onClick={startOCRScanner}
                className="h-8 px-3 rounded-xs bg-brand-orange/20 hover:bg-brand-orange/30 border border-brand-orange/40 text-brand-orange text-[9px] font-black uppercase tracking-wider cursor-pointer transition-all flex items-center gap-1.5"
              >
                <LucideIcon name="Scan" size={11} />
                <span>Kamera ile Tara</span>
              </button>
            </div>

            {/* Product Name & AI Complete Button Row */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
                  Ürün Adı *
                </label>
                <button
                  type="button"
                  onClick={handleAIAutoComplete}
                  disabled={isCompletingAI || !name.trim()}
                  className={`text-[9px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all ${
                    isCompletingAI
                      ? 'text-amber-500 animate-pulse'
                      : !name.trim()
                      ? 'text-gray-600 cursor-not-allowed opacity-55'
                      : 'text-brand-orange hover:text-white hover:underline'
                  }`}
                >
                  <LucideIcon name="Sparkles" size={11} />
                  <span>{isCompletingAI ? 'AI Düşünüyor...' : 'AI ile Otomatik Tamamla'}</span>
                </button>
              </div>
              <input
                type="text"
                placeholder="Örn: Premium Tavuklu Kedi Maması"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none px-0 py-2.5 text-sm font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
              />
            </div>

            {/* Category */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
                Kategori
              </label>
              <div className="mt-2 grid grid-cols-5 gap-1.5">
                {(['dog', 'cat', 'bird', 'fish', 'other'] as PetCategory[]).map((cat) => {
                  const isSelected = category === cat;
                  const badge = getCategoryBadge(cat);
                  return (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => {
                        sounds.playClick();
                        setCategory(cat);
                      }}
                      className={`flex flex-col items-center justify-center rounded-xs py-2 px-1 border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                          : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300 hover:border-gray-700'
                      }`}
                    >
                      <span className="text-lg leading-none">{badge.emoji}</span>
                      <span className="mt-1 text-[9px] font-bold uppercase tracking-wider">{badge.text}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
                Birim Satış Fiyatı (₺) *
              </label>
              <div className="relative mt-1">
                <span className="absolute left-0 top-1/2 -translate-y-1/2 font-bold text-brand-orange text-sm">
                  ₺
                </span>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  placeholder="0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none pl-5 pr-0 py-2 text-sm font-mono font-bold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
                />
              </div>
            </div>

            {/* Icon Selector */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange mb-2 block">
                Görsel Simge Seçin
              </label>
              <div className="grid grid-cols-6 gap-1.5 max-h-[110px] overflow-y-auto p-1 border border-art-border rounded-xs bg-[#121212] scrollbar-none">
                {PRESET_ICONS.map((ico) => {
                  const isSelected = icon === ico;
                  return (
                    <button
                      type="button"
                      key={ico}
                      onClick={() => {
                        sounds.playClick();
                        setIcon(ico);
                      }}
                      className={`flex h-8 items-center justify-center rounded-xs border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-brand-orange bg-[#222] text-brand-orange'
                          : 'border-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      <LucideIcon name={ico} size={16} />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sound Selector */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange mb-2 block">
                Dokunma Ses Efekti
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {PRESET_SOUNDS.map((snd) => {
                  const isSelected = soundType === snd.key;
                  return (
                    <button
                      type="button"
                      key={snd.key}
                      onClick={() => {
                        // Trigger preview sound
                        if (snd.key === 'bark') sounds.playBark();
                        else if (snd.key === 'meow') sounds.playMeow();
                        else if (snd.key === 'chirp') sounds.playChirp();
                        else if (snd.key === 'bubble') sounds.playBubble();
                        else if (snd.key === 'success') sounds.playSuccess();
                        else sounds.playClick();
                        setSoundType(snd.key as any);
                      }}
                      className={`rounded-xs border py-2 px-2 text-left text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                        isSelected
                          ? 'border-brand-orange bg-[#222] text-brand-orange'
                          : 'border-art-border bg-transparent text-gray-400 hover:text-gray-300'
                      }`}
                    >
                      {snd.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* --- Ürün Görseli Seçenekleri (Yapay Zeka, Kamera, Dosya) --- */}
            <div className="border border-art-border/40 rounded-xs p-4 bg-[#111]/30">
              <div className="flex items-center justify-between mb-3">
                <label className="text-[10px] font-black uppercase tracking-widest text-brand-orange">
                  Ürün Görseli
                </label>
                <button
                  type="button"
                  onClick={() => { sounds.playClick(); setShowGallery(true); }}
                  className="text-[9px] font-black uppercase tracking-wider text-brand-orange hover:underline cursor-pointer flex items-center gap-1"
                >
                  <LucideIcon name="Image" size={11} />
                  <span>Görsel Galerisi ({mediaGallery.length})</span>
                </button>
              </div>

              {/* Image Preview or Selector */}
              <div className="flex gap-3 items-center">
                <div className="relative w-20 h-20 rounded-xs border border-art-border bg-[#1c1c1c] flex items-center justify-center overflow-hidden flex-shrink-0 group">
                  {selectedImage ? (
                    <>
                      <img
                        src={selectedImage}
                        alt="Ürün Önizleme"
                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <button
                        type="button"
                        onClick={() => { sounds.playClick(); setSelectedImage(''); }}
                        className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex items-center justify-center text-rose-500 font-bold text-[9px] uppercase tracking-wider transition-opacity cursor-pointer"
                      >
                        Kaldır
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center p-2 text-gray-600">
                      <LucideIcon name="Camera" size={18} className="mb-1" />
                      <span className="text-[7px] font-bold uppercase tracking-widest">Görsel Yok</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 flex flex-col gap-2">
                  {/* AI Generate Button */}
                  <button
                    type="button"
                    onClick={handleAIGenerateImage}
                    disabled={isGeneratingImage || !name.trim()}
                    className={`h-8 px-3 rounded-xs text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      isGeneratingImage
                        ? 'bg-amber-950/40 text-amber-500 border border-amber-900/40 cursor-wait'
                        : !name.trim()
                        ? 'bg-transparent border border-art-border text-gray-600 cursor-not-allowed opacity-55'
                        : 'bg-brand-orange text-black hover:bg-brand-orange/95 shadow-md shadow-brand-orange/5'
                    }`}
                  >
                    {isGeneratingImage ? (
                      <>
                        <div className="w-3 h-3 border-2 border-brand-orange border-t-transparent rounded-full animate-spin" />
                        <span>AI Hayal Ediyor...</span>
                      </>
                    ) : (
                      <>
                        <LucideIcon name="Sparkles" size={11} />
                        <span>AI ile Görsel Üret</span>
                      </>
                    )}
                  </button>

                  <div className="grid grid-cols-2 gap-1.5">
                    {/* Camera Capture Trigger */}
                    <button
                      type="button"
                      onClick={startCamera}
                      className="h-8 rounded-xs border border-art-border bg-transparent hover:border-brand-orange/60 text-gray-300 hover:text-white text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <LucideIcon name="Camera" size={11} />
                      <span>Kamera</span>
                    </button>

                    {/* Local Image Upload */}
                    <button
                      type="button"
                      onClick={() => {
                        const fileInput = document.getElementById('catalog-item-image-file');
                        fileInput?.click();
                      }}
                      className="h-8 rounded-xs border border-art-border bg-transparent hover:border-brand-orange/60 text-gray-300 hover:text-white text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <LucideIcon name="Upload" size={11} />
                      <span>Yükle</span>
                      <input
                        type="file"
                        id="catalog-item-image-file"
                        className="hidden"
                        accept="image/*"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            handleLocalImageUpload(e.target.files[0]);
                          }
                        }}
                      />
                    </button>
                  </div>
                </div>
              </div>
              {!name.trim() && (
                <p className="text-[7.5px] font-bold text-gray-600 mt-2 uppercase tracking-wider">
                  * AI ile görsel üretmek için önce ürün adı yazın.
                </p>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
                Ürün Açıklaması (Seçimli)
              </label>
              <textarea
                placeholder="Örn: Somon balıklı, yüksek proteinli ve sindirimi kolay premium kedi maması..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                className="mt-1 w-full bg-transparent border border-art-border rounded-xs p-2.5 text-xs font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all min-h-[50px]"
              />
            </div>

            {/* Additional Carousel Images */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange block mb-2">
                Döner Galeri / Carousel Görselleri ({imagesList.length})
              </label>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {imagesList.map((imgUrl, idx) => (
                  <div key={idx} className="relative w-14 h-14 rounded-xs border border-art-border bg-[#1c1c1c] flex-shrink-0 group overflow-hidden">
                    <img src={imgUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <button
                      type="button"
                      onClick={() => {
                        sounds.playClick();
                        setImagesList(prev => prev.filter((_, i) => i !== idx));
                      }}
                      className="absolute inset-0 bg-rose-950/80 opacity-0 group-hover:opacity-100 flex items-center justify-center text-rose-400 font-bold text-[8px] cursor-pointer"
                    >
                      Sil
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    const url = prompt("Galeriye eklemek istediğiniz ek görsel URL'sini girin:");
                    if (url) {
                      setImagesList(prev => [...prev, url]);
                    }
                  }}
                  className="w-14 h-14 rounded-xs border border-dashed border-art-border flex flex-col items-center justify-center text-gray-500 hover:text-brand-orange hover:border-brand-orange/60 transition-all cursor-pointer bg-black/20"
                >
                  <LucideIcon name="Plus" size={14} />
                  <span className="text-[7.5px] font-bold uppercase mt-0.5">Ekle</span>
                </button>
              </div>
            </div>

            {singleError && (
              <div className="rounded-xs bg-rose-950/30 border border-rose-900/50 p-3 text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <LucideIcon name="AlertCircle" size={14} />
                <span>{singleError}</span>
              </div>
            )}

            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3.5 text-xs font-black uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <LucideIcon name="Plus" size={14} />
              <span>Kataloğa Ekle</span>
            </motion.button>
          </form>
        )}

        {/* TAB 2: Bulk Paste Line Importer */}
        {activeTab === 'bulk' && (
          <form onSubmit={handleBulkSubmit} className="flex flex-col gap-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
                  Ürün Listesi (Her Satıra Bir Ürün)
                </label>
                <span className="text-[8px] font-extrabold uppercase tracking-widest text-gray-500">
                  Biçim: İsim - Fiyat
                </span>
              </div>
              <textarea
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                rows={5}
                placeholder="Örnek:&#10;Kedi Tırmalama Ağacı - 480&#10;Yaş Köpek Maması - 65 TL&#10;Kuş Krakeri - 25&#10;Akvaryum Süsü: 120"
                className="w-full bg-[#121212] border border-art-border rounded-xs p-3 text-xs font-mono font-bold text-gray-300 focus:border-brand-orange focus:outline-none min-h-[140px]"
              />
            </div>

            {/* Default Category */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange mb-1.5 block">
                Varsayılan Kategori (Kelime Eşleşmezse)
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {(['dog', 'cat', 'bird', 'fish', 'other'] as PetCategory[]).map((cat) => {
                  const isSelected = bulkCategory === cat;
                  const badge = getCategoryBadge(cat);
                  return (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => {
                        sounds.playClick();
                        setBulkCategory(cat);
                      }}
                      className={`flex flex-col items-center justify-center rounded-xs py-2 px-1 border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                          : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      <span className="text-base leading-none">{badge.emoji}</span>
                      <span className="mt-0.5 text-[8px] font-bold uppercase tracking-wider">{badge.text}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Real-time Parsed Items Preview */}
            {getParsedBulkItems().length > 0 && (
              <div className="bg-black/40 rounded-xs border border-art-border/30 p-3 max-h-[120px] overflow-y-auto scrollbar-none">
                <p className="text-[8px] font-black uppercase tracking-widest text-brand-orange mb-2">
                  ✓ Algılanan Ürünler Önizleme ({getParsedBulkItems().length}):
                </p>
                <div className="flex flex-col gap-1">
                  {getParsedBulkItems().map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-[10px] font-semibold text-gray-300 border-b border-art-border/15 pb-1">
                      <span className="truncate">
                        {getCategoryBadge(item.category).emoji} {item.name}
                      </span>
                      <span className="font-mono text-brand-orange shrink-0">₺{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {bulkError && (
              <div className="rounded-xs bg-rose-950/30 border border-rose-900/50 p-2 text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <LucideIcon name="AlertCircle" size={14} />
                <span>{bulkError}</span>
              </div>
            )}

            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3.5 text-xs font-black uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <LucideIcon name="Check" size={14} />
              <span>Hepsini Kataloğa İthal Et</span>
            </motion.button>
          </form>
        )}

        {/* TAB 3: Preset Packages List */}
        {activeTab === 'preset' && (
          <div className="flex flex-col gap-4">
            <p className="text-[9px] font-bold uppercase tracking-wider text-gray-400 leading-normal mb-1">
              Pet dükkanınızı anında canlandırmak için tek tıkla hazır paketleri kataloğunuza ekleyin:
            </p>

            <div className="flex flex-col gap-3">
              {PRESETS_BUNDLES.map((bundle) => (
                <div
                  key={bundle.id}
                  className={`border rounded-xs p-3 transition-all duration-300 flex flex-col justify-between gap-2.5 ${bundle.color}`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs font-black text-white uppercase tracking-wider">
                        {bundle.title}
                      </h4>
                      <span className={`px-1.5 py-0.5 rounded-xs border text-[7px] font-black uppercase tracking-widest ${bundle.badgeColor}`}>
                        {bundle.items.length} Ürün
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-400 font-bold leading-relaxed mb-2.5">
                      {bundle.description}
                    </p>

                    {/* Preview of items */}
                    <div className="grid grid-cols-2 gap-1 bg-[#111]/50 border border-art-border/30 rounded-xs p-1.5">
                      {bundle.items.map((it, i) => (
                        <div key={i} className="flex items-center gap-1 text-[8px] font-bold text-gray-300 truncate">
                          <span className="shrink-0">🐾</span>
                          <span className="truncate">{it.name} ({it.price}₺)</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAddPresetBundle(bundle)}
                    className="w-full py-1.5 bg-[#111] hover:bg-black border border-art-border/60 hover:border-brand-orange text-[9px] font-black uppercase tracking-widest text-brand-orange rounded-xs cursor-pointer flex items-center justify-center gap-1.5 transition-all"
                  >
                    <LucideIcon name="DownloadCloud" size={11} />
                    <span>Paketi Kataloğa Yükle</span>
                  </motion.button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: Smart AI Generator & Variant Wizard */}
        {activeTab === 'smart' && (
          <div className="flex flex-col gap-5">
            {/* Smart Sub-Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-black/40 p-1 rounded-xs border border-art-border/30">
              <button
                type="button"
                onClick={() => { sounds.playClick(); setSmartSubTab('matrix'); }}
                className={`py-1 px-0.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer text-center ${
                  smartSubTab === 'matrix'
                    ? 'bg-[#222] text-brand-orange border border-brand-orange/40'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Marka Matrisi
              </button>
              <button
                type="button"
                onClick={() => { sounds.playClick(); setSmartSubTab('size'); }}
                className={`py-1 px-0.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer text-center ${
                  smartSubTab === 'size'
                    ? 'bg-[#222] text-brand-orange border border-brand-orange/40'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Beden / S-M-L
              </button>
              <button
                type="button"
                onClick={() => { sounds.playClick(); setSmartSubTab('essentials'); }}
                className={`py-1 px-0.5 text-[8px] font-black uppercase tracking-wider rounded-xs transition-all cursor-pointer text-center ${
                  smartSubTab === 'essentials'
                    ? 'bg-[#222] text-brand-orange border border-brand-orange/40'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Popüler Markalar
              </button>
            </div>

            {bulkError && (
              <div className="rounded-xs bg-rose-950/30 border border-rose-900/50 p-2 text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <LucideIcon name="AlertCircle" size={14} />
                <span>{bulkError}</span>
              </div>
            )}

            {/* Smart Sub-Tab 1: Matrix Variations */}
            {smartSubTab === 'matrix' && (
              <div className="flex flex-col gap-4">
                <p className="text-[9px] font-bold uppercase tracking-wider text-gray-400 leading-normal">
                  Seçtiğiniz marka, formül ve lezzet kombinasyonlarından otomatik olarak ürün kartları ve fiyatlandırmalar üretin.
                </p>

                {/* Target Category */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    1. Hayvan Türü
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setMatrixCategory('cat'); }}
                      className={`py-2 rounded-xs border text-[10px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        matrixCategory === 'cat'
                          ? 'border-pink-500/50 bg-pink-950/10 text-pink-400 font-extrabold'
                          : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      <LucideIcon name="Fish" size={12} />
                      <span>Kedi Mamaları Üret</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setMatrixCategory('dog'); }}
                      className={`py-2 rounded-xs border text-[10px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        matrixCategory === 'dog'
                          ? 'border-brand-orange bg-brand-orange/5 text-brand-orange font-extrabold'
                          : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      <LucideIcon name="Bone" size={12} />
                      <span>Köpek Mamaları Üret</span>
                    </button>
                  </div>
                </div>

                {/* Brands Selection */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    2. Markalar (Çoklu Seçim)
                  </label>
                  <div className="grid grid-cols-3 gap-1">
                    {SMART_BRANDS.map((brand) => {
                      const isSelected = selectedBrands.includes(brand);
                      return (
                        <button
                          type="button"
                          key={brand}
                          onClick={() => {
                            sounds.playClick();
                            if (isSelected) {
                              setSelectedBrands(selectedBrands.filter((b) => b !== brand));
                            } else {
                              setSelectedBrands([...selectedBrands, brand]);
                            }
                          }}
                          className={`py-1.5 rounded-xs border text-[9px] font-bold tracking-wide transition-all cursor-pointer ${
                            isSelected
                              ? 'border-brand-orange bg-[#1a1a1a] text-brand-orange font-extrabold'
                              : 'border-art-border bg-transparent text-gray-500 hover:text-gray-400'
                          }`}
                        >
                          {brand}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Formulas Selection */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    3. Formüller / Yaş Grupları
                  </label>
                  <div className="grid grid-cols-3 gap-1">
                    {SMART_FORMULAS.map((formula) => {
                      const isSelected = selectedFormulas.includes(formula);
                      return (
                        <button
                          type="button"
                          key={formula}
                          onClick={() => {
                            sounds.playClick();
                            if (isSelected) {
                              setSelectedFormulas(selectedFormulas.filter((f) => f !== formula));
                            } else {
                              setSelectedFormulas([...selectedFormulas, formula]);
                            }
                          }}
                          className={`py-1.5 rounded-xs border text-[8px] font-bold tracking-wide transition-all cursor-pointer ${
                            isSelected
                              ? 'border-brand-orange bg-[#1a1a1a] text-brand-orange font-extrabold'
                              : 'border-art-border bg-transparent text-gray-500 hover:text-gray-400'
                          }`}
                        >
                          {formula}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Flavors Selection */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    4. İçerik / Protein Lezzetleri
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {SMART_FLAVORS.map((flavor) => {
                      const isSelected = selectedFlavors.includes(flavor);
                      return (
                        <button
                          type="button"
                          key={flavor}
                          onClick={() => {
                            sounds.playClick();
                            if (isSelected) {
                              setSelectedFlavors(selectedFlavors.filter((f) => f !== flavor));
                            } else {
                              setSelectedFlavors([...selectedFlavors, flavor]);
                            }
                          }}
                          className={`py-1.5 rounded-xs border text-[9px] font-bold tracking-wide transition-all cursor-pointer ${
                            isSelected
                              ? 'border-brand-orange bg-[#1a1a1a] text-brand-orange font-extrabold'
                              : 'border-art-border bg-transparent text-gray-500 hover:text-gray-400'
                          }`}
                        >
                          {flavor}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Base Price input */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1">
                    5. Ortalama Taban Fiyat (₺)
                  </label>
                  <p className="text-[8px] text-gray-500 mb-2 leading-tight">
                    * Marka kalitesine göre (örn: N&D +%55, ProPlan +%35, Rico -%25) fiyatlar otomatik uyarlanır.
                  </p>
                  <input
                    type="number"
                    value={matrixBasePrice}
                    onChange={(e) => setMatrixBasePrice(Math.max(10, Number(e.target.value)))}
                    className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none py-1.5 text-sm font-mono font-bold text-art-light focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
                  />
                </div>

                {/* Combination Stats Alert */}
                <div className="bg-[#111] border border-art-border/30 rounded-xs p-3 flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-extrabold uppercase tracking-widest text-gray-400">
                      Üretilecek Kombinasyon:
                    </p>
                    <p className="text-xs font-black text-brand-orange mt-0.5 font-mono">
                      {selectedBrands.length} Marka × {selectedFormulas.length} Formül × {selectedFlavors.length} Lezzet
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-black text-white font-mono">
                      {selectedBrands.length * selectedFormulas.length * selectedFlavors.length}
                    </span>
                    <span className="text-[8px] font-extrabold uppercase text-gray-500 block">Yeni Ürün</span>
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleGenerateMatrix}
                  className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3 text-xs font-black uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all mt-1"
                >
                  <LucideIcon name="Settings" size={14} />
                  <span>Seçili Varyasyonları Anında Üret</span>
                </motion.button>
              </div>
            )}

            {/* Smart Sub-Tab 2: Size Variant Creator */}
            {smartSubTab === 'size' && (
              <div className="flex flex-col gap-4">
                <p className="text-[9px] font-bold uppercase tracking-wider text-gray-400 leading-normal">
                  Özellikle tasmalar, zincirler, yataklar veya kıyafetler için S, M, L, XL beden varyasyonlarını tek seferde otomatik açın.
                </p>

                {/* Base Product Name */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block">
                    Temel Ürün Adı (Beden Hariç)
                  </label>
                  <input
                    type="text"
                    placeholder="Örn: Rico Saten Göğüs Tasması"
                    value={sizeBaseName}
                    onChange={(e) => setSizeBaseName(e.target.value)}
                    className="mt-1 w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none py-2 text-sm font-semibold text-art-light focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
                  />
                </div>

                {/* Size Category */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    Kategori Sınıfı
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['dog', 'cat', 'other'] as PetCategory[]).map((cat) => {
                      const isSelected = sizeCategory === cat;
                      const badge = getCategoryBadge(cat);
                      return (
                        <button
                          type="button"
                          key={cat}
                          onClick={() => { sounds.playClick(); setSizeCategory(cat); }}
                          className={`py-1.5 rounded-xs border text-[9px] font-bold tracking-wide transition-all cursor-pointer ${
                            isSelected
                              ? 'border-brand-orange bg-[#1a1a1a] text-brand-orange font-extrabold'
                              : 'border-art-border bg-transparent text-gray-500 hover:text-gray-400'
                          }`}
                        >
                          {badge.emoji} {badge.text}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Sizes selection */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1.5">
                    Üretilecek Bedenler
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {['S', 'M', 'L', 'XL'].map((sz) => {
                      const isSelected = selectedSizes.includes(sz);
                      return (
                        <button
                          type="button"
                          key={sz}
                          onClick={() => {
                            sounds.playClick();
                            if (isSelected) {
                              setSelectedSizes(selectedSizes.filter((s) => s !== sz));
                            } else {
                              setSelectedSizes([...selectedSizes, sz]);
                            }
                          }}
                          className={`py-2 rounded-xs border text-xs font-black transition-all cursor-pointer ${
                            isSelected
                              ? 'border-brand-orange bg-brand-orange/15 text-brand-orange'
                              : 'border-art-border bg-transparent text-gray-500 hover:text-gray-400'
                          }`}
                        >
                          {sz}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Base price */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-brand-orange block mb-1">
                    M (Medium) Beden Satış Fiyatı (₺)
                  </label>
                  <p className="text-[8px] text-gray-500 mb-2 leading-tight">
                    * S beden %15 indirimli, L %15 zamlı, XL %30 zamlı olarak otomatik fiyatlandırılır.
                  </p>
                  <input
                    type="number"
                    value={sizeBasePrice}
                    onChange={(e) => setSizeBasePrice(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none py-1.5 text-sm font-mono font-bold text-art-light focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
                  />
                </div>

                {/* Size combination preview */}
                <div className="bg-[#111] border border-art-border/30 rounded-xs p-3">
                  <p className="text-[8px] font-black uppercase tracking-widest text-brand-orange mb-1.5">
                    ✓ Oluşturulacak Varyasyon Kartları:
                  </p>
                  <div className="flex flex-col gap-1">
                    {selectedSizes.map((sz) => {
                      let sizeMult = 1.0;
                      if (sz === 'S') sizeMult = 0.85;
                      else if (sz === 'M') sizeMult = 1.0;
                      else if (sz === 'L') sizeMult = 1.15;
                      else if (sz === 'XL') sizeMult = 1.3;
                      const calculatedPrice = Math.round(sizeBasePrice * sizeMult);
                      return (
                        <div key={sz} className="flex justify-between text-[10px] font-semibold text-gray-400">
                          <span>📐 {sizeBaseName || 'Ürün'} - {sz}</span>
                          <span className="font-mono text-brand-orange font-bold">₺{calculatedPrice}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleGenerateSizes}
                  className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3 text-xs font-black uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <LucideIcon name="Layers" size={14} />
                  <span>Boyut Varyasyonlarını Üret</span>
                </motion.button>
              </div>
            )}

            {/* Smart Sub-Tab 3: Essentials Checklist */}
            {smartSubTab === 'essentials' && (
              <div className="flex flex-col gap-4">
                <p className="text-[9px] font-bold uppercase tracking-wider text-gray-400 leading-normal mb-1">
                  Malt macunları, kedi kumu koku gidericileri, özel kuş yemleri ve ödül maması markalarını (GimCat, Bioxic, Garden Mix, Juno, Peritas, Rico) tek tıkla yükleyin:
                </p>

                {/* Multi-select check list */}
                <div className="flex flex-col gap-2 max-h-[250px] overflow-y-auto p-1.5 border border-art-border rounded-xs bg-[#111] scrollbar-none">
                  {ESSENTIAL_PRODUCTS.map((prod) => {
                    const isChecked = selectedEssentials.includes(prod.id);
                    const categoryBadge = getCategoryBadge(prod.category);
                    return (
                      <div
                        key={prod.id}
                        onClick={() => {
                          sounds.playClick();
                          if (isChecked) {
                            setSelectedEssentials(selectedEssentials.filter((id) => id !== prod.id));
                          } else {
                            setSelectedEssentials([...selectedEssentials, prod.id]);
                          }
                        }}
                        className={`p-2 rounded-xs border cursor-pointer transition-all flex items-start gap-2.5 ${
                          isChecked
                            ? 'border-brand-orange/40 bg-brand-orange/5'
                            : 'border-transparent bg-white/5 hover:bg-white/8 hover:border-gray-800'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          readOnly
                          className="mt-0.5 h-3.5 w-3.5 rounded border-gray-600 bg-transparent text-brand-orange focus:ring-brand-orange cursor-pointer focus:ring-1"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-black text-gray-200 truncate pr-1">
                              {prod.name}
                            </span>
                            <span className="text-[10px] font-mono text-brand-orange shrink-0 font-bold">
                              {prod.price}₺
                            </span>
                          </div>
                          <p className="text-[9px] text-gray-500 mt-0.5 truncate">
                            {prod.description}
                          </p>
                          <div className="mt-1 flex items-center gap-1.5">
                            <span className={`px-1 rounded-xs text-[7px] font-extrabold uppercase tracking-wider border ${categoryBadge.style}`}>
                              {categoryBadge.emoji} {categoryBadge.text}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="bg-[#111] border border-art-border/30 rounded-xs p-2 text-center">
                  <span className="text-[9px] font-extrabold uppercase tracking-widest text-gray-400">
                    Seçili Ürün Sayısı: <strong className="text-brand-orange text-xs font-mono font-black">{selectedEssentials.length}</strong>
                  </span>
                </div>

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleGenerateSelectedEssentials}
                  className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3 text-xs font-black uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <LucideIcon name="DownloadCloud" size={14} />
                  <span>Seçili ({selectedEssentials.length}) Demirbaş Ürünü Ekle</span>
                </motion.button>
              </div>
            )}
          </div>
        )}

        {/* Import Excel/CSV Drag & Drop */}
        {activeTab === 'import' && (
          <div className="flex flex-col gap-5">
            <p className="text-[10px] font-bold uppercase tracking-wider text-gray-400 leading-normal">
              Yüzlerce ürünü tek tek girmek yerine Excel (.xlsx, .xls) veya CSV dosyanızı buraya bırakarak saniyeler içinde toplu olarak içe aktarın.
            </p>

            {/* Drag and Drop Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => {
                setIsDragging(false);
              }}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileDrop(e.dataTransfer.files[0]);
                }
              }}
              className={`border-2 border-dashed rounded-xs p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                isDragging
                  ? 'border-brand-orange bg-brand-orange/5 scale-[1.01]'
                  : 'border-art-border hover:border-brand-orange/60 bg-[#111]/40 hover:bg-[#111]/80'
              }`}
              onClick={() => {
                const fileInput = document.getElementById('catalog-file-input');
                fileInput?.click();
              }}
            >
              <input
                type="file"
                id="catalog-file-input"
                className="hidden"
                accept=".csv,.xlsx,.xls"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileDrop(e.target.files[0]);
                  }
                }}
              />
              <div className="rounded-full bg-[#1c1c1c] p-3 text-brand-orange border border-art-border mb-3">
                <LucideIcon name="UploadCloud" size={24} className="animate-pulse" />
              </div>
              <h4 className="text-xs font-black text-gray-200 uppercase tracking-widest">
                {isDragging ? 'Dosyayı Buraya Bırakın!' : 'Dosyayı Sürükleyin veya Tıklayın'}
              </h4>
              <p className="text-[9px] text-gray-500 mt-1 uppercase tracking-widest font-bold">
                Desteklenen formatlar: .XLSX, .XLS, .CSV
              </p>
            </div>

            {/* Formatting Instructions */}
            <div className="rounded-xs border border-art-border bg-[#0f0f0f] p-4 flex flex-col gap-3">
              <div className="flex items-center gap-2 border-b border-art-border pb-2">
                <LucideIcon name="Info" size={12} className="text-brand-orange" />
                <span className="text-[9px] font-black uppercase tracking-wider text-brand-orange">
                  Dosya Sütun Formatı Nasıl Olmalı?
                </span>
              </div>

              <p className="text-[9px] text-gray-400 leading-relaxed font-semibold">
                Dosyanızın ilk satırı başlık (Header) satırı olmalıdır. Sistem aşağıdaki sütun adlarını otomatik eşleştirir:
              </p>

              <div className="grid grid-cols-2 gap-2 text-[9px] font-mono border-t border-b border-art-border/30 py-2">
                <div>
                  <strong className="text-white">Adı:</strong> <span className="text-gray-500">Ürün Adı (Zorunlu)</span>
                </div>
                <div>
                  <strong className="text-white">Fiyatı:</strong> <span className="text-gray-500">Sayısal Tutar (Zorunlu)</span>
                </div>
                <div>
                  <strong className="text-white">Kategori:</strong> <span className="text-gray-500">Kedi, Köpek, Kuş, Balık</span>
                </div>
                <div>
                  <strong className="text-white">Ses / İkon:</strong> <span className="text-gray-500">Ses & İkon (Seçimli)</span>
                </div>
              </div>

              <button
                type="button"
                onClick={downloadSampleTemplate}
                className="w-full rounded-xs bg-[#222] hover:bg-[#333] border border-art-border py-2 text-[9px] font-black uppercase tracking-wider text-gray-300 flex items-center justify-center gap-2 transition-all cursor-pointer mt-1"
              >
                <LucideIcon name="FileDown" size={12} className="text-brand-orange" />
                <span>Örnek Excel/CSV Şablonu İndir</span>
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Product List Ledger - occupies 7 cols */}
      <div className="lg:col-span-7 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col h-full min-h-[580px]">
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-art-border pb-4">
          <div className="flex items-center gap-3">
            <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
              <LucideIcon name="Package" size={16} />
            </div>
            <div>
              <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
                Kayıtlı Ürün Kataloğu
              </h3>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Kataloğunuzdaki tüm aktif kayıtlar</p>
            </div>
          </div>
          <span className="rounded-xs bg-[#222] border border-art-border px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-brand-orange self-start sm:self-auto">
            {catalog.length} Çeşit Ürün
          </span>
        </div>

        {/* Search */}
        <div className="relative mb-5">
          <span className="absolute left-0 top-1/2 -translate-y-1/2 text-brand-orange">
            <LucideIcon name="Search" size={14} />
          </span>
          <input
            type="text"
            placeholder="Ürün adı veya kategori ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none pl-6 pr-0 py-2 text-xs font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
          />
        </div>

        {/* Product Grid / Table */}
        <div className="flex-1 overflow-y-auto max-h-[400px] scrollbar-none pr-1">
          {filteredCatalog.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="mb-3 rounded-xs bg-[#222] border border-art-border p-4 text-brand-orange">
                🔍
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-gray-500">
                Arama sonucu bulunamadı
              </p>
            </div>
          ) : (
            <div className="divide-y divide-art-border/10">
              <AnimatePresence mode="popLayout">
                {filteredCatalog.map((item) => (
                  <motion.div
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    key={item.id}
                  >
                    <CatalogItemRow
                      item={item}
                      onRemove={onRemoveCatalogItem}
                      getCategoryBadge={getCategoryBadge}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* --- Kameradan Canlı Fotoğraf Çekme Modalı --- */}
      {showCamera && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-xs border border-art-border bg-art-card p-6 shadow-2xl relative">
            <button
              type="button"
              onClick={stopCamera}
              className="absolute right-4 top-4 text-gray-500 hover:text-white cursor-pointer"
            >
              <LucideIcon name="X" size={18} />
            </button>
            <h3 className="font-serif italic text-lg text-brand-orange mb-3">
              Ürün Fotoğrafı Çek
            </h3>
            
            {cameraError ? (
              <div className="rounded-xs bg-[#121212] border border-art-border p-4 mb-4 text-center">
                <p className="text-[10px] text-gray-400 font-bold mb-3">{cameraError}</p>
                <button
                  type="button"
                  onClick={handleSimulatedCameraCapture}
                  className="w-full h-9 rounded-xs bg-brand-orange text-black font-black uppercase text-[10px] tracking-wider transition-all cursor-pointer"
                >
                  Pet Stüdyo Çekimi Simüle Et (Önerilen)
                </button>
              </div>
            ) : (
              <div className="relative aspect-square w-full rounded-xs overflow-hidden bg-black border border-art-border mb-4 flex items-center justify-center">
                {cameraStream ? (
                  <video
                    id="webcam-preview"
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-6 h-6 border-2 border-brand-orange border-t-transparent rounded-full animate-spin" />
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Kamera başlatılıyor...</p>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={stopCamera}
                className="flex-1 h-10 rounded-xs border border-art-border bg-transparent hover:bg-[#222] text-gray-400 hover:text-white text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
              >
                Vazgeç
              </button>
              {cameraStream && (
                <button
                  type="button"
                  onClick={capturePhoto}
                  className="flex-1 h-10 rounded-xs bg-brand-orange hover:bg-brand-orange/90 text-black text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1"
                >
                  <LucideIcon name="Camera" size={13} />
                  <span>Fotoğrafı Çek</span>
                </button>
              )}
              {!cameraStream && !cameraError && (
                <button
                  type="button"
                  onClick={handleSimulatedCameraCapture}
                  className="flex-1 h-10 rounded-xs bg-brand-orange/15 hover:bg-brand-orange/30 text-brand-orange text-[10px] font-black uppercase tracking-wider border border-brand-orange/30 transition-all cursor-pointer"
                >
                  Hızlı Simüle Çekim
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- Görsel Galerisi Yönetim Modalı --- */}
      {showGallery && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl rounded-xs border border-art-border bg-art-card p-6 shadow-2xl relative max-h-[85vh] flex flex-col">
            <button
              type="button"
              onClick={() => { sounds.playClick(); setShowGallery(false); }}
              className="absolute right-4 top-4 text-gray-500 hover:text-white cursor-pointer"
            >
              <LucideIcon name="X" size={18} />
            </button>
            <div className="mb-4">
              <h3 className="font-serif italic text-xl text-brand-orange">
                Görsel Galerisi Yönetimi
              </h3>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-1">
                Yapay Zeka ile üretilen, kamerayla çekilen veya yüklenen tüm ürün görsellerini buradan yönetin
              </p>
            </div>

            {/* Media Grid */}
            <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 p-1 scrollbar-none">
              {/* Upload New Card inside Gallery */}
              <div
                onClick={() => {
                  const input = document.getElementById('gallery-upload-input');
                  input?.click();
                }}
                className="aspect-square rounded-xs border-2 border-dashed border-art-border hover:border-brand-orange/60 bg-[#111]/40 hover:bg-[#111]/80 flex flex-col items-center justify-center p-3 text-center cursor-pointer transition-all gap-1.5"
              >
                <input
                  type="file"
                  id="gallery-upload-input"
                  className="hidden"
                  accept="image/*"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleLocalImageUpload(e.target.files[0]);
                    }
                  }}
                />
                <LucideIcon name="PlusCircle" size={22} className="text-brand-orange" />
                <span className="text-[9px] font-black uppercase tracking-wider text-gray-400">Yeni Görsel Yükle</span>
              </div>

              {mediaGallery.map((imgUrl, index) => {
                const isCurrent = selectedImage === imgUrl;
                return (
                  <div
                    key={index}
                    className={`relative aspect-square rounded-xs border bg-black overflow-hidden group cursor-pointer transition-all ${
                      isCurrent
                        ? 'border-brand-orange ring-2 ring-brand-orange/20 scale-[0.98]'
                        : 'border-art-border hover:border-brand-orange/40'
                    }`}
                  >
                    <img
                      src={imgUrl}
                      alt={`Galeri ${index}`}
                      onClick={() => {
                        sounds.playClick();
                        setSelectedImage(imgUrl);
                        setShowGallery(false);
                      }}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />

                    {/* Delete action in gallery */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        sounds.playDelete();
                        setMediaGallery(prev => prev.filter(img => img !== imgUrl));
                        if (isCurrent) setSelectedImage('');
                      }}
                      className="absolute right-1.5 top-1.5 bg-black/70 p-1 rounded-xs border border-art-border/40 text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity hover:text-rose-300 cursor-pointer"
                      title="Görseli Sil"
                    >
                      <LucideIcon name="Trash2" size={10} />
                    </button>

                    {isCurrent && (
                      <div className="absolute left-1.5 bottom-1.5 bg-brand-orange text-black font-black text-[7px] uppercase tracking-widest px-1 py-0.2 rounded-xs">
                        Seçili
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between items-center border-t border-art-border/30 pt-4">
              <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">
                Toplam {mediaGallery.length} Görsel Mevcut
              </span>
              <button
                type="button"
                onClick={() => { sounds.playClick(); setShowGallery(false); }}
                className="h-9 px-5 rounded-xs bg-[#222] hover:bg-[#333] text-gray-300 hover:text-white text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- Kameradan Barkod/Ambalaj Okuma (OCR) Modalı --- */}
      {showOCRScanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xs border border-brand-orange/40 bg-[#0c0c0c] p-6 shadow-2xl relative flex flex-col border-t-4 border-t-brand-orange">
            <button
              type="button"
              onClick={stopOCRScanner}
              className="absolute right-4 top-4 text-gray-500 hover:text-white cursor-pointer"
            >
              <LucideIcon name="X" size={18} />
            </button>
            
            <div className="mb-4">
              <div className="flex items-center gap-2">
                <span className="text-amber-500 animate-pulse">
                  <LucideIcon name="Scan" size={18} />
                </span>
                <h3 className="font-serif italic text-xl text-brand-orange">
                  Ambalaj ve Barkod Okuyucu (OCR)
                </h3>
              </div>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-1">
                Kameranızı ambalaj ismine veya barkoda doğrultun, AI anında tanımlasın
              </p>
            </div>

            {/* Webcam video / Scanner window */}
            <div className="relative aspect-video w-full rounded-xs overflow-hidden bg-black border border-art-border mb-4 flex flex-col items-center justify-center group">
              {ocrScannerStream ? (
                <video
                  id="ocr-webcam-preview"
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-6 text-gray-600">
                  <LucideIcon name="CameraOff" size={28} className="mx-auto mb-2 text-gray-700 animate-bounce" />
                  <span className="text-[9px] font-black uppercase tracking-widest block text-brand-orange/70">
                    Kamera Önizleme Hazırlanıyor
                  </span>
                  <span className="text-[7.5px] text-gray-500 block uppercase tracking-wider mt-1 leading-normal max-w-[280px] mx-auto">
                    Nested iframe veya izin sınırlamaları nedeniyle kamera kapalıysa aşağıdaki simüle test butonlarını kullanabilirsiniz.
                  </span>
                </div>
              )}

              {/* Futuristic scanning green line overlay */}
              <div className="absolute inset-x-0 h-0.5 bg-brand-orange/80 shadow-[0_0_8px_rgba(249,115,22,0.8)] animate-[bounce_3s_infinite]" />

              {/* Status bar inside camera frame */}
              <div className="absolute bottom-2 left-2 right-2 bg-black/80 px-2.5 py-1.5 rounded-xs border border-white/5 flex items-center justify-between text-[8px] font-mono tracking-wide text-gray-400">
                <span className="flex items-center gap-1.5 font-bold uppercase">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
                  SİSTEM AKTİF
                </span>
                <span>FPS: 30 / RESOLUTION: HD</span>
              </div>
            </div>

            {/* Simulated Scanning State Indicator */}
            {isScanningOCR ? (
              <div className="bg-brand-orange/10 border border-brand-orange/40 rounded-xs p-3 text-center mb-4 animate-pulse">
                <div className="w-5 h-5 border-2 border-brand-orange border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                <p className="text-[9px] font-black uppercase text-brand-orange tracking-widest">
                  Görüntü Analiz Ediliyor, OCR Yazısı Çözümleniyor...
                </p>
              </div>
            ) : (
              <p className="text-[8px] text-gray-400 uppercase tracking-widest text-center mb-3">
                👇 Test Etmek İçin Aşağıdaki Hazır Ambalaj / Barkod Tiplerinden Birini Seçin 👇
              </p>
            )}

            {/* Test buttons representing various dog/cat packagings */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              {OCR_MOCK_BARCODES.map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isScanningOCR}
                  onClick={() => handleSimulatedOCRScan(item)}
                  className="p-2 text-left bg-white/5 hover:bg-brand-orange/10 border border-art-border hover:border-brand-orange/40 rounded-xs transition-all cursor-pointer flex flex-col justify-between h-14"
                >
                  <span className="text-[8.5px] font-black text-white truncate w-full block">
                    {item.name}
                  </span>
                  <div className="flex items-center justify-between text-[7px] font-mono text-gray-500 uppercase font-bold mt-1">
                    <span>Barkod: {item.barcode}</span>
                    <span className="text-brand-orange">{item.price}₺</span>
                  </div>
                </button>
              ))}
            </div>

            <div className="flex gap-2 border-t border-art-border/30 pt-4">
              <button
                type="button"
                onClick={stopOCRScanner}
                className="flex-1 h-9 rounded-xs border border-art-border bg-transparent hover:bg-[#222] text-gray-400 hover:text-white text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
              >
                Vazgeç / Kapat
              </button>
              <button
                type="button"
                disabled={isScanningOCR}
                onClick={() => handleSimulatedOCRScan()}
                className="flex-1 h-9 rounded-xs bg-brand-orange hover:bg-brand-orange/90 text-black text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <LucideIcon name="Scan" size={13} />
                <span>Rastgele Ambalaj Tara</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
