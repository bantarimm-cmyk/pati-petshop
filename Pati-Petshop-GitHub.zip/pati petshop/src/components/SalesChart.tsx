/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
  BarChart,
  Bar,
} from 'recharts';
import { Sale, PetCategory } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface SalesChartProps {
  sales: Sale[];
}

const CATEGORY_COLORS: Record<PetCategory, string> = {
  dog: '#FF4D00', // Brand Orange
  cat: '#ec4899', // Pink
  bird: '#10b981', // Emerald
  fish: '#0ea5e9', // Sky
  other: '#8b5cf6', // Indigo
};

const CATEGORY_LABELS: Record<PetCategory, string> = {
  dog: '🐶 Köpek',
  cat: '🐱 Kedi',
  bird: '🐦 Kuş',
  fish: '🐟 Balık',
  other: '✨ Diğer',
};

export default function SalesChart({ sales }: SalesChartProps) {
  const [timeFilter, setTimeFilter] = useState<'all' | 'weekly' | 'biweekly' | 'monthly'>('all');

  // Filter sales by date range
  const filteredSales = useMemo(() => {
    if (timeFilter === 'all') return sales;

    const now = new Date();
    const cutoff = new Date();
    if (timeFilter === 'weekly') {
      cutoff.setDate(now.getDate() - 7);
    } else if (timeFilter === 'biweekly') {
      cutoff.setDate(now.getDate() - 14);
    } else if (timeFilter === 'monthly') {
      cutoff.setDate(now.getDate() - 30);
    }

    return sales.filter((sale) => new Date(sale.createdAt) >= cutoff);
  }, [sales, timeFilter]);

  // 1. Process Trend Data (Group by date, sorting chronologically)
  const trendData = useMemo(() => {
    if (filteredSales.length === 0) return [];

    const dailyMap: Record<string, { total: number; timestamp: number }> = {};
    filteredSales.forEach((sale) => {
      const d = new Date(sale.createdAt);
      const dayKey = d.toLocaleDateString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
      });
      const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();

      if (!dailyMap[dayKey]) {
        dailyMap[dayKey] = { total: 0, timestamp: dayStart };
      }
      dailyMap[dayKey].total += sale.totalPrice;
    });

    // Convert map to chronological sorted array
    return Object.entries(dailyMap)
      .map(([date, info]) => ({ date, Ciro: info.total, timestamp: info.timestamp }))
      .sort((a, b) => a.timestamp - b.timestamp);
  }, [filteredSales]);

  // 2. Process Category Data
  const categoryData = useMemo(() => {
    if (filteredSales.length === 0) return [];

    const counts: Record<PetCategory, number> = {
      dog: 0,
      cat: 0,
      bird: 0,
      fish: 0,
      other: 0,
    };

    filteredSales.forEach((sale) => {
      counts[sale.category] = (counts[sale.category] || 0) + sale.totalPrice;
    });

    return Object.entries(counts)
      .filter(([_, value]) => value > 0)
      .map(([key, value]) => ({
        name: CATEGORY_LABELS[key as PetCategory],
        value,
        color: CATEGORY_COLORS[key as PetCategory],
      }));
  }, [filteredSales]);

  if (sales.length === 0) {
    return (
      <div className="flex h-[320px] flex-col items-center justify-center rounded-xs border border-dashed border-art-border bg-art-card text-center p-6">
        <div className="mb-3 rounded-xs bg-[#222] p-4 text-brand-orange border border-art-border animate-pulse">
          <LucideIcon name="BarChart3" size={28} />
        </div>
        <h4 className="font-serif italic text-lg text-brand-orange">Analiz Grafikleri</h4>
        <p className="mt-2 text-[10px] text-gray-500 max-w-[280px] uppercase tracking-wider font-semibold leading-relaxed">
          Satış verilerinizi girdikten sonra günlük ciro trendiniz ve kategori pasta grafiğiniz burada anlık olarak çizilecektir! 🐾
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Tarih Aralığı Filtreleme Panel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-art-card border border-art-border p-4 rounded-xs shadow-md shadow-black/30">
        <div className="flex items-center gap-2">
          <LucideIcon name="CalendarRange" size={14} className="text-brand-orange animate-pulse" />
          <span className="text-xs font-extrabold uppercase tracking-widest text-art-light">Zaman Filtresi:</span>
        </div>
        <div className="flex flex-wrap gap-1 bg-[#111] p-1 rounded-xs border border-art-border/40">
          {[
            { key: 'all', label: 'Tüm Zamanlar' },
            { key: 'weekly', label: 'Haftalık (7 Gün)' },
            { key: 'biweekly', label: '14 Günlük' },
            { key: 'monthly', label: 'Aylık (30 Gün)' },
          ].map((item) => {
            const isSelected = timeFilter === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => { sounds.playClick(); setTimeFilter(item.key as any); }}
                className={`px-3 py-1.5 text-[9px] font-extrabold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-brand-orange text-black shadow-sm font-black'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-[#1a1a1a]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* 1. Area Chart - Trend Analysis */}
      <div className="rounded-xs border border-art-border bg-art-card p-5 shadow-lg shadow-black/40 lg:col-span-7 flex flex-col">
        <div className="mb-4 flex items-center gap-3">
          <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
            <LucideIcon name="TrendingUp" size={16} />
          </div>
          <div>
            <h3 className="font-serif italic text-base text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
              Ciro Gelişimi (₺)
            </h3>
            <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Günlük bazda toplam ciro takibi</p>
          </div>
        </div>

        <div className="h-[220px] w-full flex-1">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorCiro" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF4D00" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#FF4D00" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 10, fontWeight: 600, fill: '#666666' }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 10, fontWeight: 600, fill: '#666666' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#161616',
                  border: '1px solid #242424',
                  borderRadius: '2px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
                  fontSize: '11px',
                  fontWeight: '700',
                  color: '#F5F5F5',
                }}
                formatter={(value: any) => [`₺${value}`, 'Toplam Ciro']}
              />
              <Area
                type="monotone"
                dataKey="Ciro"
                stroke="#FF4D00"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#colorCiro)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 2. Donut/Pie Chart - Category Share */}
      <div className="rounded-xs border border-art-border bg-art-card p-5 shadow-lg shadow-black/40 lg:col-span-5 flex flex-col">
        <div className="mb-4 flex items-center gap-3">
          <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
            <LucideIcon name="PieChart" size={16} />
          </div>
          <div>
            <h3 className="font-serif italic text-base text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
              Kategori Dağılımı (₺)
            </h3>
            <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Evcil hayvan türlerine göre satış payı</p>
          </div>
        </div>

        <div className="relative h-[220px] w-full flex-1 flex items-center justify-center">
          {categoryData.length === 0 ? (
            <p className="text-xs text-gray-400">Veri yok</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#161616',
                    border: '1px solid #242424',
                    borderRadius: '2px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
                    fontSize: '11px',
                    fontWeight: '700',
                    color: '#F5F5F5',
                  }}
                  formatter={(value: any) => [`₺${value}`, 'Toplam']}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  iconSize={6}
                  formatter={(value: string) => (
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  </div>
  );
}
