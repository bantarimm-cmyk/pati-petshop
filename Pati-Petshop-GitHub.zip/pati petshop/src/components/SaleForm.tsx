/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PetCategory, CatalogItem } from '../types';
import { sounds } from '../utils/sound';
import LucideIcon from './LucideIcon';

interface SaleFormProps {
  catalog: CatalogItem[];
  onAddCustomSale: (saleData: {
    productName: string;
    category: PetCategory;
    price: number;
    quantity: number;
    notes: string;
    paymentMethod: 'cash' | 'card';
  }) => void;
}

export default function SaleForm({ catalog, onAddCustomSale }: SaleFormProps) {
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState<PetCategory>('dog');
  const [price, setPrice] = useState<number | ''>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card'>('cash');
  const [error, setError] = useState('');
  const [isDropdownFocused, setIsDropdownFocused] = useState(false);
  const [isNotesDropdownOpen, setIsNotesDropdownOpen] = useState(false);
  
  // Custom quick notes state
  const [quickNotes, setQuickNotes] = useState<string[]>(() => {
    const defaultNotes = [
      'Düzenli Müşteri İndirimi',
      'Nakit Ödeme İndirimi',
      'Aşı Sonrası Ödül Maması',
      'Mama + Aksesuar Seti',
      'Pet Kuaför Rezervasyonu',
      'Sokak Hayvanları Bağışı'
    ];
    try {
      const saved = localStorage.getItem('pati_quick_notes');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return Array.from(new Set([...parsed, ...defaultNotes]));
        }
      }
    } catch (e) {
      // ignore
    }
    return defaultNotes;
  });

  const matchedItems = productName.trim()
    ? catalog.filter(item => item.name.toLowerCase().includes(productName.toLowerCase()))
    : [];

  const categories: { key: PetCategory; label: string; emoji: string; sound: () => void }[] = [
    { key: 'dog', label: 'Köpek', emoji: '🐶', sound: () => sounds.playBark() },
    { key: 'cat', label: 'Kedi', emoji: '🐱', sound: () => sounds.playMeow() },
    { key: 'bird', label: 'Kuş', emoji: '🐦', sound: () => sounds.playChirp() },
    { key: 'fish', label: 'Balık', emoji: '🐟', sound: () => sounds.playBubble() },
    { key: 'other', label: 'Diğer', emoji: '✨', sound: () => sounds.playClick() },
  ];

  const handleCategorySelect = (cat: PetCategory, soundFn: () => void) => {
    soundFn();
    setCategory(cat);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();

    if (!productName.trim()) {
      setError('Lütfen ürün veya hizmet adını giriniz.');
      return;
    }

    if (price === '' || price <= 0) {
      setError('Lütfen geçerli bir birim fiyatı giriniz (₺).');
      return;
    }

    if (quantity <= 0) {
      setError('Miktar en az 1 olmalıdır.');
      return;
    }

    // Success
    setError('');
    
    // Save note if custom and not already exists
    const trimmedNote = notes.trim();
    if (trimmedNote && !quickNotes.includes(trimmedNote)) {
      const updatedNotes = [trimmedNote, ...quickNotes].slice(0, 20); // Keep max 20 notes
      setQuickNotes(updatedNotes);
      localStorage.setItem('pati_quick_notes', JSON.stringify(updatedNotes));
    }

    onAddCustomSale({
      productName: productName.trim(),
      category,
      price: Number(price),
      quantity: Number(quantity),
      notes: trimmedNote,
      paymentMethod,
    });

    // Reset Form
    setProductName('');
    setPrice('');
    setQuantity(1);
    setNotes('');
    setPaymentMethod('cash');
    setIsNotesDropdownOpen(false);
  };

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40">
      <div className="mb-5 flex items-center gap-3">
        <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
          <LucideIcon name="PlusCircle" size={16} />
        </div>
        <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
          Özel Satış Girişi
        </h3>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        {/* Product Name */}
        <div className="relative">
          <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
            Ürün veya Hizmet Adı *
          </label>
          <input
            type="text"
            placeholder="Örn: Tırnak Kesimi, Özel Boyun Tasması"
            value={productName}
            onChange={(e) => {
              setProductName(e.target.value);
              setIsDropdownFocused(true);
            }}
            onFocus={() => setIsDropdownFocused(true)}
            onBlur={() => {
              // Delay to allow selecting a matched item before overlay unmounts
              setTimeout(() => setIsDropdownFocused(false), 200);
            }}
            className="mt-1 w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none px-0 py-2.5 text-sm font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
          />

          {/* Autocomplete Dropdown List */}
          <AnimatePresence>
            {isDropdownFocused && matchedItems.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="absolute left-0 right-0 z-50 mt-1 max-h-48 overflow-y-auto rounded-xs border border-art-border bg-[#181818] p-1 shadow-2xl shadow-black/80 scrollbar-none"
              >
                {matchedItems.map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => {
                      setProductName(item.name);
                      setCategory(item.category);
                      setPrice(item.price);
                      setIsDropdownFocused(false);
                      sounds.playClick();
                    }}
                    className="flex w-full items-center justify-between px-3 py-2 text-left text-xs text-gray-300 hover:bg-[#222] hover:text-brand-orange rounded-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <LucideIcon name={item.icon || 'Package'} size={12} className="text-brand-orange" />
                      <span className="font-bold">{item.name}</span>
                    </div>
                    <span className="font-mono text-brand-orange text-[10px] font-bold">₺{item.price}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Category Selector Cards */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
            Kategori Seçin
          </label>
          <div className="mt-2 grid grid-cols-5 gap-1.5">
            {categories.map((cat) => {
              const isSelected = category === cat.key;
              return (
                <button
                  type="button"
                  key={cat.key}
                  onClick={() => handleCategorySelect(cat.key, cat.sound)}
                  className={`flex flex-col items-center justify-center rounded-xs py-2 px-1 border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                      : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300 hover:border-gray-700'
                  }`}
                >
                  <span className="text-lg leading-none">{cat.emoji}</span>
                  <span className="mt-1 text-[9px] font-bold uppercase tracking-wider">{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Price & Quantity Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
              Birim Fiyatı (₺) *
            </label>
            <div className="relative mt-1">
              <span className="absolute left-0 top-1/2 -translate-y-1/2 font-bold text-brand-orange text-sm">
                ₺
              </span>
              <input
                type="number"
                min="0.01"
                step="any"
                placeholder="0.00"
                value={price}
                onChange={(e) => setPrice(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none pl-5 pr-0 py-2 text-sm font-mono font-bold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
              Miktar (Adet) *
            </label>
            <div className="mt-1.5 flex items-center justify-between border-b-2 border-art-border p-1 bg-transparent">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setQuantity((q) => Math.max(1, q - 1));
                }}
                className="flex h-7 w-7 items-center justify-center rounded-xs hover:bg-[#222] text-gray-400 hover:text-brand-orange transition-colors cursor-pointer"
              >
                <LucideIcon name="Minus" size={12} />
              </button>
              <span className="font-mono font-bold text-sm text-art-light">{quantity}</span>
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setQuantity((q) => q + 1);
                }}
                className="flex h-7 w-7 items-center justify-center rounded-xs hover:bg-[#222] text-gray-400 hover:text-brand-orange transition-colors cursor-pointer"
              >
                <LucideIcon name="Plus" size={12} />
              </button>
            </div>
          </div>
        </div>

        {/* Ödeme Yöntemi */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
            Ödeme Yöntemi
          </label>
          <div className="mt-1.5 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => { sounds.playClick(); setPaymentMethod('cash'); }}
              className={`flex items-center justify-center gap-2 rounded-xs border py-2.5 px-3 transition-all cursor-pointer ${
                paymentMethod === 'cash'
                  ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                  : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
              }`}
            >
              <LucideIcon name="Coins" size={14} />
              <span className="text-xs font-bold uppercase tracking-wider">Nakit</span>
            </button>
            <button
              type="button"
              onClick={() => { sounds.playClick(); setPaymentMethod('card'); }}
              className={`flex items-center justify-center gap-2 rounded-xs border py-2.5 px-3 transition-all cursor-pointer ${
                paymentMethod === 'card'
                  ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                  : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
              }`}
            >
              <LucideIcon name="CreditCard" size={14} />
              <span className="text-xs font-bold uppercase tracking-wider">Kredi Kartı</span>
            </button>
          </div>
        </div>

        {/* Notes */}
        <div className="relative">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
              Notlar / Müşteri Bilgisi
            </label>
            <span className="text-[8px] text-gray-500 font-extrabold tracking-widest uppercase">Hızlı Seçim</span>
          </div>
          <div className="relative mt-1 flex items-center">
            <input
              type="text"
              placeholder="Örn: Pamuk'un yıkama seansı, Ali Bey"
              value={notes}
              onChange={(e) => { setNotes(e.target.value); setIsNotesDropdownOpen(false); }}
              className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none pl-0 pr-8 py-2 text-sm font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
            />
            <button
              type="button"
              onClick={() => { sounds.playClick(); setIsNotesDropdownOpen(!isNotesDropdownOpen); }}
              className="absolute right-0 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center text-gray-500 hover:text-brand-orange transition-colors cursor-pointer"
              title="Hızlı Not Seç"
            >
              <LucideIcon name="ChevronDown" size={14} className={`transition-transform duration-300 ${isNotesDropdownOpen ? "rotate-180" : ""}`} />
            </button>
          </div>

          <AnimatePresence>
            {isNotesDropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 5 }}
                className="absolute left-0 right-0 z-50 mt-1 max-h-48 overflow-y-auto rounded-xs border border-art-border bg-[#141414] p-1 shadow-2xl shadow-black/80"
              >
                <div className="p-1.5 text-[8px] font-black uppercase tracking-widest text-brand-orange border-b border-art-border/30 mb-1 flex items-center justify-between">
                  <span>Hızlı Seçim Listesi</span>
                  <span className="text-gray-500 text-[7px]">Yazılanlar Kaydedilir</span>
                </div>
                {quickNotes.map((note, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setNotes(note);
                      setIsNotesDropdownOpen(false);
                      sounds.playClick();
                    }}
                    className="w-full text-left rounded-xs px-2.5 py-1.5 text-xs font-semibold text-gray-300 hover:text-brand-orange hover:bg-[#222] transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <LucideIcon name="FileText" size={11} className="text-gray-600 shrink-0" />
                    <span className="truncate">{note}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-xs bg-rose-950/30 border border-rose-900/50 p-3 text-xs font-bold text-rose-400 flex items-center gap-1.5"
          >
            <LucideIcon name="AlertCircle" size={14} />
            <span>{error}</span>
          </motion.div>
        )}

        {/* Submit Button */}
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          type="submit"
          className="mt-3 w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3.5 text-xs font-bold uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <LucideIcon name="ShoppingBag" size={14} />
          <span>Satışı Tamamla</span>
        </motion.button>
      </form>
    </div>
  );
}
