/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import LucideIcon from './LucideIcon';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: string;
  trendPositive?: boolean;
  gradient: string;
  delay?: number;
}

export default function StatsCard({
  title,
  value,
  icon,
  trend,
  trendPositive = true,
  gradient,
  delay = 0,
}: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.4, delay, type: 'spring', stiffness: 100 }}
      whileHover={{ y: -4, scale: 1.02 }}
      className="relative overflow-hidden rounded-xs border border-art-border border-l-4 border-l-brand-orange bg-art-card p-6 shadow-md shadow-black/40"
    >
      {/* Subtle background ambient glow */}
      <div className="absolute -right-12 -top-12 h-24 w-24 rounded-full bg-brand-orange/5 blur-2xl" />

      <div className="flex items-center justify-between">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{title}</p>
          <h3 className="mt-2 font-mono text-3xl font-extrabold text-art-light tracking-tight">
            {value}
          </h3>
        </div>

        <div className="flex h-12 w-12 items-center justify-center rounded-xs bg-[#222] text-brand-orange shadow-inner">
          <LucideIcon name={icon} className="h-5 w-5" />
        </div>
      </div>

      {trend && (
        <div className="mt-4 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
          <span
            className={`flex items-center rounded-xs px-2 py-0.5 ${
              trendPositive ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-900/50' : 'bg-rose-950/50 text-rose-400 border border-rose-900/50'
            }`}
          >
            {trendPositive ? '↑' : '↓'} {trend}
          </span>
          <span className="text-gray-500">geçen aya göre</span>
        </div>
      )}
    </motion.div>
  );
}
