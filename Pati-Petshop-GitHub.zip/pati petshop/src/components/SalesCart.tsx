/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem } from '../types';
import { sounds } from '../utils/sound';
import LucideIcon from './LucideIcon';

interface SalesCartProps {
  cart: CartItem[];
  onUpdateQuantity: (id: string, q: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: (notes: string, paymentMethod: 'cash' | 'card') => void;
}

export default function SalesCart({ cart, onUpdateQuantity, onRemoveItem, onCheckout }: SalesCartProps) {
  const [cartNotes, setCartNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card'>('cash');

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    onCheckout(cartNotes, paymentMethod);
    setCartNotes('');
    setPaymentMethod('cash');
  };

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col h-full min-h-[400px]">
      <div className="mb-4 flex items-center justify-between border-b border-art-border pb-4">
        <div className="flex items-center gap-3">
          <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
            <LucideIcon name="ShoppingCart" size={16} />
          </div>
          <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
            Aktif Satış Sepeti
          </h3>
        </div>
        {cart.length > 0 && (
          <span className="rounded-xs bg-brand-orange px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-black">
            {cart.reduce((sum, item) => sum + item.quantity, 0)} Ürün
          </span>
        )}
      </div>

      {/* Cart Items list */}
      <div className="flex-1 overflow-y-auto max-h-[300px] pr-1 mb-4 scrollbar-none">
        <AnimatePresence mode="popLayout">
          {cart.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-12 text-center"
            >
              <div className="mb-3 rounded-xs bg-[#222] p-4 text-brand-orange border border-art-border">
                <LucideIcon name="ShoppingBag" size={28} />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-gray-500">Sepetiniz Boş</p>
              <p className="mt-2 text-[10px] text-gray-600 max-w-[200px] uppercase tracking-wider font-semibold">
                Katalogdan ürün seçerek hızlıca sepet oluşturun!
              </p>
            </motion.div>
          ) : (
            <div className="flex flex-col gap-3">
              {cart.map((item) => (
                <motion.div
                  layout
                  key={item.catalogItemId}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20, scale: 0.95 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  className="flex items-center gap-3 justify-between rounded-xs border border-art-border bg-transparent p-3"
                >
                  {/* Visual product image thumbnail inside Cart */}
                  <div className="relative w-10 h-10 rounded-xs border border-art-border bg-[#1c1c1c] flex items-center justify-center overflow-hidden flex-shrink-0">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <span className="text-sm">
                        {item.category === 'cat'
                          ? '🐱'
                          : item.category === 'dog'
                          ? '🐶'
                          : item.category === 'bird'
                          ? '🐦'
                          : item.category === 'fish'
                          ? '🐟'
                          : '🐾'}
                      </span>
                    )}
                  </div>

                  <div className="flex-1 pr-2 truncate">
                    <span className="text-[8px] font-extrabold uppercase text-brand-orange tracking-widest">
                      {item.category.toUpperCase()}
                    </span>
                    <h4 className="text-xs font-bold text-art-light truncate" title={item.name}>
                      {item.name}
                    </h4>
                    <p className="font-mono text-xs font-bold text-gray-500 mt-0.5">
                      ₺{item.price} x {item.quantity} = <span className="text-brand-orange">₺{item.price * item.quantity}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Quantity controls */}
                    <div className="flex items-center rounded-xs border border-art-border bg-[#222] p-0.5">
                      <button
                        onClick={() => {
                          sounds.playClick();
                          onUpdateQuantity(item.catalogItemId, item.quantity - 1);
                        }}
                        className="flex h-6 w-6 items-center justify-center rounded-xs hover:bg-[#333] text-gray-400 hover:text-brand-orange cursor-pointer"
                      >
                        <LucideIcon name="Minus" size={10} />
                      </button>
                      <span className="w-5 text-center font-mono text-xs font-bold text-art-light">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => {
                          sounds.playClick();
                          onUpdateQuantity(item.catalogItemId, item.quantity + 1);
                        }}
                        className="flex h-6 w-6 items-center justify-center rounded-xs hover:bg-[#333] text-gray-400 hover:text-brand-orange cursor-pointer"
                      >
                        <LucideIcon name="Plus" size={10} />
                      </button>
                    </div>

                    {/* Delete Item */}
                    <button
                      onClick={() => {
                        sounds.playDelete();
                        onRemoveItem(item.catalogItemId);
                      }}
                      className="flex h-8 w-8 items-center justify-center rounded-xs bg-rose-950/40 text-rose-400 border border-rose-900/50 hover:bg-rose-900/30 transition-colors cursor-pointer"
                      title="Sepetten Çıkar"
                    >
                      <LucideIcon name="Trash2" size={12} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>
      </div>

      {cart.length > 0 && (
        <div className="border-t border-art-border pt-4 flex flex-col gap-3">
          {/* Cart Notes Input */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
              Müşteri Notu (İsteğe Bağlı)
            </label>
            <input
              type="text"
              placeholder="Örn: Pamuk'un sahibi, Veresiye vb."
              value={cartNotes}
              onChange={(e) => setCartNotes(e.target.value)}
              className="mt-1 w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none px-0 py-2 text-xs font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
            />
          </div>

          {/* Ödeme Yöntemi */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-brand-orange">
              Ödeme Yöntemi
            </label>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => { sounds.playClick(); setPaymentMethod('cash'); }}
                className={`flex items-center justify-center gap-1.5 rounded-xs border py-2 px-2 transition-all cursor-pointer ${
                  paymentMethod === 'cash'
                    ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                    : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
                }`}
              >
                <LucideIcon name="Coins" size={12} />
                <span className="text-[10px] font-bold uppercase tracking-wider">Nakit</span>
              </button>
              <button
                type="button"
                onClick={() => { sounds.playClick(); setPaymentMethod('card'); }}
                className={`flex items-center justify-center gap-1.5 rounded-xs border py-2 px-2 transition-all cursor-pointer ${
                  paymentMethod === 'card'
                    ? 'border-brand-orange bg-[#222] text-brand-orange font-bold shadow-sm'
                    : 'border-art-border bg-transparent text-gray-500 hover:text-gray-300'
                }`}
              >
                <LucideIcon name="CreditCard" size={12} />
                <span className="text-[10px] font-bold uppercase tracking-wider">Kredi Kartı</span>
              </button>
            </div>
          </div>

          {/* Pricing summary */}
          <div className="flex items-center justify-between bg-[#222] rounded-xs p-3 border border-art-border">
            <span className="text-xs font-bold uppercase tracking-widest text-gray-400">Toplam Ödeme</span>
            <div className="text-right">
              <span className="font-mono text-xl font-bold text-brand-orange">
                ₺{totalPrice}
              </span>
            </div>
          </div>

          {/* Complete Cart Sale Button */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleCheckout}
            className="w-full rounded-xs bg-brand-orange hover:bg-brand-orange/95 py-3.5 text-xs font-bold uppercase tracking-widest text-black shadow-md shadow-brand-orange/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <LucideIcon name="CheckCircle" size={14} />
            <span>Satışı Onayla (₺{totalPrice})</span>
          </motion.button>
        </div>
      )}
    </div>
  );
}
