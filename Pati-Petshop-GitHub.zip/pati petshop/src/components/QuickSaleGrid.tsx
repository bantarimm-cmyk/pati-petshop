/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CatalogItem, PetCategory } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface QuickSaleGridProps {
  catalog: CatalogItem[];
  onAddToCart: (item: CatalogItem) => void;
  onInstantSell: (item: CatalogItem, event: React.MouseEvent) => void;
  activeHighlight?: {
    itemIds: string[];
    type: string;
    cityName: string;
  } | null;
}

export default function QuickSaleGrid({ catalog, onAddToCart, onInstantSell, activeHighlight }: QuickSaleGridProps) {
  const [selectedCategory, setSelectedCategory] = useState<PetCategory | 'all'>('all');

  const categories: { key: PetCategory | 'all'; label: string; icon: string; emoji: string; sound: () => void }[] = [
    {
      key: 'all',
      label: 'Tüm Ürünler',
      icon: 'PawPrint',
      emoji: '🐾',
      sound: () => sounds.playClick(),
    },
    {
      key: 'cat',
      label: 'Kedi',
      icon: 'Cat',
      emoji: '🐱',
      sound: () => sounds.playMeow(),
    },
    {
      key: 'dog',
      label: 'Köpek',
      icon: 'Dog',
      emoji: '🐶',
      sound: () => sounds.playBark(),
    },
    {
      key: 'bird',
      label: 'Kuş',
      icon: 'Twitter',
      emoji: '🐦',
      sound: () => sounds.playChirp(),
    },
    {
      key: 'fish',
      label: 'Balık',
      icon: 'FishSymbol',
      emoji: '🐟',
      sound: () => sounds.playBubble(),
    },
    {
      key: 'other',
      label: 'Diğer',
      icon: 'Sparkles',
      emoji: '✨',
      sound: () => sounds.playClick(),
    },
  ];

  const handleCategoryChange = (cat: PetCategory | 'all', soundFn: () => void) => {
    soundFn();
    setSelectedCategory(cat);
  };

  const filteredItems = selectedCategory === 'all'
    ? catalog
    : catalog.filter((item) => item.category === selectedCategory);

  return (
    <div className="flex flex-col gap-6">
      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.key;
          return (
            <motion.button
              key={cat.key}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleCategoryChange(cat.key, cat.sound)}
              className={`flex items-center gap-2 rounded-xs px-4 py-2.5 text-xs font-bold uppercase tracking-wider border transition-all cursor-pointer ${
                isActive
                  ? 'bg-brand-orange text-black border-brand-orange shadow-md shadow-brand-orange/20'
                  : 'bg-art-card hover:bg-[#222] text-gray-400 hover:text-brand-orange border-art-border'
              }`}
            >
              <span className="text-base leading-none">{cat.emoji}</span>
              <span>{cat.label}</span>
            </motion.button>
          );
        })}
      </div>

      {/* Grid of Items */}
      <motion.div
        layout
        className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3"
      >
        <AnimatePresence mode="popLayout">
          {filteredItems.map((item, idx) => {
            const petEmoji =
              item.category === 'cat'
                ? '🐱'
                : item.category === 'dog'
                ? '🐶'
                : item.category === 'bird'
                ? '🐦'
                : item.category === 'fish'
                ? '🐟'
                : '🐾';

            // Distinct left border colors matching the Artistic category colors
            const categoryLeftBorder =
              item.category === 'cat'
                ? 'border-l-pink-500'
                : item.category === 'dog'
                ? 'border-l-brand-orange'
                : item.category === 'bird'
                ? 'border-l-emerald-500'
                : item.category === 'fish'
                ? 'border-l-sky-500'
                : 'border-l-indigo-500';

            const isHighlighted = activeHighlight?.itemIds.includes(item.id);
            const weatherType = activeHighlight?.type;

            let highlightClasses = '';
            let weatherBadgeLabel = '';
            let weatherBadgeIcon = '';
            let weatherBadgeColor = '';

            if (isHighlighted) {
              if (weatherType === 'sunny') {
                highlightClasses = 'ring-1.5 ring-amber-500/80 shadow-md shadow-amber-500/10 scale-[1.01] border-amber-500/40 bg-[#1e1710]';
                weatherBadgeLabel = 'Güneş Önerisi';
                weatherBadgeIcon = 'Sun';
                weatherBadgeColor = 'bg-amber-500/15 text-amber-400 border-amber-500/30';
              } else if (weatherType === 'rainy') {
                highlightClasses = 'ring-1.5 ring-sky-500/80 shadow-md shadow-sky-500/10 scale-[1.01] border-sky-500/40 bg-[#101924]';
                weatherBadgeLabel = 'Yağmur Önerisi';
                weatherBadgeIcon = 'CloudRain';
                weatherBadgeColor = 'bg-sky-500/15 text-sky-400 border-sky-500/30';
              } else if (weatherType === 'snowy') {
                highlightClasses = 'ring-1.5 ring-indigo-500/80 shadow-md shadow-indigo-500/10 scale-[1.01] border-indigo-500/40 bg-[#121124]';
                weatherBadgeLabel = 'Soğuk Önerisi';
                weatherBadgeIcon = 'Snowflake';
                weatherBadgeColor = 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30';
              } else if (weatherType === 'windy') {
                highlightClasses = 'ring-1.5 ring-teal-500/80 shadow-md shadow-teal-500/10 scale-[1.01] border-teal-500/40 bg-[#101f1f]';
                weatherBadgeLabel = 'Fırtına Önerisi';
                weatherBadgeIcon = 'Wind';
                weatherBadgeColor = 'bg-teal-500/15 text-teal-400 border-teal-500/30';
              } else {
                highlightClasses = 'ring-1.5 ring-brand-orange shadow-md shadow-brand-orange/10 scale-[1.01] border-brand-orange/40 bg-[#241310]';
                weatherBadgeLabel = 'Atmosfer Önerisi';
                weatherBadgeIcon = 'Sparkles';
                weatherBadgeColor = 'bg-brand-orange/15 text-brand-orange border-brand-orange/30';
              }
            }

            return (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -15 }}
                transition={{ duration: 0.3, delay: idx * 0.02, type: 'spring', stiffness: 150 }}
                whileHover={{ y: -4 }}
                className={`flex flex-col justify-between rounded-xs border border-art-border border-l-4 ${categoryLeftBorder} bg-art-card p-5 shadow-md shadow-black/20 hover:border-brand-orange/40 hover:shadow-lg hover:shadow-black/40 transition-all ${highlightClasses}`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex flex-col gap-1.5 items-start">
                      <span className="rounded-xs bg-[#222] border border-art-border px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-widest text-gray-300">
                        {petEmoji} {item.category.toUpperCase()}
                      </span>
                      {isHighlighted && (
                        <span className={`rounded-xs border px-2 py-0.5 text-[7px] font-black uppercase tracking-wider flex items-center gap-1 ${weatherBadgeColor}`}>
                          <LucideIcon name={weatherBadgeIcon} size={8} />
                          <span>{weatherBadgeLabel}</span>
                        </span>
                      )}
                    </div>
                    <div className="relative w-10 h-10 rounded-xs border border-art-border bg-[#1c1c1c] flex items-center justify-center overflow-hidden flex-shrink-0">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="text-brand-orange">
                          <LucideIcon name={item.icon} size={16} />
                        </div>
                      )}
                    </div>
                  </div>

                  <h4 className="mt-4 font-sans text-sm font-bold text-art-light leading-snug min-h-[44px]">
                    {item.name}
                  </h4>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-art-border pt-4">
                  <div>
                    <span className="text-[9px] text-gray-500 uppercase tracking-widest font-extrabold">Birim Fiyat</span>
                    <p className="font-mono text-lg font-bold text-brand-orange">₺{item.price}</p>
                  </div>

                  <div className="flex gap-2">
                    {/* Sepete Ekle Button */}
                    <button
                      onClick={() => onAddToCart(item)}
                      title="Sepete Ekle"
                      className="flex h-10 w-10 items-center justify-center rounded-xs bg-[#222] text-brand-orange border border-art-border hover:bg-[#2c2c2c] active:scale-95 transition-all cursor-pointer"
                    >
                      <LucideIcon name="ShoppingCart" size={15} />
                    </button>

                    {/* Hemen Sat Button */}
                    <button
                      onClick={(e) => onInstantSell(item, e)}
                      title="Hemen Sat"
                      className="flex h-10 items-center gap-1.5 rounded-xs bg-brand-orange hover:bg-brand-orange/90 px-3 text-xs font-bold uppercase tracking-wider text-black shadow-md shadow-brand-orange/10 active:scale-95 transition-all cursor-pointer"
                    >
                      <LucideIcon name="Zap" size={13} />
                      <span>Hemen Sat</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
