/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sale } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface SalesHistoryProps {
  sales: Sale[];
  onDeleteSale: (id: string) => void;
  onClearAll: () => void;
}

export default function SalesHistory({ sales, onDeleteSale, onClearAll }: SalesHistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Search filter logic
  const filteredSales = sales.filter((sale) => {
    const q = searchQuery.toLowerCase();
    return (
      sale.productName.toLowerCase().includes(q) ||
      sale.notes.toLowerCase().includes(q) ||
      sale.category.toLowerCase().includes(q)
    );
  });

  const handleStartDelete = (id: string) => {
    sounds.playClick();
    setConfirmDeleteId(id);
  };

  const handleCancelDelete = () => {
    sounds.playClick();
    setConfirmDeleteId(null);
  };

  const handleConfirmDelete = (id: string) => {
    sounds.playDelete();
    onDeleteSale(id);
    setConfirmDeleteId(null);
  };

  // CSV Export helper
  const exportToCSV = () => {
    sounds.playClick();
    if (sales.length === 0) return;

    const headers = ['İşlem ID', 'Ürün/Hizmet', 'Kategori', 'Birim Fiyat', 'Miktar', 'Toplam Tutar', 'Ödeme Yöntemi', 'Notlar', 'Tarih'];
    const rows = sales.map((s) => [
      s.id,
      s.productName,
      s.category,
      s.price,
      s.quantity,
      s.totalPrice,
      s.paymentMethod === 'card' ? 'Kredi Kartı' : 'Nakit',
      s.notes,
      new Date(s.createdAt).toLocaleString('tr-TR'),
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.map((val) => `"${val}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Pati_Petshop_Satis_Raporu_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCategoryTag = (category: string) => {
    switch (category) {
      case 'cat':
        return { emoji: '🐱', style: 'bg-[#222] border border-pink-500/40 text-pink-400' };
      case 'dog':
        return { emoji: '🐶', style: 'bg-[#222] border border-brand-orange/40 text-brand-orange' };
      case 'bird':
        return { emoji: '🐦', style: 'bg-[#222] border border-emerald-500/40 text-emerald-400' };
      case 'fish':
        return { emoji: '🐟', style: 'bg-[#222] border border-sky-500/40 text-sky-400' };
      default:
        return { emoji: '🐾', style: 'bg-[#222] border border-indigo-500/40 text-indigo-400' };
    }
  };

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40">
      {/* Title Bar with Action Buttons */}
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
            <LucideIcon name="ClipboardList" size={16} />
          </div>
          <div>
            <h3 className="font-serif italic text-xl font-normal text-brand-orange border-b border-brand-orange pb-0.5 inline-block">
              Son Satış Kayıtları
            </h3>
            <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Yapılan tüm işlemlerin detaylı listesi</p>
          </div>
        </div>

        {sales.length > 0 && (
          <div className="flex items-center gap-2">
            {/* Export */}
            <button
              onClick={exportToCSV}
              className="flex items-center gap-1.5 rounded-xs border border-art-border bg-[#222] hover:bg-[#2c2c2c] px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-brand-orange active:scale-95 transition-all cursor-pointer shadow-md shadow-black/25"
            >
              <LucideIcon name="Download" size={12} />
              <span>CSV Raporu</span>
            </button>

            {/* Clear All */}
            {!showClearConfirm ? (
              <button
                onClick={() => {
                  sounds.playClick();
                  setShowClearConfirm(true);
                }}
                className="flex items-center gap-1.5 rounded-xs bg-rose-950/40 border border-rose-900/50 hover:bg-rose-900/30 px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-rose-400 active:scale-95 transition-all cursor-pointer"
              >
                <LucideIcon name="Trash2" size={12} />
                <span>Temizle</span>
              </button>
            ) : (
              <div className="flex items-center gap-1.5 rounded-xs bg-rose-950/40 border border-rose-900/50 p-1">
                <span className="text-[9px] font-bold uppercase tracking-wider text-rose-300 px-2">Emin misiniz?</span>
                <button
                  onClick={() => {
                    sounds.playDelete();
                    onClearAll();
                    setShowClearConfirm(false);
                  }}
                  className="rounded-xs bg-rose-600 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-white cursor-pointer"
                >
                  Evet
                </button>
                <button
                  onClick={() => {
                    sounds.playClick();
                    setShowClearConfirm(false);
                  }}
                  className="rounded-xs bg-[#222] border border-art-border px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-gray-400 cursor-pointer"
                >
                  Hayır
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Search Input */}
      {sales.length > 0 && (
        <div className="relative mb-6">
          <span className="absolute left-0 top-1/2 -translate-y-1/2 text-brand-orange">
            <LucideIcon name="Search" size={14} />
          </span>
          <input
            type="text"
            placeholder="Satışlarda ara (Ürün adı, müşteri notu, hayvan türü...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent border-t-0 border-r-0 border-l-0 border-b-2 border-art-border rounded-none pl-6 pr-0 py-2 text-xs font-semibold text-art-light placeholder-gray-600 focus:border-brand-orange focus:outline-none focus:ring-0 transition-all"
          />
        </div>
      )}

      {/* Sales Rows */}
      <div className="overflow-x-auto">
        {filteredSales.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-3 rounded-xs bg-[#222] border border-art-border p-4 text-brand-orange animate-bounce">
              🐾
            </div>
            <p className="text-xs font-bold uppercase tracking-widest text-gray-500">
              {searchQuery ? 'Arama sonucu bulunamadı.' : 'Henüz hiçbir satış girilmedi.'}
            </p>
            <p className="mt-2 text-[10px] text-gray-600 max-w-[260px] uppercase tracking-wider font-semibold leading-relaxed">
              {searchQuery
                ? 'Lütfen arama kelimenizi kontrol edin veya filtreyi temizleyin.'
                : 'Yeni bir satış kaydederek Pati Petshop takip işleminize hemen başlayın!'}
            </p>
          </div>
        ) : (
          <table className="w-full min-w-[600px] border-collapse text-left">
            <thead>
              <tr className="border-b border-art-border pb-3 text-[9px] font-extrabold uppercase tracking-widest text-brand-orange">
                <th className="py-3 px-4">Tarih</th>
                <th className="py-3 px-2">Ürün / Hizmet</th>
                <th className="py-3 px-2">Kategori</th>
                <th className="py-3 px-2 text-right">Birim Fiyat</th>
                <th className="py-3 px-2 text-center">Miktar</th>
                <th className="py-3 px-2 text-right">Toplam Fiyat</th>
                <th className="py-3 px-4 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-art-border/30 text-xs font-semibold text-art-light">
              <AnimatePresence mode="popLayout">
                {filteredSales.map((sale) => {
                  const tag = getCategoryTag(sale.category);
                  const isConfirming = confirmDeleteId === sale.id;

                  return (
                    <motion.tr
                      layout
                      key={sale.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -50 }}
                      transition={{ duration: 0.2 }}
                      className="group hover:bg-[#1a1a1a] transition-colors"
                    >
                      {/* Created At */}
                      <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500 whitespace-nowrap">
                        {new Date(sale.createdAt).toLocaleDateString('tr-TR', {
                          day: '2-digit',
                          month: 'short',
                        })}
                        <span className="block text-[9px] text-gray-600">
                          {new Date(sale.createdAt).toLocaleTimeString('tr-TR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </td>

                      {/* Product Name */}
                      <td className="py-3.5 px-2 max-w-[200px]">
                        <span className="text-art-light font-bold block truncate" title={sale.productName}>
                          {sale.productName}
                        </span>
                        {sale.notes && (
                          <span className="text-[10px] text-brand-orange block italic leading-none mt-1 truncate" title={sale.notes}>
                            📝 {sale.notes}
                          </span>
                        )}
                      </td>

                      {/* Category Badges */}
                      <td className="py-3.5 px-2">
                        <span className={`inline-flex items-center gap-1 rounded-xs px-2.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wider ${tag.style}`}>
                          <span>{tag.emoji}</span>
                          <span>{sale.category.toUpperCase()}</span>
                        </span>
                      </td>

                      {/* Price */}
                      <td className="py-3.5 px-2 text-right font-mono text-gray-400">
                        ₺{sale.price}
                      </td>

                      {/* Quantity */}
                      <td className="py-3.5 px-2 text-center font-mono font-bold text-gray-400">
                        {sale.quantity}
                      </td>

                      {/* Total Price */}
                      <td className="py-3.5 px-2 text-right font-mono font-bold text-brand-orange">
                        ₺{sale.totalPrice}
                        <span className="block text-[8px] font-semibold font-sans tracking-wider text-gray-500 uppercase mt-0.5">
                          {sale.paymentMethod === 'card' ? '💳 KART' : '💵 NAKİT'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <AnimatePresence mode="wait">
                          {!isConfirming ? (
                            <motion.button
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              onClick={() => handleStartDelete(sale.id)}
                              className="inline-flex h-7 w-7 items-center justify-center rounded-xs bg-[#222] border border-art-border text-gray-500 hover:text-rose-400 hover:border-rose-900/50 transition-colors cursor-pointer"
                              title="Satışı Sil / İptal Et"
                            >
                              <LucideIcon name="Undo" size={11} />
                            </motion.button>
                          ) : (
                            <motion.div
                              key="confirm-box"
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.9 }}
                              className="inline-flex items-center gap-1 bg-rose-950/40 border border-rose-900/50 p-1 rounded-xs"
                            >
                              <button
                                onClick={() => handleConfirmDelete(sale.id)}
                                className="rounded-xs px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-rose-600 text-white cursor-pointer"
                              >
                                Evet
                              </button>
                              <button
                                onClick={handleCancelDelete}
                                className="rounded-xs px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-[#222] text-gray-400 border border-art-border cursor-pointer"
                              >
                                Hayır
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
