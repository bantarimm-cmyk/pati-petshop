/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import LucideIcon from './LucideIcon';
import { Sale, CatalogItem } from '../types';
import { sounds } from '../utils/sound';

interface BackupReminderProps {
  sales: Sale[];
  catalog: CatalogItem[];
  onRestore: (sales: Sale[], catalog: CatalogItem[]) => void;
}

export default function BackupReminder({ sales, catalog, onRestore }: BackupReminderProps) {
  const [showReminder, setShowReminder] = useState(false);
  const [lastBackup, setLastBackup] = useState<string>(() => {
    return localStorage.getItem('pati_last_backup_time') || '';
  });

  // Check if we need to remind the user (if there are sales and either no backup exists or it's older than 24 hours)
  useEffect(() => {
    if (sales.length === 0) return;

    const checkReminder = () => {
      const now = Date.now();
      const lastBackupTime = Number(localStorage.getItem('pati_last_backup_time') || 0);
      const ONE_DAY_MS = 24 * 60 * 60 * 1000;

      // Remind if last backup was more than 24 hours ago (or never)
      if (now - lastBackupTime > ONE_DAY_MS) {
        setShowReminder(true);
      }
    };

    // Check on mount and then every 30 seconds
    checkReminder();
    const interval = setInterval(checkReminder, 30000);
    return () => clearInterval(interval);
  }, [sales, lastBackup]);

  const handleDownloadBackup = () => {
    sounds.playSuccess();
    const backupData = {
      sales,
      catalog,
      version: '1.0',
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Pati_Petshop_Veri_Yedegi_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);

    // Save backup timestamp
    const nowStr = String(Date.now());
    localStorage.setItem('pati_last_backup_time', nowStr);
    setLastBackup(nowStr);
    setShowReminder(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data && Array.isArray(data.sales) && Array.isArray(data.catalog)) {
          onRestore(data.sales, data.catalog);
          sounds.playSuccess();
          setShowReminder(false);
          alert('Yedek başarıyla yüklendi! Tüm satışlar ve ürün kataloğu geri yüklendi.');
        } else {
          throw new Error('Invalid format');
        }
      } catch (err) {
        sounds.playDelete();
        alert('Hata: Seçilen dosya geçerli bir Pati Petshop yedek dosyası değil!');
      }
    };
    reader.readAsText(file);
  };

  const dismissReminder = () => {
    sounds.playClick();
    // Snooze for 4 hours by shifting the target backward
    const snoozeTime = String(Date.now() - (20 * 60 * 60 * 1000)); // sets target to 20h ago so it prompts in 4 hours
    localStorage.setItem('pati_last_backup_time', snoozeTime);
    setShowReminder(false);
  };

  return (
    <AnimatePresence>
      {showReminder && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="fixed bottom-6 right-6 z-[100] max-w-sm rounded-xs border border-brand-orange bg-[#111] p-5 shadow-2xl shadow-black/90"
        >
          <div className="flex gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xs bg-brand-orange/15 border border-brand-orange/40 text-brand-orange">
              <LucideIcon name="Database" size={18} />
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold uppercase tracking-wider text-brand-orange flex items-center gap-1.5">
                <span>Yedekleme Hatırlatıcısı</span>
                <span className="rounded-xs bg-[#222] border border-brand-orange/30 px-1.5 py-0.2 text-[8px] font-black text-brand-orange animate-pulse">ÖNEMLİ</span>
              </h4>
              <p className="mt-1.5 text-xs font-bold text-gray-300 leading-relaxed">
                Tarayıcı çerezleri veya önbelleği temizlendiğinde satış verileriniz sıfırlanabilir. Verilerinizi güvenceye almak için şimdi yedek indirin.
              </p>

              {lastBackup && (
                <p className="mt-2 text-[9px] font-mono text-gray-500 font-bold uppercase">
                  Son Yedekleme: {new Date(Number(lastBackup)).toLocaleDateString('tr-TR')} {new Date(Number(lastBackup)).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                </p>
              )}

              <div className="mt-4 flex flex-wrap items-center gap-2">
                {/* Backup Now */}
                <button
                  onClick={handleDownloadBackup}
                  className="flex items-center gap-1.5 rounded-xs bg-brand-orange hover:bg-brand-orange/95 px-3 py-2 text-[10px] font-black uppercase tracking-wider text-black transition-all cursor-pointer shadow-md shadow-brand-orange/15"
                >
                  <LucideIcon name="Download" size={11} />
                  <span>Şimdi Yedekle</span>
                </button>

                {/* Import / Restore */}
                <label className="flex items-center gap-1.5 rounded-xs border border-art-border bg-[#222] hover:bg-[#333] px-3 py-2 text-[10px] font-extrabold uppercase tracking-wider text-gray-300 transition-all cursor-pointer">
                  <LucideIcon name="Upload" size={11} className="text-brand-orange" />
                  <span>Yedek Yükle</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                {/* Remind me later */}
                <button
                  onClick={dismissReminder}
                  className="rounded-xs px-2.5 py-2 text-[9px] font-bold uppercase tracking-wider text-gray-500 hover:text-gray-300 transition-colors cursor-pointer"
                >
                  Daha Sonra
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
