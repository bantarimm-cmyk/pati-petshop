/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CatalogItem } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface VoiceSaleProps {
  catalog: CatalogItem[];
  onAddVoiceSale: (item: CatalogItem, quantity: number) => void;
}

const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

const TURKISH_NUMBER_WORDS: Record<string, number> = {
  'bir': 1, 'tek': 1,
  'iki': 2,
  'üç': 3,
  'dört': 4,
  'beş': 5,
  'altı': 6,
  'yedi': 7,
  'sekiz': 8,
  'dokuz': 9,
  'on': 10,
  'yirmi': 20,
  'otuz': 30,
};

export default function VoiceSale({ catalog, onAddVoiceSale }: VoiceSaleProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [status, setStatus] = useState<'idle' | 'listening' | 'success' | 'error'>('idle');
  const [feedback, setFeedback] = useState('');
  const [isSupported, setIsSupported] = useState(true);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      setIsSupported(false);
    }
  }, []);

  const startListening = () => {
    if (!isSupported) return;

    sounds.playClick();
    setTranscript('');
    setFeedback('');
    setStatus('listening');
    setIsListening(true);

    try {
      const recognition = new SpeechRecognitionAPI();
      recognition.lang = 'tr-TR';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const resultText = event.results[0][0].transcript;
        setTranscript(resultText);
        processVoiceCommand(resultText);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event);
        setIsListening(false);
        setStatus('error');
        if (event.error === 'not-allowed') {
          setFeedback('Mikrofon izni reddedildi. Tarayıcınızdan izin verin.');
        } else {
          setFeedback('Ses duyulamadı. Lütfen tekrar deneyin.');
        }
        sounds.playDelete();
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
      setStatus('error');
      setFeedback('Mikrofon başlatılamadı.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
    setStatus('idle');
  };

  const processVoiceCommand = (rawText: string) => {
    const text = rawText.toLowerCase().trim();
    
    // Parse quantity
    let quantity = 1;
    const digitMatch = text.match(/\d+/);
    if (digitMatch) {
      quantity = parseInt(digitMatch[0], 10);
    } else {
      // Check word numbers
      for (const [word, val] of Object.entries(TURKISH_NUMBER_WORDS)) {
        if (new RegExp(`\\b${word}\\b`).test(text)) {
          quantity = val;
          break;
        }
      }
    }

    // Prepare text for matching by stripping noise words
    const cleanText = text
      .replace(/\b(bir|tek|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|tane|adet|kilo|paket|sat|ekle|al|gönder|sepete)\b/g, '')
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
      .trim();

    if (!cleanText && !digitMatch) {
      setStatus('error');
      setFeedback('Anlaşılamadı. Örn: "3 kedi maması sat"');
      sounds.playDelete();
      return;
    }

    // Match catalog item using advanced word scoring
    let bestMatch: CatalogItem | null = null;
    let maxScore = 0;

    const queryWords = cleanText.split(/\s+/).filter(w => w.length >= 2);

    for (const item of catalog) {
      const itemName = item.name.toLowerCase();
      let score = 0;

      // Direct exact match contains
      if (itemName === cleanText) {
        score += 100;
      } else if (text.includes(itemName)) {
        score += itemName.length * 3;
      } else if (itemName.includes(cleanText)) {
        score += cleanText.length * 2;
      }

      // Word-by-word matching
      const itemWords = itemName.split(/\s+/).filter(w => w.length >= 2);
      for (const qWord of queryWords) {
        for (const iWord of itemWords) {
          if (iWord === qWord) {
            score += 15;
          } else if (iWord.includes(qWord) || qWord.includes(iWord)) {
            score += 5;
          }
        }
      }

      if (score > maxScore && score > 3) {
        maxScore = score;
        bestMatch = item;
      }
    }

    if (bestMatch) {
      onAddVoiceSale(bestMatch, quantity);
      setStatus('success');
      setFeedback(`Sepete Eklendi: ${quantity} x ${bestMatch.name}`);
      
      // Auto reset feedback to idle after 3 seconds
      setTimeout(() => {
        setStatus('idle');
        setTranscript('');
        setFeedback('');
      }, 4000);
    } else {
      setStatus('error');
      setFeedback(`Katalogda "${cleanText}" ürünü bulunamadı.`);
      sounds.playDelete();
    }
  };

  if (!isSupported) {
    return (
      <div className="rounded-xs border border-art-border bg-art-card/30 p-4 text-center">
        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center justify-center gap-1.5">
          <LucideIcon name="MicOff" size={12} />
          <span>Sesle Satış desteklenmiyor.</span>
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-xs border border-art-border bg-art-card p-4 shadow-md shadow-black/30">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            {/* Audio Ripples */}
            {isListening && (
              <>
                <span className="absolute -inset-1 rounded-full bg-brand-orange/30 animate-ping" />
                <span className="absolute -inset-2 rounded-full bg-brand-orange/15 animate-pulse" />
              </>
            )}
            
            <button
              onClick={isListening ? stopListening : startListening}
              className={`relative z-10 flex h-10 w-10 items-center justify-center rounded-full transition-all cursor-pointer shadow-md ${
                isListening
                  ? 'bg-brand-orange text-black'
                  : 'bg-[#1e1e1e] border border-art-border text-brand-orange hover:bg-[#252525]'
              }`}
            >
              <LucideIcon name={isListening ? 'Mic' : 'MicOff'} size={18} />
            </button>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
              <span>Sesle Satış Gir</span>
              <span className="rounded-xs bg-brand-orange/15 border border-brand-orange/30 px-1 py-0.2 text-[8px] font-black text-brand-orange">
                YENİ
              </span>
            </h4>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-0.5">
              {isListening ? 'Sizi dinliyorum...' : 'Mikrofona tıklayıp konuşun'}
            </p>
          </div>
        </div>

        {/* Mini Guide / Help Icon */}
        <div className="relative group">
          <div className="text-gray-500 hover:text-brand-orange cursor-help p-1 transition-colors">
            <LucideIcon name="HelpCircle" size={14} />
          </div>
          <div className="absolute right-0 bottom-full mb-2 w-56 p-2.5 rounded-xs bg-[#111] border border-art-border shadow-2xl text-[10px] text-gray-300 font-medium leading-relaxed opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-200 z-50">
            <strong className="text-brand-orange block mb-1">Sesli Komut Örnekleri:</strong>
            <ul className="list-disc pl-3.5 space-y-1 text-gray-400">
              <li>"3 kedi maması sat"</li>
              <li>"köpek tasması" (1 adet ekler)</li>
              <li>"iki adet kuş yemi"</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Realtime voice output display */}
      <AnimatePresence>
        {(transcript || feedback) && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="mt-3 pt-3 border-t border-art-border/40 flex flex-col gap-1.5"
          >
            {transcript && (
              <div className="flex items-center gap-1.5">
                <span className="text-[8px] font-extrabold uppercase tracking-widest text-gray-500">Söylenen:</span>
                <p className="text-xs font-bold italic text-gray-300 font-serif">"{transcript}"</p>
              </div>
            )}

            {feedback && (
              <div className="flex items-center gap-1.5">
                <span className={`text-[8px] font-black uppercase tracking-widest ${
                  status === 'success' ? 'text-[#10b981]' : status === 'error' ? 'text-[#f43f5e]' : 'text-gray-500'
                }`}>
                  {status === 'success' ? '✔ Başarılı:' : status === 'error' ? '✖ Hata:' : 'Durum:'}
                </span>
                <p className={`text-xs font-extrabold tracking-wide ${
                  status === 'success' ? 'text-[#10b981]' : status === 'error' ? 'text-[#f43f5e]' : 'text-gray-300'
                }`}>
                  {feedback}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
