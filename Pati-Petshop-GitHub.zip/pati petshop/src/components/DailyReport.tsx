/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { Sale, PetCategory } from '../types';
import { sounds } from '../utils/sound';
import LucideIcon from './LucideIcon';

interface DailyReportProps {
  sales: Sale[];
  onResetSales: () => void;
  onDeleteSale: (id: string) => void;
  triggerParticles: () => void;
}

const CATEGORY_COLORS: Record<PetCategory, string> = {
  dog: '#f97316',   // Brand Orange
  cat: '#ec4899',   // Pink
  bird: '#10b981',  // Emerald
  fish: '#0ea5e9',  // Sky
  other: '#6366f1', // Indigo
};

const CustomPieTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="rounded-xs border border-art-border bg-[#151515] p-3 shadow-xl">
        <p className="text-xs font-bold uppercase tracking-widest text-brand-orange flex items-center gap-1">
          <span>{data.emoji}</span>
          <span>{data.name}</span>
        </p>
        <p className="mt-1.5 font-mono text-sm font-black text-art-light">
          ₺{data.value.toLocaleString('tr-TR')}
        </p>
        <p className="text-[9px] text-gray-500 uppercase tracking-widest font-semibold mt-0.5">Toplam Kategori Cirosu</p>
      </div>
    );
  }
  return null;
};

export default function DailyReport({ sales, onResetSales, onDeleteSale, triggerParticles }: DailyReportProps) {
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [deletingSaleId, setDeletingSaleId] = useState<string | null>(null);

  // Filter sales for today (local date calendar day)
  const todayStr = new Date().toDateString();
  const todaySales = sales.filter(s => new Date(s.createdAt).toDateString() === todayStr);

  // Sort today's transactions to show latest first
  const latestTodaySales = [...todaySales].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // 1. EOD Key Indicators
  const todayRevenue = todaySales.reduce((sum, s) => sum + s.totalPrice, 0);
  const todayTxCount = todaySales.length;
  const todayItemCount = todaySales.reduce((sum, s) => sum + s.quantity, 0);
  const averageTicket = todayTxCount > 0 ? Math.round(todayRevenue / todayTxCount) : 0;

  // 2. Neler Sattım (Product Breakdown)
  const productSummary = (() => {
    const summaryMap: Record<string, { name: string; category: PetCategory; qty: number; total: number }> = {};
    todaySales.forEach((s) => {
      if (!summaryMap[s.productName]) {
        summaryMap[s.productName] = { name: s.productName, category: s.category, qty: 0, total: 0 };
      }
      summaryMap[s.productName].qty += s.quantity;
      summaryMap[s.productName].total += s.totalPrice;
    });
    return Object.values(summaryMap).sort((a, b) => b.qty - a.qty); // sorted by highest qty
  })();

  // Find best selling product name
  const bestProduct = productSummary.length > 0 ? productSummary[0] : null;

  // 3. Hangi Saatte Ne Kadar Sattım (Hourly Breakdown)
  const hourlySummary = (() => {
    const hourlyMap: Record<number, { hour: number; txCount: number; qty: number; revenue: number }> = {};
    
    // Seed all hours from 0 to 23 (we will filter active ones or show all)
    // To keep it high-contrast and readable, we can focus on active hours
    todaySales.forEach((s) => {
      const dateObj = new Date(s.createdAt);
      const hour = dateObj.getHours(); // 0 to 23
      if (!hourlyMap[hour]) {
        hourlyMap[hour] = { hour, txCount: 0, qty: 0, revenue: 0 };
      }
      hourlyMap[hour].txCount += 1;
      hourlyMap[hour].qty += s.quantity;
      hourlyMap[hour].revenue += s.totalPrice;
    });

    return Object.values(hourlyMap).sort((a, b) => a.hour - b.hour); // chronological
  })();

  const formatHourString = (hour: number) => {
    const nextHour = (hour + 1) % 24;
    return `${hour.toString().padStart(2, '0')}:00 - ${nextHour.toString().padStart(2, '0')}:00`;
  };

  const getCategoryEmoji = (cat: PetCategory) => {
    switch (cat) {
      case 'cat': return '🐱';
      case 'dog': return '🐶';
      case 'bird': return '🐦';
      case 'fish': return '🐟';
      default: return '🐾';
    }
  };

  // Kategoriye Göre Satış Dağılımı (Pie Chart Data)
  const categorySummary = useMemo(() => {
    const summaryMap: Record<PetCategory, { name: string; categoryKey: PetCategory; value: number; emoji: string }> = {
      dog: { name: 'Köpek', categoryKey: 'dog', value: 0, emoji: '🐶' },
      cat: { name: 'Kedi', categoryKey: 'cat', value: 0, emoji: '🐱' },
      bird: { name: 'Kuş', categoryKey: 'bird', value: 0, emoji: '🐦' },
      fish: { name: 'Balık', categoryKey: 'fish', value: 0, emoji: '🐟' },
      other: { name: 'Diğer', categoryKey: 'other', value: 0, emoji: '🐾' },
    };

    todaySales.forEach((s) => {
      if (summaryMap[s.category]) {
        summaryMap[s.category].value += s.totalPrice;
      }
    });

    return Object.values(summaryMap).filter((item) => item.value > 0);
  }, [todaySales]);

  // Ödeme Yöntemi Dağılımı
  const paymentSummary = useMemo(() => {
    let cashTotal = 0;
    let cardTotal = 0;
    todaySales.forEach((s) => {
      if (s.paymentMethod === 'card') {
        cardTotal += s.totalPrice;
      } else {
        cashTotal += s.totalPrice;
      }
    });
    return { cashTotal, cardTotal };
  }, [todaySales]);

  // 4. Download / Export EOD report as text
  const downloadReport = () => {
    sounds.playSuccess();
    
    let text = `==================================================\n`;
    text += `         PATİ PETSHOP GÜN SONU SATIŞ RAPORU       \n`;
    text += `         Tarih: ${new Date().toLocaleDateString('tr-TR')} (Bugün)       \n`;
    text += `==================================================\n\n`;
    
    text += `GENEL ÖZET METRİKLERİ:\n`;
    text += `--------------------------------------------------\n`;
    text += `Toplam Günlük Ciro        : ₺${todayRevenue.toLocaleString('tr-TR')}\n`;
    text += `Nakit Ödeme Toplamı       : ₺${paymentSummary.cashTotal.toLocaleString('tr-TR')}\n`;
    text += `Kart Ödeme Toplamı        : ₺${paymentSummary.cardTotal.toLocaleString('tr-TR')}\n`;
    text += `Toplam İşlem Adedi        : ${todayTxCount} adet\n`;
    text += `Toplam Satılan Ürün Adedi : ${todayItemCount} adet\n`;
    text += `Ortalama Sepet Tutarı     : ₺${averageTicket.toLocaleString('tr-TR')}\n`;
    if (bestProduct) {
      text += `En Çok Satan Ürün         : ${bestProduct.name} (${bestProduct.qty} adet)\n`;
    }
    text += `\n\n`;

    text += `NELER SATILDI? (MİKTAR ve TUTAR):\n`;
    text += `--------------------------------------------------\n`;
    if (productSummary.length === 0) {
      text += `Bugün henüz bir satış yapılmadı.\n`;
    } else {
      productSummary.forEach((p, idx) => {
        text += `${idx + 1}. [${p.category.toUpperCase()}] ${p.name}\n`;
        text += `   Miktar: ${p.qty} adet | Toplam Ciro: ₺${p.total}\n`;
      });
    }
    text += `\n\n`;

    text += `SAATLİK SATIŞ DAĞILIMI:\n`;
    text += `--------------------------------------------------\n`;
    if (hourlySummary.length === 0) {
      text += `Bugün henüz bir satış yapılmadı.\n`;
    } else {
      hourlySummary.forEach((h) => {
        text += `${formatHourString(h.hour)} -> ${h.txCount} İşlem | ${h.qty} Ürün | ₺${h.revenue} Ciro\n`;
      });
    }
    text += `\n\n`;
    text += `==================================================\n`;
    text += `Rapor Oluşturma Saati: ${new Date().toLocaleTimeString('tr-TR')}\n`;
    text += `Sistem: Pati Petshop Panel v1.0\n`;
    text += `==================================================\n`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Pati_Petshop_Gun_Sonu_Raporu_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    triggerParticles();
  };

  const downloadCSVReport = () => {
    sounds.playSuccess();
    
    // Header Row with clean columns
    const headers = [
      'Tarih',
      'Saat',
      'Urun veya Hizmet Adi',
      'Kategori',
      'Birim Fiyat (TL)',
      'Adet',
      'Toplam Tutar (TL)',
      'Odeme Yontemi',
      'Notlar veya Aciklama'
    ];

    const rows = todaySales.map(s => {
      const dateObj = new Date(s.createdAt);
      const dateStr = dateObj.toLocaleDateString('tr-TR');
      const timeStr = dateObj.toLocaleTimeString('tr-TR');
      return [
        dateStr,
        timeStr,
        `"${s.productName.replace(/"/g, '""')}"`,
        s.category.toUpperCase(),
        s.price,
        s.quantity,
        s.totalPrice,
        s.paymentMethod === 'card' ? 'Kredi Kartı' : 'Nakit',
        s.notes ? `"${s.notes.replace(/"/g, '""')}"` : ''
      ];
    });

    // UTF-8 BOM representation so Excel correctly preserves Turkish characters on load
    const csvContent = "\uFEFF" + [headers.join(';'), ...rows.map(r => r.join(';'))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Pati_Petshop_Detayli_Satis_Raporu_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    triggerParticles();
  };

  const handleConfirmReset = () => {
    sounds.playSuccess();
    onResetSales();
    setShowConfirmReset(false);
    triggerParticles();
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Top Banner Action Panel */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-xs border border-art-border bg-art-card p-6 shadow-md">
        <div>
          <h3 className="font-serif italic text-2xl font-normal text-brand-orange">
            Gün Sonu Rapor Modülü
          </h3>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1 font-bold">
            Bugün ({new Date().toLocaleDateString('tr-TR')}) gerçekleşen tüm satış verileri
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          {/* Export to CSV/Excel */}
          <button
            onClick={downloadCSVReport}
            className="flex items-center gap-1.5 rounded-xs border border-emerald-500/50 bg-emerald-950/20 hover:bg-emerald-500 hover:text-black px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-emerald-400 transition-all cursor-pointer shadow-md shadow-emerald-950/30"
          >
            <LucideIcon name="FileSpreadsheet" size={14} />
            <span>Raporu Dışa Aktar (Excel / CSV)</span>
          </button>

          {/* Download EOD report */}
          <button
            onClick={downloadReport}
            className="flex items-center gap-1.5 rounded-xs border border-brand-orange bg-transparent hover:bg-brand-orange hover:text-black px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-brand-orange transition-all cursor-pointer shadow-md"
          >
            <LucideIcon name="FileText" size={14} />
            <span>Raporu İndir (.TXT)</span>
          </button>

          {/* Close Register / Reset */}
          {!showConfirmReset ? (
            <button
              onClick={() => {
                sounds.playClick();
                setShowConfirmReset(true);
              }}
              className="flex items-center gap-1.5 rounded-xs bg-rose-600 hover:bg-rose-700 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white transition-all cursor-pointer shadow-md"
            >
              <LucideIcon name="Clock" size={14} />
              <span>Kasa Kapat (Gün Sonu Sıfırla)</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 rounded-xs bg-rose-950/40 border border-rose-900/50 p-1.5">
              <span className="text-[9px] font-bold uppercase tracking-widest text-rose-300 px-2 leading-none">
                Emin misiniz? Tüm geçmiş silinecektir!
              </span>
              <button
                onClick={handleConfirmReset}
                className="rounded-xs bg-rose-600 hover:bg-rose-700 px-3 py-1 text-[9px] font-bold uppercase tracking-wider text-white cursor-pointer"
              >
                Evet, Sıfırla
              </button>
              <button
                onClick={() => {
                  sounds.playClick();
                  setShowConfirmReset(false);
                }}
                className="rounded-xs bg-[#222] border border-art-border hover:bg-[#333] px-3 py-1 text-[9px] font-bold uppercase tracking-wider text-gray-400 cursor-pointer"
              >
                İptal
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Grid: EOD Indicators */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1 */}
        <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-md border-l-4 border-l-brand-orange relative overflow-hidden">
          <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-brand-orange/5 blur-xl" />
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Bugünkü Ciro</p>
          <h3 className="mt-2 font-mono text-3xl font-extrabold text-brand-orange tracking-tight">
            ₺{todayRevenue.toLocaleString('tr-TR')}
          </h3>
          <div className="mt-2 text-[9px] text-gray-400 uppercase font-semibold">
            Kasaya giren nakit/kart toplam
          </div>
        </div>

        {/* Metric 2 */}
        <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-md border-l-4 border-l-emerald-500 relative overflow-hidden">
          <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-emerald-500/5 blur-xl" />
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Müşteri / İşlem</p>
          <h3 className="mt-2 font-mono text-3xl font-extrabold text-art-light tracking-tight">
            {todayTxCount} Adet
          </h3>
          <div className="mt-2 text-[9px] text-gray-400 uppercase font-semibold">
            Onaylanan toplam fiş sayısı
          </div>
        </div>

        {/* Metric 3 */}
        <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-md border-l-4 border-l-sky-500 relative overflow-hidden">
          <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-sky-500/5 blur-xl" />
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Ortalama Sepet</p>
          <h3 className="mt-2 font-mono text-3xl font-extrabold text-art-light tracking-tight">
            ₺{averageTicket.toLocaleString('tr-TR')}
          </h3>
          <div className="mt-2 text-[9px] text-gray-400 uppercase font-semibold">
            İşlem başına düşen tutar
          </div>
        </div>

        {/* Metric 4 */}
        <div className="rounded-xs border border-art-border bg-art-card p-6 shadow-md border-l-4 border-l-purple-500 relative overflow-hidden">
          <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-purple-500/5 blur-xl" />
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">En Çok Satan Ürün</p>
          <h3 className="mt-2 font-sans text-lg font-bold text-art-light tracking-tight truncate" title={bestProduct?.name || 'Veri Yok'}>
            {bestProduct ? bestProduct.name : 'Yok 🐾'}
          </h3>
          <div className="mt-2 text-[9px] text-brand-orange uppercase font-extrabold">
            {bestProduct ? `${bestProduct.qty} Adet Satıldı` : 'Satış yapılmadı'}
          </div>
        </div>
      </div>

      {/* Detailed Analysis Section (Row 1: Product Breakdown & Category Sales Distribution Pie Chart) */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 items-stretch">
        
        {/* Neler Sattım List (7 Columns) */}
        <div className="lg:col-span-7 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col justify-between">
          <div>
            <div className="mb-4 flex items-center gap-3 border-b border-art-border pb-4">
              <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
                <LucideIcon name="ShoppingBag" size={16} />
              </div>
              <div>
                <h3 className="font-serif italic text-lg text-brand-orange">
                  Neler Sattım? (Bugün Satılanlar)
                </h3>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-0.5">Bugün en çok satılan ürünler sıralı listesi</p>
              </div>
            </div>

            {productSummary.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <p className="text-xs font-bold uppercase tracking-widest text-gray-500">Bugün henüz hiçbir satış girilmedi</p>
                <p className="mt-2 text-[10px] text-gray-600 uppercase tracking-wider font-semibold max-w-[280px]">
                  Hızlı satış ekranından satışı tamamlayarak gün sonu raporlarını anlık izleyebilirsiniz! 🐾
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-art-border pb-2 text-[9px] font-extrabold uppercase tracking-widest text-brand-orange">
                      <th className="py-2">Ürün Adı</th>
                      <th className="py-2 text-center">Kategori</th>
                      <th className="py-2 text-center">Satış Adedi</th>
                      <th className="py-2 text-right">Elde Edilen Tutar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-art-border/30 text-xs font-semibold text-art-light">
                    {productSummary.map((p, idx) => (
                      <tr key={idx} className="hover:bg-[#1a1a1a] transition-colors group">
                        <td className="py-3 font-bold pr-2">
                          {p.name}
                        </td>
                        <td className="py-3 text-center">
                          <span className="inline-block bg-[#222] border border-art-border rounded-xs px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-gray-400">
                            {getCategoryEmoji(p.category)} {p.category.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3 text-center font-mono font-bold text-art-light">
                          {p.qty} Adet
                        </td>
                        <td className="py-3 text-right font-mono font-bold text-brand-orange">
                          ₺{p.total.toLocaleString('tr-TR')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Kategorilere Göre Satış Dağılımı (Pie Chart - 5 Columns) */}
        <div className="lg:col-span-5 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col justify-between">
          <div>
            <div className="mb-5 flex items-center gap-3 border-b border-art-border pb-4">
              <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
                <LucideIcon name="PieChart" size={16} />
              </div>
              <div>
                <h3 className="font-serif italic text-lg text-brand-orange">
                  Kategori Satış Dağılımı
                </h3>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-0.5">Kategorilere göre günlük ciro paylaşımı</p>
              </div>
            </div>

            {categorySummary.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <p className="text-xs font-bold uppercase tracking-widest text-gray-500">Dağılım verisi yok</p>
                <p className="mt-2 text-[10px] text-gray-600 uppercase tracking-wider font-semibold max-w-[200px]">
                  Satış yaptıkça kategori bazlı pasta grafiğiniz burada çizilecektir.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-6">
                {/* Pie Chart Display */}
                <div className="w-full h-44 relative flex justify-center items-center">
                  <div className="w-44 h-44 relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categorySummary}
                          cx="50%"
                          cy="50%"
                          innerRadius={52}
                          outerRadius={70}
                          paddingAngle={4}
                          dataKey="value"
                        >
                          {categorySummary.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.categoryKey] || '#6366f1'} />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomPieTooltip />} />
                      </PieChart>
                    </ResponsiveContainer>
                    {/* Center text of donut */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <span className="text-[9px] text-gray-500 uppercase tracking-widest font-extrabold leading-none">CİRO</span>
                      <span className="font-mono text-sm font-black text-brand-orange mt-1">
                        ₺{todayRevenue.toLocaleString('tr-TR')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Custom Legend layout */}
                <div className="flex flex-col gap-2 w-full">
                  {categorySummary.map((item, idx) => {
                    const percentage = todayRevenue > 0 ? ((item.value / todayRevenue) * 100).toFixed(1) : '0';
                    const color = CATEGORY_COLORS[item.categoryKey] || '#6366f1';
                    return (
                      <div key={idx} className="flex items-center justify-between p-2 rounded-xs border border-art-border/30 bg-[#141414] hover:bg-[#1c1c1c] transition-colors">
                        <div className="flex items-center gap-2">
                          <span className="text-xs">{item.emoji}</span>
                          <span className="text-xs font-bold text-gray-300">{item.name}</span>
                          <span className="text-[9px] rounded-xs px-1.5 py-0.2 bg-[#222] border border-art-border text-gray-500 font-mono">
                            %{percentage}
                          </span>
                        </div>
                        <span className="font-mono text-xs font-extrabold" style={{ color }}>
                          ₺{item.value.toLocaleString('tr-TR')}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Ödeme Yöntemi Dağılımı */}
                <div className="mt-6 pt-5 border-t border-art-border/40">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-brand-orange mb-3 flex items-center gap-1.5">
                    <LucideIcon name="Wallet" size={12} />
                    <span>Ödeme Yöntemi Dağılımı</span>
                  </h4>
                  <div className="flex flex-col gap-2">
                    {todayRevenue > 0 ? (
                      <>
                        <div className="flex items-center justify-between text-[10px] font-bold text-gray-400">
                          <span className="flex items-center gap-1">💵 Nakit</span>
                          <span className="flex items-center gap-1">Kredi Kartı 💳</span>
                        </div>
                        <div className="w-full h-3.5 rounded-xs bg-[#141414] border border-art-border/30 overflow-hidden flex">
                          <div 
                            style={{ width: `${(paymentSummary.cashTotal / todayRevenue) * 100}%` }}
                            className="bg-brand-orange h-full transition-all duration-500"
                            title={`Nakit: ₺${paymentSummary.cashTotal}`}
                          />
                          <div 
                            style={{ width: `${(paymentSummary.cardTotal / todayRevenue) * 100}%` }}
                            className="bg-[#22d3ee] h-full transition-all duration-500"
                            title={`Kredi Kartı: ₺${paymentSummary.cardTotal}`}
                          />
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-extrabold font-mono mt-1">
                          <span className="text-brand-orange">₺{paymentSummary.cashTotal.toLocaleString('tr-TR')} (%{((paymentSummary.cashTotal / todayRevenue) * 100).toFixed(0)}%)</span>
                          <span className="text-[#22d3ee]">₺{paymentSummary.cardTotal.toLocaleString('tr-TR')} (%{((paymentSummary.cardTotal / todayRevenue) * 100).toFixed(0)}%)</span>
                        </div>
                      </>
                    ) : (
                      <p className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold">Ödeme yöntemi verisi bulunmuyor.</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Detailed Analysis Section (Row 2: Hourly Sales Breakdown & Return Ledger) */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 items-stretch">
        
        {/* Hangi Saatte Ne Kadar Sattım List (5 Columns) */}
        <div className="lg:col-span-5 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col justify-between">
          <div>
            <div className="mb-4 flex items-center gap-3 border-b border-art-border pb-4">
              <div className="rounded-xs bg-[#222] p-2 text-brand-orange border border-art-border">
                <LucideIcon name="TrendingUp" size={16} />
              </div>
              <div>
                <h3 className="font-serif italic text-lg text-brand-orange">
                  Hangi Saatte Ne Kadar Sattım?
                </h3>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-0.5">Saat bazında işlem ve ciro dağılımı</p>
              </div>
            </div>

            {hourlySummary.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <p className="text-xs font-bold uppercase tracking-widest text-gray-500">Kasa saati verisi yok</p>
                <p className="mt-2 text-[10px] text-gray-600 uppercase tracking-wider font-semibold max-w-[200px]">
                  Satış girdikçe saatlik ciro trendiniz burada belirecektir.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5 max-h-[360px] overflow-y-auto scrollbar-none pr-1">
                {hourlySummary.map((h, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 border border-art-border bg-[#151515] hover:border-brand-orange/40 transition-colors rounded-xs">
                    <div className="flex flex-col">
                      <span className="font-mono text-xs font-bold text-brand-orange">
                        {formatHourString(h.hour)}
                      </span>
                      <span className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mt-1">
                        {h.txCount} Fiş | {h.qty} Ürün Satışı
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-sm font-black text-art-light">
                        ₺{h.revenue.toLocaleString('tr-TR')}
                      </span>
                      <span className="block text-[8px] text-gray-600 font-bold uppercase tracking-wider mt-0.5">
                        Toplam Ciro
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Bugün Gerçekleşen İşlemler (Satış İadesi ve Yanlış Tıklama Silme) (7 Columns) */}
        <div className="lg:col-span-7 rounded-xs border border-art-border bg-art-card p-6 shadow-lg shadow-black/40 flex flex-col justify-between">
          <div>
            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-art-border pb-4">
              <div className="flex items-center gap-3">
                <div className="rounded-xs bg-[#222] p-2 text-rose-500 border border-art-border">
                  <LucideIcon name="Undo2" size={16} />
                </div>
                <div>
                  <h3 className="font-serif italic text-lg text-rose-400">
                    Bugün Gerçekleşen Satışlar (İade ve İptal)
                  </h3>
                  <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">
                    Yanlış girilen veya iade edilen satışları bu listeden kaldırabilirsiniz
                  </p>
                </div>
              </div>
              <span className="rounded-xs bg-[#222] border border-art-border px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-rose-400 self-start sm:self-auto">
                {latestTodaySales.length} Bugünkü Fiş
              </span>
            </div>

            {latestTodaySales.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="mb-3 rounded-xs bg-[#222] border border-art-border p-4 text-gray-600">
                  🐾
                </div>
                <p className="text-xs font-bold uppercase tracking-widest text-gray-500">Bugün henüz hiçbir satış yapılmadı.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[500px] border-collapse text-left">
                  <thead>
                    <tr className="border-b border-art-border pb-3 text-[9px] font-extrabold uppercase tracking-widest text-brand-orange">
                      <th className="py-3 px-2">Saat</th>
                      <th className="py-3 px-2">Ürün / Hizmet</th>
                      <th className="py-3 px-2 text-center">Kategori</th>
                      <th className="py-3 px-2 text-right">Birim x Adet</th>
                      <th className="py-3 px-2 text-right">Toplam Fiyat</th>
                      <th className="py-3 px-2 text-center">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-art-border/30 text-xs font-semibold text-art-light">
                    <AnimatePresence mode="popLayout">
                      {latestTodaySales.map((sale) => (
                        <motion.tr
                          key={sale.id}
                          layout
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -30 }}
                          transition={{ duration: 0.2 }}
                          className="group hover:bg-[#1a1a1a] transition-colors"
                        >
                          {/* Timestamp */}
                          <td className="py-3.5 px-2 font-mono text-[11px] text-gray-500 whitespace-nowrap">
                            {new Date(sale.createdAt).toLocaleTimeString('tr-TR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit'
                            })}
                          </td>

                          {/* Product Name */}
                          <td className="py-3.5 px-2 max-w-[150px]">
                            <span className="text-art-light font-bold block truncate" title={sale.productName}>
                              {sale.productName}
                            </span>
                            {sale.notes && (
                              <span className="text-[10px] text-brand-orange block italic leading-none mt-1 truncate" title={sale.notes}>
                                📝 {sale.notes}
                              </span>
                            )}
                          </td>

                          {/* Category */}
                          <td className="py-3.5 px-2 text-center">
                            <span className="inline-flex items-center gap-1 bg-[#222] border border-art-border rounded-xs px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-gray-400">
                              <span>{getCategoryEmoji(sale.category)}</span>
                              <span>{sale.category.toUpperCase()}</span>
                            </span>
                          </td>

                          {/* Unit x Qty */}
                          <td className="py-3.5 px-2 text-right font-mono text-gray-400">
                            ₺{sale.price} x {sale.quantity}
                          </td>

                          {/* Total price */}
                          <td className="py-3.5 px-2 text-right font-mono font-bold text-brand-orange">
                            ₺{sale.totalPrice}
                          </td>

                          {/* Return actions */}
                          <td className="py-3.5 px-2 text-center whitespace-nowrap">
                            {deletingSaleId !== sale.id ? (
                              <button
                                onClick={() => {
                                  sounds.playClick();
                                  setDeletingSaleId(sale.id);
                                }}
                                className="inline-flex items-center gap-1.5 rounded-xs bg-rose-950/40 border border-rose-900/50 hover:bg-rose-900/30 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-rose-400 transition-colors cursor-pointer"
                                title="İade Et / Sil"
                              >
                                <LucideIcon name="Undo" size={11} />
                                <span>İade</span>
                              </button>
                            ) : (
                              <div className="inline-flex items-center gap-1.5 bg-rose-950/40 border border-rose-900/50 p-1 rounded-xs">
                                <button
                                  onClick={() => {
                                    sounds.playDelete();
                                    onDeleteSale(sale.id);
                                    setDeletingSaleId(null);
                                    triggerParticles();
                                  }}
                                  className="rounded-xs bg-rose-600 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white cursor-pointer hover:bg-rose-700 transition-colors"
                                >
                                  Evet
                                </button>
                                <button
                                  onClick={() => {
                                    sounds.playClick();
                                    setDeletingSaleId(null);
                                  }}
                                  className="rounded-xs bg-[#222] border border-art-border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-gray-400 cursor-pointer hover:bg-[#333] transition-colors"
                                >
                                  İptal
                                </button>
                              </div>
                            )}
                          </td>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
