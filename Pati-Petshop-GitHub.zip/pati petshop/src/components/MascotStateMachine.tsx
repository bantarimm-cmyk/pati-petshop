/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sale } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface MascotStateMachineProps {
  sales: Sale[];
  mascotMood: 'sleeping' | 'happy' | 'singing';
  setMascotMood: React.Dispatch<React.SetStateAction<'sleeping' | 'happy' | 'singing'>>;
  onTriggerParticles: (x?: number, y?: number) => void;
}

type MascotEvolutionState = 'sleepy' | 'active' | 'millionaire';
type InteractiveState = MascotEvolutionState | 'hovered' | 'singing' | 'happy';

export default function MascotStateMachine({
  sales,
  mascotMood,
  setMascotMood,
  onTriggerParticles,
}: MascotStateMachineProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  // Calculate total sales volume
  const totalSalesVolume = sales.reduce((sum, sale) => sum + sale.totalPrice, 0);

  // Determine base evolution state based on sales volume
  let evolutionState: MascotEvolutionState = 'sleepy';
  if (totalSalesVolume >= 1000) {
    evolutionState = 'millionaire';
  } else if (totalSalesVolume >= 250) {
    evolutionState = 'active';
  }

  // Determine current active display state
  let currentState: InteractiveState = evolutionState;
  if (mascotMood === 'singing') {
    currentState = 'singing';
  } else if (mascotMood === 'happy') {
    currentState = 'happy';
  } else if (isHovered) {
    currentState = 'hovered';
  }

  // Handle interactions
  const handleMouseEnter = () => {
    setIsHovered(true);
    // Play tail wag or purr
    if (evolutionState === 'sleepy') {
      sounds.playRustle(); // Soft rustle for sleepy waking up
    } else {
      sounds.playTailWag(); // Tail wag for active/wealthy
    }
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const handleMascotClick = (e: React.MouseEvent) => {
    setClickCount((prev) => prev + 1);
    
    // Select sound based on state
    if (evolutionState === 'millionaire') {
      sounds.playSuccess();
    } else {
      const soundArray = [
        () => sounds.playMeow(),
        () => sounds.playBark(),
        () => sounds.playChirp(),
        () => sounds.playBubble(),
      ];
      const randomSound = soundArray[Math.floor(Math.random() * soundArray.length)];
      randomSound();
    }

    setMascotMood('singing');
    onTriggerParticles(e.clientX, e.clientY);
    
    setTimeout(() => {
      setMascotMood('happy');
    }, 800);

    setTimeout(() => {
      setMascotMood('sleeping');
    }, 3000);
  };

  // Get visual config based on state
  const getStateConfig = (state: InteractiveState) => {
    switch (state) {
      case 'singing':
        return {
          emoji: '🎶🐶',
          name: 'Şarkıcı Pati',
          desc: 'Melodik havlamalar dükkanı çınlatıyor!',
          bg: 'from-pink-950/20 to-art-card border-pink-500/30',
          accent: 'text-pink-400',
          animation: {
            scale: [1, 1.12, 0.95, 1.15, 1],
            rotate: [0, -12, 12, -8, 8, 0],
            transition: { duration: 0.6, repeat: Infinity },
          },
          phrase: 'Cha-ching! 💸 Satış melodisi harika geliyor kulaklarıma! Hav, hav!',
        };
      case 'happy':
        return {
          emoji: '🐾🥰',
          name: 'Mutlu Pati',
          desc: 'Son satıştan ötürü çok neşeli!',
          bg: 'from-emerald-950/20 to-art-card border-emerald-500/30',
          accent: 'text-emerald-400',
          animation: {
            y: [0, -8, 0],
            transition: { duration: 0.4, repeat: 3 },
          },
          phrase: 'Nefis! Bir pet dostumuz daha mutlu ayrıldı! Mama ödülümü kaparım! 🍖',
        };
      case 'hovered':
        return {
          emoji: '👀🐾',
          name: 'Meraklı Pati',
          desc: 'İmleci takip ediyor, oyun istiyor!',
          bg: 'from-orange-950/20 to-art-card border-brand-orange/30',
          accent: 'text-brand-orange',
          animation: {
            rotate: [0, -6, 6, -3, 3, 0],
            transition: { duration: 0.5, repeat: Infinity },
          },
          phrase: 'Aha! O hareket eden de ne? Ödül maması mı vereceksin bana? 🦴🐾',
        };
      case 'millionaire':
        return {
          emoji: '👑🦁✨',
          name: 'Milyoner Pati',
          desc: 'Dükkan rekor kırıyor! Taç giyme töreni vakti!',
          bg: 'from-amber-950/30 to-art-card border-amber-500/50 shadow-lg shadow-amber-500/5',
          accent: 'text-amber-400',
          animation: {
            scale: [1, 1.08, 0.96, 1.05, 1],
            y: [0, -4, 2, -4, 0],
            transition: { duration: 1.2, repeat: Infinity },
          },
          phrase: 'KRAL BİZİZ! 👑 Dükkan doldu taştı, altın mamalar gelsin! 💎✨',
        };
      case 'active':
        return {
          emoji: '🐕⚡',
          name: 'Aktif Pati',
          desc: 'Satışlar canlı, enerjisi tam yerinde!',
          bg: 'from-sky-950/20 to-art-card border-sky-500/30',
          accent: 'text-sky-400',
          animation: {
            scaleX: [1, 1.04, 0.98, 1],
            scaleY: [1, 0.96, 1.04, 1],
            transition: { duration: 1.5, repeat: Infinity },
          },
          phrase: 'İşler yolunda gidiyor! Gözüm kasada, kulaklarım seslerde! 🐕🔊',
        };
      case 'sleepy':
      default:
        return {
          emoji: '😴💤',
          name: 'Uykucu Pati',
          desc: 'Sakin dükkan günü, rahatça mayışıyor.',
          bg: 'from-indigo-950/10 to-art-card border-art-border',
          accent: 'text-indigo-400/80',
          animation: {
            scale: [1, 0.97, 1.02, 1],
            transition: { duration: 3, repeat: Infinity, ease: 'easeInOut' },
          },
          phrase: 'Zzz... Dükkan çok sakin. Sıcak bir minder ve şekerleme gibisi yok...',
        };
    }
  };

  const config = getStateConfig(currentState);

  // Calculate progress to next state
  let nextStateThreshold = 250;
  let nextStateLabel = 'Aktif Pati';
  let progressPercentage = Math.min((totalSalesVolume / 250) * 100, 100);

  if (totalSalesVolume >= 250 && totalSalesVolume < 1000) {
    nextStateThreshold = 1000;
    nextStateLabel = 'Milyoner Pati';
    progressPercentage = Math.min(((totalSalesVolume - 250) / (1000 - 250)) * 100, 100);
  } else if (totalSalesVolume >= 1000) {
    nextStateThreshold = 5000;
    nextStateLabel = 'Efsanevi Ejderha Pati 🐉';
    progressPercentage = Math.min((totalSalesVolume / 5000) * 100, 100);
  }

  return (
    <div className={`rounded-xs border p-4 shadow-xl shadow-black/30 transition-all duration-300 ${config.bg}`}>
      <div className="flex flex-col gap-3.5">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-art-border/40 pb-2.5">
          <div className="flex items-center gap-2">
            <span className={`p-1.5 rounded-xs bg-[#111] border border-art-border ${config.accent}`}>
              <LucideIcon name="Workflow" size={14} />
            </span>
            <div>
              <h4 className="text-xs font-black uppercase tracking-wider text-white">
                Mascot Durum Makinesi
              </h4>
              <p className="text-[8px] text-gray-500 font-extrabold uppercase tracking-widest mt-0.5">
                Mevcut Mod: {config.name}
              </p>
            </div>
          </div>

          <span className="rounded-xs bg-brand-orange/15 border border-brand-orange/30 px-2 py-0.5 text-[8px] font-black text-brand-orange uppercase tracking-wider">
            Sürüm 1.2
          </span>
        </div>

        {/* Mascot Interactive Showcase */}
        <div className="flex items-center gap-4 bg-black/25 rounded-xs border border-art-border/30 p-3 relative overflow-hidden">
          {/* Spring animation visual element */}
          <motion.div
            animate={config.animation}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            onClick={handleMascotClick}
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xs bg-[#222] border border-art-border text-2xl cursor-pointer relative shadow-md shadow-black/50 select-none hover:border-brand-orange/50 active:scale-95 transition-colors"
            title="Mascotu sevmek için fareyi gezdir, tıklatarak neşelendir!"
          >
            <span>{config.emoji}</span>
            
            {/* Soft pulsing heart or badge overlay */}
            {currentState === 'happy' && (
              <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white shadow-sm shadow-rose-950 animate-bounce">
                ❤
              </span>
            )}
            {currentState === 'hovered' && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-orange text-[9px] font-bold text-black border border-black/40">
                ❓
              </span>
            )}
            {currentState === 'singing' && (
              <span className="absolute -top-1.5 -right-1.5 text-xs font-bold text-pink-500 animate-ping">
                ♫
              </span>
            )}
            {currentState === 'millionaire' && (
              <span className="absolute -bottom-1 -left-1 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-[8px] font-bold text-black border border-black/20 animate-spin-slow">
                ⭐
              </span>
            )}
          </motion.div>

          {/* Dialog bubble */}
          <div className="flex flex-col gap-1 z-10">
            <div className="flex items-center gap-1.5">
              <span className={`text-[9px] font-black uppercase tracking-widest ${config.accent}`}>
                {config.name}
              </span>
              <span className="text-[7px] font-extrabold text-gray-500 uppercase tracking-widest">
                Tıklama: {clickCount}
              </span>
            </div>
            <p className="text-[10px] text-gray-300 font-bold font-serif italic leading-snug">
              "{config.phrase}"
            </p>
          </div>

          {/* Grid Background accent */}
          <div className="absolute right-0 top-0 bottom-0 w-24 opacity-5 pointer-events-none bg-grid" />
        </div>

        {/* State Machine Status Panel & Evolution Progress */}
        <div className="flex flex-col gap-2.5 bg-[#141414]/50 rounded-xs border border-art-border/30 p-2.5">
          <div className="flex items-center justify-between text-[9px] font-extrabold uppercase tracking-wider text-gray-400">
            <span>Pati Seviyesi İlerlemesi</span>
            <span className="font-mono text-white">
              {Math.round(totalSalesVolume)} / {nextStateThreshold} TL
            </span>
          </div>

          {/* Custom micro progress bar */}
          <div className="h-2 w-full rounded-full bg-black border border-art-border overflow-hidden p-0.5">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className={`h-full rounded-full bg-gradient-to-r ${
                evolutionState === 'millionaire'
                  ? 'from-amber-500 to-yellow-400'
                  : evolutionState === 'active'
                  ? 'from-sky-500 to-indigo-500'
                  : 'from-brand-orange to-red-500'
              }`}
            />
          </div>

          {/* Evolution Thresholds helper info */}
          <div className="grid grid-cols-3 gap-1.5 text-[7px] font-black uppercase tracking-widest text-gray-500 text-center border-t border-art-border/30 pt-2 mt-1">
            <div className={`flex flex-col gap-0.5 p-1 rounded-xs ${evolutionState === 'sleepy' ? 'bg-indigo-950/20 border border-indigo-900/30 text-indigo-400' : ''}`}>
              <span>Uykucu</span>
              <span className="font-mono text-[8px]">&lt; 250TL</span>
            </div>
            <div className={`flex flex-col gap-0.5 p-1 rounded-xs ${evolutionState === 'active' ? 'bg-sky-950/20 border border-sky-900/30 text-sky-400' : ''}`}>
              <span>Aktif</span>
              <span className="font-mono text-[8px]">250TL+</span>
            </div>
            <div className={`flex flex-col gap-0.5 p-1 rounded-xs ${evolutionState === 'millionaire' ? 'bg-amber-950/20 border border-amber-900/30 text-amber-400' : ''}`}>
              <span>Milyoner</span>
              <span className="font-mono text-[8px]">1000TL+</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
