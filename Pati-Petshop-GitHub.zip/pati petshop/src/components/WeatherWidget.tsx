/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CatalogItem } from '../types';
import LucideIcon from './LucideIcon';
import { sounds } from '../utils/sound';

interface WeatherWidgetProps {
  catalog: CatalogItem[];
  onHighlightProducts: (itemIds: string[], type: string, cityName: string) => void;
  activeHighlight: {
    itemIds: string[];
    type: string;
    cityName: string;
  } | null;
}

interface CityConfig {
  name: string;
  lat: number;
  lon: number;
  description: string;
}

const CITIES: CityConfig[] = [
  { name: 'Dalaman', lat: 36.7641, lon: 28.8028, description: 'Merkez Şube (Muğla)' },
  { name: 'Ortaca', lat: 36.8333, lon: 28.7667, description: 'Komşu Şube (Muğla)' },
  { name: 'Fethiye', lat: 36.6219, lon: 29.1164, description: 'Ölüdeniz Şubesi' },
  { name: 'Bodrum', lat: 37.0344, lon: 27.4305, description: 'Marina Şubesi' },
  { name: 'Marmaris', lat: 36.8550, lon: 28.2742, description: 'Körfez Şubesi' },
  { name: 'Menteşe', lat: 37.2153, lon: 28.3636, description: 'Muğla Merkez Şube' },
  { name: 'Datça', lat: 36.7262, lon: 27.6835, description: 'Bademli Şube' },
];

export default function WeatherWidget({ catalog, onHighlightProducts, activeHighlight }: WeatherWidgetProps) {
  const [selectedCityName, setSelectedCityName] = useState<string>(() => {
    return localStorage.getItem('pati_weather_city') || 'Dalaman';
  });
  
  const [weatherData, setWeatherData] = useState<{
    temp: number;
    humidity: number;
    windSpeed: number;
    code: number;
    conditionType: 'sunny' | 'rainy' | 'snowy' | 'windy' | 'normal';
    conditionLabel: string;
    icon: string;
  } | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedCity = CITIES.find(c => c.name === selectedCityName) || CITIES[0];

  useEffect(() => {
    localStorage.setItem('pati_weather_city', selectedCityName);
    fetchWeather(selectedCity);
  }, [selectedCityName]);

  const fetchWeather = async (city: CityConfig) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m`
      );
      if (!response.ok) {
        throw new Error('Hava durumu verisi alınamadı.');
      }
      const data = await response.json();
      const current = data.current;
      
      const temp = Math.round(current.temperature_2m);
      const humidity = current.relative_humidity_2m;
      const windSpeed = Math.round(current.wind_speed_10m);
      const code = current.weather_code;

      // Classify weather code based on WMO codes
      let conditionType: 'sunny' | 'rainy' | 'snowy' | 'windy' | 'normal' = 'normal';
      let conditionLabel = 'Bulutlu / Ilık';
      let icon = 'Cloud';

      if (windSpeed > 24) {
        conditionType = 'windy';
        conditionLabel = 'Rüzgarlı & Fırtınalı';
        icon = 'Wind';
      } else if (code >= 71 && code <= 86) {
        conditionType = 'snowy';
        conditionLabel = 'Karlı & Soğuk';
        icon = 'Snowflake';
      } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code === 95) {
        conditionType = 'rainy';
        conditionLabel = 'Yağmurlu & Islak';
        icon = 'CloudRain';
      } else if (code === 0 || code === 1) {
        conditionType = 'sunny';
        conditionLabel = temp > 28 ? 'Aşırı Sıcak & Güneşli' : 'Açık & Güneşli';
        icon = 'Sun';
      } else {
        conditionType = 'normal';
        conditionLabel = 'Parçalı Bulutlu / Ilık';
        icon = 'Cloudy';
      }

      setWeatherData({
        temp,
        humidity,
        windSpeed,
        code,
        conditionType,
        conditionLabel,
        icon,
      });

      // Auto trigger update if there is already a highlight set for this city
      if (activeHighlight && activeHighlight.cityName === city.name) {
        const recommendedIds = getRecommendedProductIds(conditionType);
        onHighlightProducts(recommendedIds, conditionType, city.name);
      }
    } catch (err: any) {
      console.error(err);
      setError('Bağlantı hatası.');
      // Fallback simulated data based on city defaults
      generateSimulatedWeather(city);
    } finally {
      setLoading(false);
    }
  };

  const generateSimulatedWeather = (city: CityConfig) => {
    let temp = 26;
    let humidity = 60;
    let windSpeed = 12;
    let conditionType: 'sunny' | 'rainy' | 'snowy' | 'windy' | 'normal' = 'normal';
    let conditionLabel = 'Ilık & Parçalı Bulutlu';
    let icon = 'Cloudy';

    if (city.name === 'Dalaman' || city.name === 'Ortaca') {
      temp = 28;
      conditionType = 'sunny';
      conditionLabel = 'Açık & Sıcak Güneşli';
      icon = 'Sun';
    } else if (city.name === 'Fethiye' || city.name === 'Bodrum') {
      temp = 30;
      conditionType = 'sunny';
      conditionLabel = 'Güneşli Ege Havası';
      icon = 'Sun';
    } else if (city.name === 'Marmaris') {
      temp = 27;
      conditionType = 'windy';
      windSpeed = 26;
      conditionLabel = 'Rüzgarlı & Esintili';
      icon = 'Wind';
    } else if (city.name === 'Datça') {
      temp = 25;
      conditionType = 'windy';
      windSpeed = 28;
      conditionLabel = 'Meşhur Datça Rüzgarı';
      icon = 'Wind';
    } else if (city.name === 'Menteşe') {
      temp = 22;
      conditionType = 'rainy';
      humidity = 80;
      conditionLabel = 'Serin & Yağmurlu';
      icon = 'CloudRain';
    }

    setWeatherData({
      temp,
      humidity,
      windSpeed,
      code: 0,
      conditionType,
      conditionLabel,
      icon,
    });
  };

  const getRecommendedProductIds = (type: 'sunny' | 'rainy' | 'snowy' | 'windy' | 'normal'): string[] => {
    switch (type) {
      case 'sunny':
        return ['pet_shampoo_aloe', 'fish_food_flakes', 'dog_toy_rope'];
      case 'rainy':
        return ['cat_litter_premium', 'vet_grooming', 'bird_feed_mix'];
      case 'snowy':
        return ['dog_food_premium', 'cat_food_premium', 'cat_toy_laser'];
      case 'windy':
        return ['bird_cage_luxury', 'cat_toy_laser', 'dog_toy_rope'];
      default:
        return ['dog_toy_rope', 'bird_feed_mix', 'cat_litter_premium'];
    }
  };

  const handleApplyHighlight = () => {
    if (!weatherData) return;
    sounds.playClick();
    const recommendedIds = getRecommendedProductIds(weatherData.conditionType);
    
    // Toggle check
    const isAlreadyActive = activeHighlight && activeHighlight.cityName === selectedCityName && activeHighlight.type === weatherData.conditionType;
    if (isAlreadyActive) {
      onHighlightProducts([], '', ''); // Clear
    } else {
      onHighlightProducts(recommendedIds, weatherData.conditionType, selectedCityName);
      sounds.playSuccess();
    }
  };

  const recommendedIds = weatherData ? getRecommendedProductIds(weatherData.conditionType) : [];
  const recommendedItems = catalog.filter(item => recommendedIds.includes(item.id));
  const isCurrentlyHighlighted = activeHighlight && activeHighlight.cityName === selectedCityName && weatherData && activeHighlight.type === weatherData.conditionType;

  // Render weather color scheme
  const getWeatherThemeClasses = () => {
    if (!weatherData) return 'border-art-border bg-art-card/30';
    switch (weatherData.conditionType) {
      case 'sunny':
        return 'border-amber-500/30 bg-gradient-to-br from-amber-950/20 to-art-card';
      case 'rainy':
        return 'border-sky-500/30 bg-gradient-to-br from-sky-950/20 to-art-card';
      case 'snowy':
        return 'border-indigo-500/30 bg-gradient-to-br from-indigo-950/20 to-art-card';
      case 'windy':
        return 'border-teal-500/30 bg-gradient-to-br from-teal-950/20 to-art-card';
      default:
        return 'border-art-border bg-art-card';
    }
  };

  const getWeatherAccentColor = () => {
    if (!weatherData) return 'text-brand-orange';
    switch (weatherData.conditionType) {
      case 'sunny': return 'text-amber-500';
      case 'rainy': return 'text-sky-400';
      case 'snowy': return 'text-indigo-300';
      case 'windy': return 'text-teal-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className={`rounded-xs border p-4 shadow-xl shadow-black/30 transition-all duration-300 ${getWeatherThemeClasses()}`}>
      <div className="flex flex-col gap-3.5">
        
        {/* Widget Header */}
        <div className="flex items-center justify-between border-b border-art-border/40 pb-2.5">
          <div className="flex items-center gap-2">
            <span className={`p-1.5 rounded-xs bg-[#111] border border-art-border ${getWeatherAccentColor()}`}>
              <LucideIcon name="CloudSun" size={14} />
            </span>
            <div>
              <h4 className="text-xs font-black uppercase tracking-wider text-white">
                Pati Hava Durumu
              </h4>
              <p className="text-[8px] text-gray-500 font-extrabold uppercase tracking-widest mt-0.5">
                Şubelere Göre Atmosfer Takibi
              </p>
            </div>
          </div>

          {/* City Selector */}
          <div className="relative">
            <select
              value={selectedCityName}
              onChange={(e) => {
                sounds.playClick();
                setSelectedCityName(e.target.value);
              }}
              className="appearance-none bg-[#1a1a1a] border border-art-border rounded-xs px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-gray-300 pr-7 cursor-pointer focus:outline-none focus:border-brand-orange"
            >
              {CITIES.map(city => (
                <option key={city.name} value={city.name}>
                  {city.name} ({city.description})
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
              <LucideIcon name="ChevronDown" size={10} />
            </div>
          </div>
        </div>

        {/* Weather Info & Stats */}
        {loading ? (
          <div className="py-4 flex flex-col items-center justify-center gap-2">
            <div className="h-6 w-6 rounded-full border-2 border-brand-orange/20 border-t-brand-orange animate-spin" />
            <p className="text-[9px] font-bold uppercase tracking-widest text-gray-500">Canlı Veriler Çekiliyor...</p>
          </div>
        ) : weatherData ? (
          <div className="grid grid-cols-5 gap-3 items-center">
            {/* Visual Big Temperature */}
            <div className="col-span-2 flex items-center gap-2.5 bg-black/25 rounded-xs border border-art-border/30 p-2.5">
              <span className={`text-2xl font-extrabold tracking-tight font-mono ${getWeatherAccentColor()}`}>
                {weatherData.temp}°C
              </span>
              <div className="flex flex-col">
                <LucideIcon name={weatherData.icon} className={`animate-bounce-slow ${getWeatherAccentColor()}`} size={20} />
                <span className="text-[7px] font-black uppercase tracking-widest text-gray-500 mt-1">
                  {weatherData.conditionLabel}
                </span>
              </div>
            </div>

            {/* Micro Stats */}
            <div className="col-span-3 flex flex-col gap-1.5 pl-1.5">
              <div className="flex items-center justify-between text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                <span className="flex items-center gap-1">
                  <LucideIcon name="Droplets" size={10} />
                  <span>Nem</span>
                </span>
                <span className="font-mono text-white">%{weatherData.humidity}</span>
              </div>
              <div className="flex items-center justify-between text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                <span className="flex items-center gap-1">
                  <LucideIcon name="Wind" size={10} />
                  <span>Rüzgar</span>
                </span>
                <span className="font-mono text-white">{weatherData.windSpeed} km/h</span>
              </div>
            </div>
          </div>
        ) : null}

        {error && (
          <p className="text-[8px] font-bold text-amber-500/90 text-center uppercase tracking-wider bg-amber-950/20 p-1.5 border border-amber-900/30 rounded-xs">
            ⚠️ {error} Çevrimdışı moda geçildi.
          </p>
        )}

        {/* Atmospheric Product Highlights */}
        {weatherData && (
          <div className="mt-1 pt-3 border-t border-art-border/30 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-extrabold uppercase tracking-widest text-gray-400 flex items-center gap-1">
                <LucideIcon name="Sparkles" size={10} className="text-brand-orange" />
                <span>Atmosfere Özel Öneriler</span>
              </span>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">
                {recommendedItems.length} Ürün Önerildi
              </span>
            </div>

            {/* Miniature horizontal cards */}
            <div className="grid grid-cols-3 gap-2">
              {recommendedItems.map((item) => (
                <div 
                  key={item.id} 
                  className={`relative p-2 rounded-xs border transition-all ${
                    isCurrentlyHighlighted 
                      ? 'border-brand-orange bg-brand-orange/5 shadow-sm shadow-brand-orange/10 scale-[1.02]' 
                      : 'border-art-border/40 bg-[#111]/40'
                  }`}
                >
                  <div className="flex items-center gap-1 mb-1">
                    <LucideIcon name={item.icon} size={11} className={getWeatherAccentColor()} />
                    <span className="text-[8px] font-bold text-gray-500 uppercase truncate">
                      {item.category === 'dog' ? 'Köpek' : item.category === 'cat' ? 'Kedi' : 'Diğer'}
                    </span>
                  </div>
                  <p className="text-[9px] font-black text-white truncate leading-none mb-1">
                    {item.name}
                  </p>
                  <p className="text-[8px] font-extrabold text-brand-orange font-mono">
                    {item.price} TL
                  </p>
                  
                  {isCurrentlyHighlighted && (
                    <span className="absolute -top-1 -right-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-orange opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-orange"></span>
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* Action Trigger Button */}
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handleApplyHighlight}
              className={`w-full py-2 rounded-xs border text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 ${
                isCurrentlyHighlighted
                  ? 'bg-brand-orange text-black border-brand-orange hover:bg-brand-orange/95 font-black shadow-lg shadow-brand-orange/20'
                  : 'bg-[#181818] border-art-border text-gray-300 hover:bg-[#202020] hover:text-white'
              }`}
            >
              <LucideIcon name={isCurrentlyHighlighted ? 'CheckSquare' : 'Megaphone'} size={12} />
              <span>
                {isCurrentlyHighlighted 
                  ? 'Önerilenleri Geri Çek' 
                  : `Dükkanda "${selectedCityName}" Önerilerini Öne Çıkar`}
              </span>
            </motion.button>
          </div>
        )}
      </div>
    </div>
  );
}
